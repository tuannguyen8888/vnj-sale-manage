-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 21, 2019 at 05:16 PM
-- Server version: 5.7.23
-- PHP Version: 7.1.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gold_sales_manage`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms_apicustom`
--

DROP TABLE IF EXISTS `cms_apicustom`;
CREATE TABLE IF NOT EXISTS `cms_apicustom` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `permalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tabel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kolom` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderby` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_query_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sql_where` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `method_type` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci,
  `responses` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_apikey`
--

DROP TABLE IF EXISTS `cms_apikey`;
CREATE TABLE IF NOT EXISTS `cms_apikey` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `screetkey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_dashboard`
--

DROP TABLE IF EXISTS `cms_dashboard`;
CREATE TABLE IF NOT EXISTS `cms_dashboard` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_email_queues`
--

DROP TABLE IF EXISTS `cms_email_queues`;
CREATE TABLE IF NOT EXISTS `cms_email_queues` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `send_at` datetime DEFAULT NULL,
  `email_recipient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_cc_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_content` text COLLATE utf8mb4_unicode_ci,
  `email_attachments` text COLLATE utf8mb4_unicode_ci,
  `is_sent` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_email_templates`
--

DROP TABLE IF EXISTS `cms_email_templates`;
CREATE TABLE IF NOT EXISTS `cms_email_templates` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_email_templates`
--

INSERT INTO `cms_email_templates` (`id`, `name`, `slug`, `subject`, `content`, `description`, `from_name`, `from_email`, `cc_email`, `created_at`, `updated_at`) VALUES
(1, 'Email cấp lại mật khẩu', 'forgot_password_backend', 'VNJ - Cấp lại mật khẩu', '<p>Chào bạn,</p>\r\n<p>Đây là mật khẩu mới được cấp lại cho bạn:<b>[password]</b></p><p><br></p>\r\n<p></p>\r\n<p>--</p>\r\n<p>Regards,</p>\r\n<p>Việt Ngọc Jewerly</p>', '[password]', 'VNJ System', 'sales.vietngocjewerly@gmail.com', NULL, '2018-03-28 16:38:52', '2019-05-03 15:48:29'),
(2, 'Email thông báo đơn hàng về kế toán', 'sale_notification_accountant', 'Đơn hàng [order_no] của khách hàng [customer_name] ngày [order_date]', '<p>Đơn hàng <b>[order_no]</b> đã được tạo </p>\r\n<p>Ngày bán: <b>[order_date]</b></p>\r\n<p>Khách hàng: <b>[customer_name]</b></p>\r\n<p>Saler: <b>[saler_name]</b></p>\r\n<p></p>\r\n<p>----------</p>\r\n<p>Regards,</p>\r\n<p>Việt Ngọc Jewerly</p>', '[order_no],[order_date],[saler_name],[customer_name]', 'VNJ System', 'sales.vietngocjewerly@gmail.com', 'tuannguyen8888@gmail.com', '2019-05-05 04:27:27', '2019-05-05 10:14:02');

-- --------------------------------------------------------

--
-- Table structure for table `cms_logs`
--

DROP TABLE IF EXISTS `cms_logs`;
CREATE TABLE IF NOT EXISTS `cms_logs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `useragent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `id_cms_users` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_logs`
--

INSERT INTO `cms_logs` (`id`, `ipaddress`, `useragent`, `url`, `description`, `details`, `id_cms_users`, `created_at`, `updated_at`) VALUES
(1, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com login with IP Address ::1', '', 1, '2019-04-19 10:22:32', NULL),
(2, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/8', 'Sửa dữ liệu Loại hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>icon</td><td>fa fa-glass</td><td>fa fa-th-large</td></tr><tr><td>sorting</td><td>8</td><td></td></tr></tbody></table>', 1, '2019-04-19 18:15:29', NULL),
(3, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Nhẫn trong Loại hàng', '', 1, '2019-04-19 18:18:25', NULL),
(4, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Vòng trong Loại hàng', '', 1, '2019-04-19 18:18:36', NULL),
(5, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Bông trong Loại hàng', '', 1, '2019-04-19 18:19:10', NULL),
(6, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Dây trong Loại hàng', '', 1, '2019-04-19 18:19:14', NULL),
(7, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Lắc trong Loại hàng', '', 1, '2019-04-19 18:19:18', NULL),
(8, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Mặt trong Loại hàng', '', 1, '2019-04-19 18:19:23', NULL),
(9, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO 68 trong Kho hàng', '', 1, '2019-04-19 18:30:19', NULL),
(10, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO A trong Kho hàng', '', 1, '2019-04-19 18:30:33', NULL),
(11, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO B trong Kho hàng', '', 1, '2019-04-19 18:30:38', NULL),
(12, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO C trong Kho hàng', '', 1, '2019-04-19 18:30:43', NULL),
(13, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho hàng sửa trong Kho hàng', '', 1, '2019-04-19 18:31:02', NULL),
(14, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 1 trong Kho hàng', '', 1, '2019-04-19 18:31:24', NULL),
(15, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 2 trong Kho hàng', '', 1, '2019-04-19 18:31:32', NULL),
(16, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 3 trong Kho hàng', '', 1, '2019-04-19 18:31:37', NULL),
(17, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 4 trong Kho hàng', '', 1, '2019-04-19 18:31:43', NULL),
(18, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 5 trong Kho hàng', '', 1, '2019-04-19 18:31:50', NULL),
(19, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 6 trong Kho hàng', '', 1, '2019-04-19 18:31:55', NULL),
(20, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 7 trong Kho hàng', '', 1, '2019-04-19 18:32:03', NULL),
(21, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 8 trong Kho hàng', '', 1, '2019-04-19 18:32:08', NULL),
(22, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO VIET NGOC trong Kho hàng', '', 1, '2019-04-19 18:32:32', NULL),
(23, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Bông đít đẩy trong Nhóm hàng', '', 1, '2019-04-19 18:51:31', NULL),
(24, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Bông giò gà trong Nhóm hàng', '', 1, '2019-04-19 18:51:59', NULL),
(25, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Dây cổ trong Nhóm hàng', '', 1, '2019-04-19 18:52:38', NULL),
(26, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Lắc tay trong Nhóm hàng', '', 1, '2019-04-19 18:52:58', NULL),
(27, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_types/add-save', 'Tạo mới dữ liệu 610 trong Loại vàng', '', 1, '2019-04-19 18:53:15', NULL),
(28, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_types/add-save', 'Tạo mới dữ liệu 680 trong Loại vàng', '', 1, '2019-04-19 18:53:24', NULL),
(29, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-20 04:45:44', NULL),
(30, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho test trong Kho hàng', '', 1, '2019-04-20 04:56:54', NULL),
(31, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/delete/15', 'Xóa dữ liệu Kho test trong Kho hàng', '', 1, '2019-04-20 04:57:45', NULL),
(32, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/edit-save/15', 'Sửa dữ liệu Kho test aaa trong Kho hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>Kho test</td><td>Kho test aaa</td></tr><tr><td>created_by</td><td></td><td></td></tr><tr><td>updated_by</td><td></td><td></td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>delete_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 05:00:08', NULL),
(33, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/edit-save/15', 'Sửa dữ liệu Kho test aaa trong Kho hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>notes</td><td>test aaaakkkk</td><td>test aaaakkkkkmomk</td></tr><tr><td>created_by</td><td></td><td></td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>delete_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 05:39:42', NULL),
(34, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 05:40:31', NULL),
(35, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/delete/16', 'Xóa dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 05:41:09', NULL),
(36, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/delete/15', 'Xóa dữ liệu Kho test aaa trong Kho hàng', '', 1, '2019-04-20 05:41:14', NULL),
(37, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Quản lý users trong Menu Management', '', 1, '2019-04-20 06:02:52', NULL),
(38, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Danh sách user trong Menu Management', '', 1, '2019-04-20 06:03:57', NULL),
(39, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/13', 'Sửa dữ liệu Danh sách user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>icon</td><td>fa fa-user</td><td>fa fa-navicon</td></tr><tr><td>parent_id</td><td>12</td><td></td></tr></tbody></table>', 1, '2019-04-20 06:05:45', NULL),
(40, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/users/delete-image', 'Xóa ảnh của Super Admin trong Users Management', '', 1, '2019-04-20 06:58:27', NULL),
(41, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/1', 'Sửa dữ liệu Super Admin trong Users Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>photo</td><td></td><td>uploads/1/2019-04/vnjlogo.png</td></tr><tr><td>password</td><td>$2y$10$Jevyu0o1N651oyZjHyd0Y.367dhBWYrtCTp8jxak40DaWpGjZhw6a</td><td></td></tr><tr><td>id_cms_privileges</td><td>1</td><td></td></tr><tr><td>status</td><td>Active</td><td></td></tr></tbody></table>', 1, '2019-04-20 06:59:05', NULL),
(42, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-20 06:59:17', NULL),
(43, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-20 06:59:20', NULL),
(44, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/12', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>#</td><td></td></tr><tr><td>sorting</td><td>5</td><td></td></tr></tbody></table>', 1, '2019-04-20 07:00:56', NULL),
(45, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tạo mới user trong Menu Management', '', 1, '2019-04-20 07:02:39', NULL),
(46, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/13', 'Sửa dữ liệu Danh sách user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>12</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-04-20 07:03:02', NULL),
(47, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Danh mục trong Menu Management', '', 1, '2019-04-20 07:14:04', NULL),
(48, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/9', 'Sửa dữ liệu Kho hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:06:44', NULL),
(49, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/8', 'Sửa dữ liệu Loại hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:06:56', NULL),
(50, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/10', 'Sửa dữ liệu Nhóm hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:07:08', NULL),
(51, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/11', 'Sửa dữ liệu Loại vàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:07:21', NULL),
(52, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_units/add-save', 'Tạo mới dữ liệu Đôi trong Đơn vị tính', '', 1, '2019-04-20 08:08:57', NULL),
(53, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_units/add-save', 'Tạo mới dữ liệu Chiếc trong Đơn vị tính', '', 1, '2019-04-20 08:09:02', NULL),
(54, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_units/add-save', 'Tạo mới dữ liệu Bộ trong Đơn vị tính', '', 1, '2019-04-20 08:11:16', NULL),
(55, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/9', 'Sửa dữ liệu Kho hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>AdminGoldProductStocksControllerGetIndex</td><td>AdminGoldStocksControllerGetIndex</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:16:01', NULL),
(56, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/edit-save/16', 'Sửa dữ liệu tesst 2 trong Kho hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>notes</td><td></td><td>fhdgf</td></tr><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 08:17:03', NULL),
(57, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/delete/16', 'Xóa dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 08:18:01', NULL),
(58, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/delete/16', 'Xóa dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 08:20:23', NULL),
(59, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/delete/15', 'Xóa dữ liệu Kho test aaa trong Kho hàng', '', 1, '2019-04-20 08:20:29', NULL),
(60, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/17', 'Sửa dữ liệu Sản phẩm trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>8</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:55:07', NULL),
(61, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/add-save', 'Tạo mới dữ liệu do_duc trong Settings', '', 1, '2019-04-20 16:33:57', NULL),
(62, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/add-save', 'Tạo mới dữ liệu do_bong trong Settings', '', 1, '2019-04-20 16:34:25', NULL),
(63, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/edit-save/17', 'Sửa dữ liệu  trong Settings', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>do_duc</td><td></td></tr><tr><td>content</td><td>625</td><td></td></tr><tr><td>content_input_type</td><td>number</td><td>text</td></tr><tr><td>dataenum</td><td></td><td></td></tr><tr><td>helper</td><td></td><td>Bạn chỉ được nhập số</td></tr></tbody></table>', 1, '2019-04-20 16:37:09', NULL),
(64, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/edit-save/18', 'Sửa dữ liệu  trong Settings', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>do_bong</td><td></td></tr><tr><td>content</td><td>635</td><td></td></tr><tr><td>content_input_type</td><td>number</td><td>text</td></tr><tr><td>dataenum</td><td></td><td></td></tr><tr><td>helper</td><td></td><td>Bạn chỉ được nhập số</td></tr></tbody></table>', 1, '2019-04-20 16:37:32', NULL),
(65, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-20 16:41:42', NULL),
(66, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-20 16:54:53', NULL),
(67, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/1', 'Sửa dữ liệu Email Template Forgot Password Backend trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>subject</td><td></td><td>VNJ - Cấp lại mật khẩu</td></tr><tr><td>content</td><td><p>Hi,</p><p>Someone requested forgot password, here is your new password : </p><p>[password]</p><p><br></p><p>--</p><p>Regards,</p><p>Admin</p></td><td><p>Chào bạn,</p>\r\n<p>Đây là mật khẩu mới được cấp lại cho bạn:<b>[password]</b></p><p><br></p>\r\n<p></p>\r\n<p>--</p>\r\n<p>Regards,</p>\r\n<p>Admin</p></td></tr><tr><td>cc_email</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 16:59:03', NULL),
(68, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products/add-save', 'Tạo mới dữ liệu buhk87654 trong Sản phẩm', '', 1, '2019-04-20 17:43:39', NULL),
(69, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products/edit-save/1', 'Sửa dữ liệu buhk87654 trong Sản phẩm', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 17:44:20', NULL),
(70, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products/edit-save/1', 'Sửa dữ liệu buhk87654 trong Sản phẩm', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>status</td><td>0</td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 17:45:13', NULL),
(71, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-21 01:00:41', NULL),
(72, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 07:37:30', NULL),
(73, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 16:44:25', NULL),
(74, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 16:45:58', NULL),
(75, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 17:08:25', NULL),
(76, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 17:08:29', NULL),
(77, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 17:24:20', NULL),
(78, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 17:28:09', NULL),
(79, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 17:28:13', NULL),
(80, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 01:17:41', NULL),
(81, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 03:09:22', NULL),
(82, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 03:09:32', NULL),
(83, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tuổi vàng trong Menu Management', '', 1, '2019-04-23 05:11:08', NULL),
(84, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '', 1, '2019-04-23 05:13:21', NULL),
(85, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 05:13:28', NULL),
(86, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-04-23 05:13:51', NULL),
(87, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:13:58', NULL),
(88, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products', 'Try view the data :name at Sản phẩm', '', 2, '2019-04-23 05:14:06', NULL),
(89, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-04-23 05:14:18', NULL),
(90, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 05:14:22', NULL),
(91, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 05:23:44', NULL),
(92, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-04-23 05:23:59', NULL),
(93, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:24:03', NULL),
(94, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:24:15', NULL),
(95, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:25:40', NULL),
(96, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:25:43', NULL),
(97, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-04-23 05:29:56', NULL),
(98, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 05:30:00', NULL),
(99, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/delete/18', 'Xóa dữ liệu Tuổi vàng trong Menu Management', '', 1, '2019-04-23 05:33:09', NULL),
(100, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tuổi vàng trong Menu Management', '', 1, '2019-04-23 05:46:52', NULL),
(101, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 05:47:47', NULL),
(102, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-04-23 05:48:04', NULL),
(103, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-04-23 08:48:36', NULL),
(104, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 08:48:38', NULL),
(105, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/19', 'Sửa dữ liệu Khách hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:04:59', NULL),
(106, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/16', 'Sửa dữ liệu Đơn vị tính trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>6</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:05:18', NULL),
(107, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/12', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:05:37', NULL),
(108, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/12', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:06:10', NULL),
(109, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/14', 'Sửa dữ liệu Tạo mới user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>12</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:06:22', NULL),
(110, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/13', 'Sửa dữ liệu Danh sách user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>12</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:07:06', NULL),
(111, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_customers/add-save', 'Tạo mới dữ liệu  trong Khách hàng', '', 1, '2019-04-23 09:20:04', NULL),
(112, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_customers/add-save', 'Tạo mới dữ liệu  trong Khách hàng', '', 1, '2019-04-23 09:40:09', NULL),
(113, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/20', 'Sửa dữ liệu Công nợ trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:59:44', NULL),
(114, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/21', 'Sửa dữ liệu Đơn hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 17:04:36', NULL),
(115, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/21', 'Sửa dữ liệu Đơn hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 17:04:53', NULL),
(116, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-24 16:11:26', NULL),
(117, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Kiểm tra đơn hàng trong Menu Management', '', 1, '2019-04-24 16:15:32', NULL),
(118, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tạo đơn hàng mới trong Menu Management', '', 1, '2019-04-24 16:20:15', NULL),
(119, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-25 13:06:55', NULL),
(120, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-26 13:28:57', NULL),
(121, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-29 03:20:03', NULL),
(122, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/gold_products/edit-save/4', 'Sửa dữ liệu 1950400059513 trong Sản phẩm', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>total_weight</td><td>0.863</td><td>0863</td></tr><tr><td>gold_weight</td><td>0.863</td><td>0863</td></tr><tr><td>make_stemp_date</td><td></td><td></td></tr><tr><td>notes</td><td></td><td></td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-30 14:13:59', NULL),
(123, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/gold_products/edit-save/4', 'Sửa dữ liệu 1950400059513 trong Sản phẩm', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>total_weight</td><td>863</td><td>0863</td></tr><tr><td>gold_weight</td><td>863</td><td>0863</td></tr><tr><td>make_stemp_date</td><td></td><td></td></tr><tr><td>notes</td><td></td><td></td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-30 14:14:27', NULL),
(124, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/gold_customers/delete/8', 'Xóa dữ liệu  trong Khách hàng', '', 1, '2019-05-01 04:05:11', NULL),
(125, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/1', 'Sửa dữ liệu Email Template Forgot Password Backend trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>content</td><td><p>Chào bạn,</p>\r\n<p>Đây là mật khẩu mới được cấp lại cho bạn:<b>[password]</b></p><p><br></p>\r\n<p></p>\r\n<p>--</p>\r\n<p>Regards,</p>\r\n<p>Admin</p></td><td><p>Chào bạn,</p>\r\n<p>Đây là mật khẩu mới được cấp lại cho bạn:<b>[password]</b></p><p><br></p>\r\n<p></p>\r\n<p>--</p>\r\n<p>Regards,</p>\r\n<p>Việt Ngọc Jewerly</p></td></tr><tr><td>cc_email</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-01 13:02:25', NULL),
(126, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-03 03:47:31', NULL),
(127, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$F1dU6JO7koEJjbDHwEKGeO8ZSNlVPseD3.hn8RJa/E4yj2Co0INGC</td><td>$2y$10$Uxy2v9MqRlw37EDc7xMMNuLxSA.RZ4DU9nPakgZp3NKaA1W8tamwa</td></tr><tr><td>id_cms_privileges</td><td>5</td><td>2</td></tr><tr><td>status</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-03 04:32:12', NULL),
(128, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-03 04:32:18', NULL),
(129, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-05-03 04:33:41', NULL),
(130, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/gold_sale_orders', 'Try view the data :name at Đơn hàng', '', 2, '2019-05-03 05:28:39', NULL),
(131, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-05-03 05:34:58', NULL),
(132, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-03 05:35:04', NULL),
(133, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-03 15:30:59', NULL),
(134, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/12', 'Xóa dữ liệu Categories trong Module Generator', '', 1, '2019-05-03 15:32:43', NULL),
(135, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/14', 'Xóa dữ liệu Employees trong Module Generator', '', 1, '2019-05-03 15:32:50', NULL),
(136, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/18', 'Xóa dữ liệu History Order trong Module Generator', '', 1, '2019-05-03 15:32:55', NULL),
(137, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/13', 'Xóa dữ liệu Products trong Module Generator', '', 1, '2019-05-03 15:33:03', NULL),
(138, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/15', 'Xóa dữ liệu Report Product Sales trong Module Generator', '', 1, '2019-05-03 15:33:10', NULL),
(139, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/16', 'Xóa dữ liệu Report Profit Sales trong Module Generator', '', 1, '2019-05-03 15:33:17', NULL),
(140, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/17', 'Xóa dữ liệu Stock Report trong Module Generator', '', 1, '2019-05-03 15:33:22', NULL),
(141, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/1', 'Sửa dữ liệu Email cấp lại mật khẩu trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>Email Template Forgot Password Backend</td><td>Email cấp lại mật khẩu</td></tr><tr><td>from_name</td><td>System</td><td>VNJ System</td></tr><tr><td>from_email</td><td>system@crudbooster.com</td><td>sales.vietngocjewerly@gmail.com</td></tr><tr><td>cc_email</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-03 15:48:29', NULL),
(142, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$Uxy2v9MqRlw37EDc7xMMNuLxSA.RZ4DU9nPakgZp3NKaA1W8tamwa</td><td>$2y$10$QzR1NYLJq3cCt21jfjj8o.4OHJ0ytNQsRdX6cZH/bMuIecDseaOIS</td></tr><tr><td>id_cms_privileges</td><td>2</td><td>4</td></tr><tr><td>status</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-03 15:57:36', NULL),
(143, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-03 15:57:41', NULL),
(144, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-05-03 15:57:54', NULL),
(145, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-05-03 16:57:58', NULL),
(146, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-03 16:58:01', NULL);
INSERT INTO `cms_logs` (`id`, `ipaddress`, `useragent`, `url`, `description`, `details`, `id_cms_users`, `created_at`, `updated_at`) VALUES
(147, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$QzR1NYLJq3cCt21jfjj8o.4OHJ0ytNQsRdX6cZH/bMuIecDseaOIS</td><td>$2y$10$QzPxYEvUkbue3GaxLY.pbeY2dLYkLrcPdsu5YbrFfsIkEs1NvtDde</td></tr><tr><td>id_cms_privileges</td><td>4</td><td>5</td></tr><tr><td>status</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-03 16:58:14', NULL),
(148, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-03 16:58:18', NULL),
(149, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-05-03 16:58:28', NULL),
(150, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-04 04:23:47', NULL),
(151, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-04 04:34:23', NULL),
(152, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-04 07:53:53', NULL),
(153, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-05 04:08:03', NULL),
(154, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/email_templates/add-save', 'Tạo mới dữ liệu Email thông báo đơn hàng về kế toán trong Email Templates', '', 1, '2019-05-05 04:27:27', NULL),
(155, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/2', 'Sửa dữ liệu Email thông báo đơn hàng về kế toán trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>content</td><td>Đơn hàng [order_no] đã được tạo [order_date]\r\nSaler: [saler_name]\r\n\r\n-----------\r\nRegards,\r\nViệt Ngọc Jewerly</td><td><p>Đơn hàng <b>[order_no]</b> đã được tạo <b>[order_date]</b></p>\r\n<p>Saler: <b>[saler_name]</b></p>\r\n<p></p>\r\n<p>----------</p>\r\n<p>Regards,</p>\r\n<p>Việt Ngọc Jewerly</p></td></tr><tr><td>cc_email</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-05 04:29:19', NULL),
(156, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/2', 'Sửa dữ liệu Email thông báo đơn hàng về kế toán trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>subject</td><td>Đơn hàng [order_no] đã được tạo [order_date]</td><td>Đơn hàng [order_no] của khách hàng [customer_name] ngày [order_date]</td></tr><tr><td>content</td><td><p>Đơn hàng <b>[order_no]</b> đã được tạo <b>[order_date]</b></p>\r\n<p>Saler: <b>[saler_name]</b></p>\r\n<p></p>\r\n<p>----------</p>\r\n<p>Regards,</p>\r\n<p>Việt Ngọc Jewerly</p></td><td><p>Đơn hàng <b>[order_no]</b> đã được tạo </p>\r\n<p>Ngày bán: <b>[order_date]</b></p>\r\n<p>Khách hàng: <b>[customer_name]</b></p>\r\n<p>Saler: <b>[saler_name]</b></p>\r\n<p></p>\r\n<p>----------</p>\r\n<p>Regards,</p>\r\n<p>Việt Ngọc Jewerly</p></td></tr><tr><td>cc_email</td><td></td><td>vietngocj@gmail.com</td></tr></tbody></table>', 1, '2019-05-05 07:37:03', NULL),
(157, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/2', 'Sửa dữ liệu Email thông báo đơn hàng về kế toán trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>cc_email</td><td>vietngocj@gmail.com</td><td>tuannguyen.8.8.8.8@gmail.com</td></tr></tbody></table>', 1, '2019-05-05 07:38:08', NULL),
(158, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/2', 'Sửa dữ liệu Email thông báo đơn hàng về kế toán trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>description</td><td>[order_no], [order_date], [saler_name]</td><td>[order_no],[order_date],[saler_name],[customer_name]</td></tr></tbody></table>', 1, '2019-05-05 07:39:09', NULL),
(159, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/2', 'Sửa dữ liệu Email thông báo đơn hàng về kế toán trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>cc_email</td><td>tuannguyen.8.8.8.8@gmail.com</td><td>tuannguyen8888@gmail.com</td></tr></tbody></table>', 1, '2019-05-05 10:14:02', NULL),
(160, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/settings/add-save', 'Tạo mới dữ liệu tuoi_hang_khac trong Settings', '', 1, '2019-05-05 16:00:16', NULL),
(161, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/settings/add-save', 'Tạo mới dữ liệu trong_luong_tem trong Settings', '', 1, '2019-05-05 16:01:35', NULL),
(162, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Trọng lượng tem trong Menu Management', '', 1, '2019-05-05 16:03:55', NULL),
(163, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/24', 'Sửa dữ liệu Trọng lượng tem trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>admin/settings/show?group=Trọng%20lượng%20tem</td><td>settings/show?group=Trọng%20lượng%20tem</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>6</td><td></td></tr></tbody></table>', 1, '2019-05-05 16:04:33', NULL),
(164, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/18', 'Sửa dữ liệu Tuổi vàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>/admin/settings/show?group=Tuổi+vàng&m=0</td><td>settings/show?group=Tuổi+vàng&m=0</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>5</td><td></td></tr></tbody></table>', 1, '2019-05-05 16:05:52', NULL),
(165, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/23', 'Sửa dữ liệu Tạo đơn hàng mới trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>/admin/gold_sale_orders/add</td><td>gold_sale_orders/add</td></tr><tr><td>parent_id</td><td>21</td><td></td></tr></tbody></table>', 1, '2019-05-05 16:06:46', NULL),
(166, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-06 16:10:35', NULL),
(167, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-06 16:11:43', NULL),
(168, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-06 16:12:36', NULL),
(169, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-07 11:17:32', NULL),
(170, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tạo đơn hàng nhanh trong Menu Management', '', 1, '2019-05-07 11:21:30', NULL),
(171, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/25', 'Sửa dữ liệu Tạo đơn hàng nhanh trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>gold_sale_orders/fast_order</td><td>gold_sale_orders/fast_order?fast=true</td></tr><tr><td>parent_id</td><td>21</td><td></td></tr></tbody></table>', 1, '2019-05-07 11:28:42', NULL),
(172, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/25', 'Sửa dữ liệu Tạo đơn hàng nhanh trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>gold_sale_orders/fast_order?fast=true</td><td>gold_sale_orders/add?fast=true</td></tr><tr><td>parent_id</td><td>21</td><td></td></tr></tbody></table>', 1, '2019-05-07 11:31:58', NULL),
(173, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-07 14:52:04', NULL),
(174, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/18', 'Sửa dữ liệu Tuổi vàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>settings/show?group=Tuổi+vàng&m=0</td><td>/admin/settings/show?group=Tuổi+vàng&m=0</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>5</td><td></td></tr></tbody></table>', 1, '2019-05-07 14:52:23', NULL),
(175, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/24', 'Sửa dữ liệu Trọng lượng tem trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>settings/show?group=Trọng%20lượng%20tem</td><td>/admin/settings/show?group=Trọng%20lượng%20tem</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>6</td><td></td></tr></tbody></table>', 1, '2019-05-07 14:52:39', NULL),
(176, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/25', 'Sửa dữ liệu Tạo đơn hàng nhanh trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>gold_sale_orders/add?fast=true</td><td>/admin/gold_sale_orders/add?fast=true</td></tr><tr><td>parent_id</td><td>21</td><td></td></tr></tbody></table>', 1, '2019-05-07 14:53:00', NULL),
(177, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/23', 'Sửa dữ liệu Tạo đơn hàng mới trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>gold_sale_orders/add</td><td>/admin/gold_sale_orders/add</td></tr><tr><td>parent_id</td><td>21</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-05-07 14:53:16', NULL),
(178, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/22', 'Sửa dữ liệu Danh sách đơn hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>Kiểm tra đơn hàng</td><td>Danh sách đơn hàng</td></tr><tr><td>parent_id</td><td>21</td><td></td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2019-05-07 15:18:41', NULL),
(179, '::1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-08 02:15:12', NULL),
(180, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-08 17:07:14', NULL),
(181, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-09 06:40:38', NULL),
(182, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-11 02:45:17', NULL),
(183, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu Vinh Nguyễn trong Quản lý Users', '', 1, '2019-05-11 09:33:45', NULL),
(184, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu Trung Danh trong Quản lý Users', '', 1, '2019-05-11 09:40:24', NULL),
(185, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu Accountant trong Quản lý Users', '', 1, '2019-05-11 09:41:16', NULL),
(186, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu Phạm Thị Ngọc Khuyên trong Quản lý Users', '', 1, '2019-05-11 09:42:32', NULL),
(187, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/5', 'Sửa dữ liệu Accountant trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>employee_code</td><td>admin@crudbooster.com</td><td>NV002</td></tr><tr><td>password</td><td>$2y$10$/N77o6FUSjT3wEDbKq4XkOIxfg9GFkkTmhB8x4cZgTp.bWjK4Zpc6</td><td>$2y$10$DcztKyJRGjq/FsoHqJxJQ.ILHM1kuOqZypAbk0PxakEK6sXPQ0WgS</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-11 09:43:49', NULL),
(188, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/6', 'Sửa dữ liệu Phạm Thị Ngọc Khuyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>employee_code</td><td>SALE001</td><td>NV001</td></tr><tr><td>password</td><td>$2y$10$beqFt9gqOkEaTR8d4mfx7eopFKTmRXPGwTnDtPG4upboPVSIvWBPO</td><td></td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-11 09:44:01', NULL),
(189, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>employee_code</td><td>NV0002</td><td>NV003</td></tr><tr><td>password</td><td>$2y$10$QzPxYEvUkbue3GaxLY.pbeY2dLYkLrcPdsu5YbrFfsIkEs1NvtDde</td><td></td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-11 09:44:33', NULL),
(190, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/1', 'Sửa dữ liệu Super Admin trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>employee_code</td><td>NV0001</td><td></td></tr><tr><td>password</td><td>$2y$10$Jevyu0o1N651oyZjHyd0Y.367dhBWYrtCTp8jxak40DaWpGjZhw6a</td><td></td></tr><tr><td>status</td><td>Active</td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-11 09:44:44', NULL),
(191, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/1', 'Sửa dữ liệu Super Admin trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>employee_code</td><td>NV0001</td><td></td></tr><tr><td>password</td><td>$2y$10$Jevyu0o1N651oyZjHyd0Y.367dhBWYrtCTp8jxak40DaWpGjZhw6a</td><td></td></tr><tr><td>status</td><td>Active</td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-11 09:44:56', NULL),
(192, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/1', 'Sửa dữ liệu Super Admin trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>employee_code</td><td>NV0001</td><td></td></tr><tr><td>password</td><td>$2y$10$Jevyu0o1N651oyZjHyd0Y.367dhBWYrtCTp8jxak40DaWpGjZhw6a</td><td></td></tr><tr><td>status</td><td>Active</td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-11 09:45:12', NULL),
(193, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-11 09:55:30', NULL),
(194, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-11 09:55:35', NULL),
(195, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'sale@crudbooster.com đăng xuất', '', 6, '2019-05-11 10:01:37', NULL),
(196, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-11 10:01:40', NULL),
(197, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-11 10:01:54', NULL),
(198, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-11 10:02:04', NULL),
(199, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'sale@crudbooster.com đăng xuất', '', 6, '2019-05-11 10:10:15', NULL),
(200, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-11 10:10:18', NULL),
(201, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-11 10:10:45', NULL),
(202, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-11 10:10:59', NULL),
(203, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'sale@crudbooster.com đăng xuất', '', 6, '2019-05-11 10:11:07', NULL),
(204, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-11 10:11:09', NULL),
(205, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/20', 'Sửa dữ liệu Công nợ trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>5</td><td></td></tr></tbody></table>', 1, '2019-05-11 10:11:30', NULL),
(206, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-11 10:11:37', NULL),
(207, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-11 10:11:47', NULL),
(208, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'sale@crudbooster.com đăng xuất', '', 6, '2019-05-11 11:40:47', NULL),
(209, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-05-11 11:41:06', NULL),
(210, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-12 03:23:43', NULL),
(211, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-13 16:50:15', NULL),
(212, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$QzPxYEvUkbue3GaxLY.pbeY2dLYkLrcPdsu5YbrFfsIkEs1NvtDde</td><td>$2y$10$gYo1BIc3yECAoSOBYyTC9u1or3vFySc0ooE5MTzKF4tb4OSVDSRma</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td></td><td>19</td></tr></tbody></table>', 1, '2019-05-13 18:39:29', NULL),
(213, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$gYo1BIc3yECAoSOBYyTC9u1or3vFySc0ooE5MTzKF4tb4OSVDSRma</td><td>$2y$10$DZAWbZsq7NVqwZcVdZg3DOjrOQ3At.R1JP7VUez3dQgDuzDeKVFwq</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td>19</td><td>1</td></tr></tbody></table>', 1, '2019-05-13 18:40:48', NULL),
(214, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-15 14:17:11', NULL),
(215, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$DZAWbZsq7NVqwZcVdZg3DOjrOQ3At.R1JP7VUez3dQgDuzDeKVFwq</td><td>$2y$10$V2gmAQbDn41Xw/eeatvSuuaqJrbl7akZ4b5Sgnq4NRCuFbtkxmq6K</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td>1</td><td>7</td></tr></tbody></table>', 1, '2019-05-15 14:23:21', NULL),
(216, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$V2gmAQbDn41Xw/eeatvSuuaqJrbl7akZ4b5Sgnq4NRCuFbtkxmq6K</td><td>$2y$10$Z3H7pQ7dxHUVEwBeCaB.mex4Unmoa2K/UvtMNhAh89CsIMahRJ0Ca</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td>7</td><td>Array</td></tr></tbody></table>', 1, '2019-05-15 14:34:00', NULL),
(217, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$Z3H7pQ7dxHUVEwBeCaB.mex4Unmoa2K/UvtMNhAh89CsIMahRJ0Ca</td><td>$2y$10$/eZnHMS0MlEB4Ge9QAbf1eRUdYSvg.JFLJhf5/BpUfSSlCxHSHhPW</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td>Array</td><td>17,20,1</td></tr></tbody></table>', 1, '2019-05-15 14:51:02', NULL),
(218, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/2', 'Sửa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$/eZnHMS0MlEB4Ge9QAbf1eRUdYSvg.JFLJhf5/BpUfSSlCxHSHhPW</td><td>$2y$10$MzOvYfYZv18vDs87TI.XY.6d90Y7.sGcAHbUz8wKpE21NHo0vgpfW</td></tr><tr><td>status</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-15 15:31:36', NULL),
(219, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-16 08:43:08', NULL),
(220, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/6', 'Sửa dữ liệu Phạm Thị Ngọc Khuyên trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$beqFt9gqOkEaTR8d4mfx7eopFKTmRXPGwTnDtPG4upboPVSIvWBPO</td><td>$2y$10$OaWxezhPZXpMhCKUXAulz.ZkEDvvQjv2/QJzRHe93IgZSeBLD9pnu</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td>8</td><td>18,19,8</td></tr></tbody></table>', 1, '2019-05-16 08:43:33', NULL),
(221, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-16 08:43:43', NULL),
(222, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-16 08:45:43', NULL),
(223, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'sale@crudbooster.com đăng xuất', '', 6, '2019-05-16 09:24:18', NULL),
(224, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-16 09:24:21', NULL),
(225, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/gold_customers/edit-save/5', 'Sửa dữ liệu KH0003 trong Khách hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>tmp_code</td><td></td><td></td></tr><tr><td>name</td><td>KỲ KIM PHÁT HIỆP THÀNH</td><td>Vo Tuan Nguyen</td></tr><tr><td>dob</td><td></td><td></td></tr><tr><td>store_name</td><td></td><td>Tiệm test 1</td></tr><tr><td>address</td><td>địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, </td><td>địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng,</td></tr><tr><td>zalo_phone</td><td></td><td>0987175075</td></tr><tr><td>phone</td><td></td><td>987175075</td></tr><tr><td>saler_id</td><td></td><td>6</td></tr><tr><td>notes</td><td></td><td></td></tr><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-16 09:25:21', NULL),
(226, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/gold_customers/edit-save/11', 'Sửa dữ liệu KH0007 trong Khách hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>tmp_code</td><td></td><td></td></tr><tr><td>dob</td><td></td><td>2019-05-16 00:00:00</td></tr><tr><td>store_name</td><td></td><td>Tiệm test 1</td></tr><tr><td>address</td><td>địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, </td><td>địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng,</td></tr><tr><td>zalo_phone</td><td></td><td>098765434567</td></tr><tr><td>phone</td><td></td><td>98765434567</td></tr><tr><td>saler_id</td><td></td><td>6</td></tr><tr><td>notes</td><td></td><td></td></tr><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-16 09:26:41', NULL),
(227, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/gold_customers/edit-save/13', 'Sửa dữ liệu KH0009 trong Khách hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>tmp_code</td><td></td><td></td></tr><tr><td>dob</td><td></td><td></td></tr><tr><td>store_name</td><td></td><td>Tiệm test 3</td></tr><tr><td>address</td><td>địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, </td><td>địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng,</td></tr><tr><td>zalo_phone</td><td></td><td>9876541234567</td></tr><tr><td>phone</td><td></td><td>34654677</td></tr><tr><td>saler_id</td><td></td><td>6</td></tr><tr><td>notes</td><td></td><td></td></tr><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-16 09:27:35', NULL),
(228, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-16 09:32:49', NULL),
(229, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-16 09:32:55', NULL),
(230, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/gold_customers/edit-save/13', 'Sửa dữ liệu KH0009 trong Khách hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>tmp_code</td><td></td><td>77777</td></tr><tr><td>dob</td><td></td><td></td></tr><tr><td>address</td><td>địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng, địa chỉ khách hàng,</td><td>33, Thống Nhất, P10, Gò Vấp, HCM</td></tr><tr><td>address_home_number</td><td></td><td>33</td></tr><tr><td>address_street</td><td></td><td>Thống Nhất</td></tr><tr><td>address_ward</td><td></td><td>P10</td></tr><tr><td>address_district</td><td></td><td>Gò Vấp</td></tr><tr><td>address_province</td><td></td><td>HCM</td></tr><tr><td>import</td><td>1</td><td></td></tr><tr><td>notes</td><td></td><td></td></tr><tr><td>created_by</td><td>1</td><td></td></tr><tr><td>updated_by</td><td>1</td><td>6</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 6, '2019-05-16 10:51:00', NULL),
(231, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'sale@crudbooster.com đăng xuất', '', 6, '2019-05-17 12:56:07', NULL),
(232, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-17 12:56:13', NULL),
(233, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-17 14:31:50', NULL),
(234, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-17 14:31:56', NULL),
(235, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'sale@crudbooster.com đăng xuất', '', 6, '2019-05-17 14:32:21', NULL),
(236, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-17 14:33:04', NULL),
(237, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-18 04:08:18', NULL),
(238, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-19 10:12:53', NULL),
(239, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/module_generator/delete/28', 'Xóa dữ liệu Module Khách Hàng trong Module Generator', '', 1, '2019-05-19 10:25:12', NULL),
(240, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/27', 'Sửa dữ liệu Chỉ định kho bán hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>8</td><td></td></tr></tbody></table>', 1, '2019-05-19 10:31:19', NULL),
(241, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-19 11:12:34', NULL),
(242, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-19 11:12:44', NULL),
(243, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'sale@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 6, '2019-05-20 16:22:00', NULL),
(244, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-21 01:44:06', NULL),
(245, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/23', 'Sửa dữ liệu Tạo đơn hàng mới trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>21</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-05-21 01:45:21', NULL),
(246, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-21 02:32:23', NULL),
(247, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-21 02:54:07', NULL),
(248, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-21 02:54:49', NULL),
(249, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-05-21 13:08:16', NULL),
(250, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/delete/6', 'Xóa dữ liệu Phạm Thị Ngọc Khuyên trong Quản lý Users', '', 1, '2019-05-21 13:50:46', NULL),
(251, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/delete/5', 'Xóa dữ liệu Accountant trong Quản lý Users', '', 1, '2019-05-21 13:50:56', NULL),
(252, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/delete/4', 'Xóa dữ liệu Trung Danh trong Quản lý Users', '', 1, '2019-05-21 13:51:00', NULL),
(253, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/delete/3', 'Xóa dữ liệu Vinh Nguyễn trong Quản lý Users', '', 1, '2019-05-21 13:51:03', NULL),
(254, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/delete/2', 'Xóa dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '', 1, '2019-05-21 13:51:07', NULL),
(255, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu ĐẶNG THỊ THANH HUỆ trong Quản lý Users', '', 1, '2019-05-21 14:09:39', NULL),
(256, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu HỒ TỪ LÂM trong Quản lý Users', '', 1, '2019-05-21 14:11:07', NULL),
(257, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu TRẦN QUỐC HOANH trong Quản lý Users', '', 1, '2019-05-21 14:12:14', NULL),
(258, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu PHẠM THỊ NGỌC KHUYÊN trong Quản lý Users', '', 1, '2019-05-21 14:14:06', NULL),
(259, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu TRẦN THỊ MỸ LỄ trong Quản lý Users', '', 1, '2019-05-21 14:15:09', NULL),
(260, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu PHẠM VIỆT VŨ trong Quản lý Users', '', 1, '2019-05-21 14:16:14', NULL),
(261, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu PHẠM THỊ NHƯ QUỲNH trong Quản lý Users', '', 1, '2019-05-21 14:17:24', NULL),
(262, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu NGUYỄN MINH CÓ trong Quản lý Users', '', 1, '2019-05-21 14:18:49', NULL),
(263, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu NGUYỄN TẤN TƯỜNG trong Quản lý Users', '', 1, '2019-05-21 14:19:48', NULL),
(264, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/9', 'Sửa dữ liệu NGUYỄN MINH CÓ trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$CriUCK74UnpVbbGYIFqj9.9iWThLFWeHLYWqvDuTgKTLduKbsLpJO</td><td>$2y$10$EJd54NGkapXOpRAqKFSmbOfk0N1n0RwjVhxQA6DDUx17.D4R6AaU6</td></tr><tr><td>id_cms_privileges</td><td>2</td><td>5</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-21 14:20:04', NULL),
(265, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/9', 'Sửa dữ liệu NGUYỄN MINH CÓ trong Quản lý Users', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>password</td><td>$2y$10$EJd54NGkapXOpRAqKFSmbOfk0N1n0RwjVhxQA6DDUx17.D4R6AaU6</td><td>$2y$10$.w8/wjuherjVOy9ZPsGngutrvaNWz5K3OkLEKfaK0IaEsEdFEW5P6</td></tr><tr><td>status</td><td></td><td></td></tr><tr><td>stock_id</td><td></td><td></td></tr></tbody></table>', 1, '2019-05-21 14:20:24', NULL),
(266, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-05-21 14:20:55', NULL),
(267, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36', 'http://localhost:8888/admin/login', 'tuongnguyen.hce@gmail.com đăng nhập với địa chỉ IP ::1', '', 10, '2019-05-21 14:21:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_menus`
--

DROP TABLE IF EXISTS `cms_menus`;
CREATE TABLE IF NOT EXISTS `cms_menus` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'url',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_dashboard` tinyint(1) NOT NULL DEFAULT '0',
  `id_cms_privileges` int(11) DEFAULT NULL,
  `sorting` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_menus`
--

INSERT INTO `cms_menus` (`id`, `name`, `type`, `path`, `color`, `icon`, `parent_id`, `is_active`, `is_dashboard`, `id_cms_privileges`, `sorting`, `created_at`, `updated_at`) VALUES
(8, 'Loại hàng', 'Route', 'AdminGoldProductCategoriesControllerGetIndex', 'normal', 'fa fa-th-large', 15, 1, 0, 1, 2, '2019-04-19 18:09:36', '2019-04-20 08:06:56'),
(9, 'Kho hàng', 'Route', 'AdminGoldStocksControllerGetIndex', 'normal', 'fa fa-hospital-o', 15, 1, 0, 1, 1, '2019-04-19 18:25:43', '2019-04-20 08:16:01'),
(10, 'Nhóm hàng', 'Route', 'AdminGoldProductGroupsControllerGetIndex', 'normal', 'fa fa-th', 15, 1, 0, 1, 3, '2019-04-19 18:33:57', '2019-04-20 08:07:08'),
(11, 'Loại vàng', 'Route', 'AdminGoldProductTypesControllerGetIndex', 'normal', 'fa fa-unlink', 15, 1, 0, 1, 4, '2019-04-19 18:48:53', '2019-04-20 08:07:21'),
(12, 'Quản lý users', 'URL', '#', 'normal', 'fa fa-group', 0, 1, 0, 1, 6, '2019-04-20 06:02:52', '2019-04-23 09:06:10'),
(13, 'Danh sách user', 'Module', 'users', 'normal', 'fa fa-navicon', 12, 1, 0, 1, 2, '2019-04-20 06:03:57', '2019-04-23 09:07:06'),
(14, 'Tạo mới user', 'URL', '/admin/users/add', 'normal', 'fa fa-plus', 12, 1, 0, 1, 1, '2019-04-20 07:02:39', '2019-04-23 09:06:22'),
(15, 'Danh mục', 'URL', '#', 'normal', 'fa fa-sitemap', 0, 1, 0, 1, 1, '2019-04-20 07:14:04', NULL),
(16, 'Đơn vị tính', 'Route', 'AdminGoldProductUnitsControllerGetIndex', 'normal', 'fa fa-stack-overflow', 15, 1, 0, 1, 7, '2019-04-20 08:00:45', '2019-04-23 09:05:18'),
(17, 'Sản phẩm', 'Route', 'AdminGoldProductsControllerGetIndex', 'normal', 'fa fa-cubes', 0, 1, 0, 1, 2, '2019-04-20 08:24:54', '2019-04-20 08:55:07'),
(18, 'Tuổi vàng', 'URL', '/admin/settings/show?group=Tuổi+vàng&m=0', 'normal', 'fa fa-magic', 15, 1, 0, 1, 5, '2019-04-23 05:46:52', '2019-05-07 14:52:23'),
(19, 'Khách hàng', 'Route', 'AdminGoldCustomersControllerGetIndex', 'normal', 'fa fa-male', 0, 1, 0, 1, 3, '2019-04-23 08:54:43', '2019-04-23 09:04:59'),
(20, 'Công nợ', 'Route', 'AdminGoldLiabilitiesControllerGetIndex', 'normal', 'fa fa-money', 0, 1, 0, 1, 5, '2019-04-23 09:49:28', '2019-05-11 10:11:30'),
(21, 'Đơn hàng', 'Route', 'AdminGoldSaleOrdersControllerGetIndex', 'normal', 'fa fa-diamond', 0, 1, 0, 1, 4, '2019-04-23 16:50:00', '2019-04-23 17:04:53'),
(22, 'Danh sách đơn hàng', 'Module', 'gold_sale_orders', 'normal', 'fa fa-th-list', 21, 1, 0, 1, 3, '2019-04-24 16:15:32', '2019-05-07 15:18:41'),
(23, 'Tạo đơn hàng mới', 'URL', '/admin/gold_sale_orders/add', 'normal', 'fa fa-cart-plus', 21, 1, 0, 1, 2, '2019-04-24 16:20:15', '2019-05-21 01:45:21'),
(24, 'Trọng lượng tem', 'URL', '/admin/settings/show?group=Trọng%20lượng%20tem', 'normal', 'fa fa-tags', 15, 1, 0, 1, 6, '2019-05-05 16:03:55', '2019-05-07 14:52:39'),
(25, 'Tạo đơn hàng nhanh', 'URL', '/admin/gold_sale_orders/add?fast=true', 'normal', 'fa fa-flash', 21, 1, 0, 1, 1, '2019-05-07 11:21:30', '2019-05-07 14:53:00'),
(27, 'Chỉ định kho bán hàng', 'Route', 'AdminGoldAssignStocksControllerGetIndex', 'normal', 'fa fa-usb', 0, 1, 0, 1, 8, '2019-05-19 10:17:33', '2019-05-19 10:31:19');

-- --------------------------------------------------------

--
-- Table structure for table `cms_menus_privileges`
--

DROP TABLE IF EXISTS `cms_menus_privileges`;
CREATE TABLE IF NOT EXISTS `cms_menus_privileges` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_cms_menus` int(11) DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_menus_privileges`
--

INSERT INTO `cms_menus_privileges` (`id`, `id_cms_menus`, `id_cms_privileges`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(22, 15, 5),
(23, 15, 2),
(24, 15, 3),
(25, 15, 4),
(26, 15, 1),
(33, 8, 5),
(34, 8, 2),
(35, 8, 3),
(36, 8, 4),
(37, 8, 1),
(38, 10, 5),
(39, 10, 2),
(40, 10, 3),
(41, 10, 4),
(42, 10, 1),
(43, 11, 5),
(44, 11, 2),
(45, 11, 3),
(46, 11, 4),
(47, 11, 1),
(48, 9, 5),
(49, 9, 2),
(50, 9, 3),
(51, 9, 4),
(52, 9, 1),
(53, 17, 5),
(54, 17, 2),
(55, 17, 3),
(56, 17, 4),
(57, 17, 1),
(61, 19, 5),
(62, 19, 2),
(63, 19, 3),
(64, 19, 4),
(65, 19, 1),
(66, 16, 5),
(67, 16, 2),
(68, 16, 3),
(69, 16, 4),
(70, 16, 1),
(71, 12, 4),
(72, 14, 4),
(73, 13, 4),
(76, 21, 5),
(77, 21, 2),
(78, 21, 1),
(94, 18, 5),
(95, 18, 4),
(96, 18, 1),
(97, 24, 5),
(98, 24, 4),
(99, 24, 1),
(100, 25, 2),
(101, 25, 1),
(104, 22, 5),
(105, 22, 2),
(106, 22, 1),
(107, 20, 5),
(108, 20, 2),
(109, 20, 1),
(110, 26, 1),
(111, 27, 5),
(112, 27, 1),
(113, 23, 5),
(114, 23, 2),
(115, 23, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_moduls`
--

DROP TABLE IF EXISTS `cms_moduls`;
CREATE TABLE IF NOT EXISTS `cms_moduls` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_protected` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_moduls`
--

INSERT INTO `cms_moduls` (`id`, `name`, `icon`, `path`, `table_name`, `controller`, `is_protected`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Notifications', 'fa fa-cog', 'notifications', 'cms_notifications', 'NotificationsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(2, 'Privileges', 'fa fa-cog', 'privileges', 'cms_privileges', 'PrivilegesController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(3, 'Privileges Roles', 'fa fa-cog', 'privileges_roles', 'cms_privileges_roles', 'PrivilegesRolesController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(4, 'Quản lý Users', 'fa fa-users', 'users', 'cms_users', 'AdminCmsUsersController', 0, 1, '2018-03-28 16:38:50', NULL, NULL),
(5, 'Settings', 'fa fa-cog', 'settings', 'cms_settings', 'SettingsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(6, 'Module Generator', 'fa fa-database', 'module_generator', 'cms_moduls', 'ModulsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(7, 'Menu Management', 'fa fa-bars', 'menu_management', 'cms_menus', 'MenusController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(8, 'Email Templates', 'fa fa-envelope-o', 'email_templates', 'cms_email_templates', 'EmailTemplatesController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(9, 'Statistic Builder', 'fa fa-dashboard', 'statistic_builder', 'cms_statistics', 'StatisticBuilderController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(10, 'API Generator', 'fa fa-cloud-download', 'api_generator', '', 'ApiCustomController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(11, 'Log User Access', 'fa fa-flag-o', 'logs', 'cms_logs', 'LogsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(19, 'Loại hàng', 'fa fa-th-large', 'gold_product_categories', 'gold_product_categories', 'AdminGoldProductCategoriesController', 0, 0, '2019-04-19 18:09:36', NULL, NULL),
(20, 'Kho hàng', 'fa fa-hospital-o', 'gold_stocks', 'gold_stocks', 'AdminGoldStocksController', 0, 0, '2019-04-19 18:25:43', NULL, NULL),
(21, 'Nhóm hàng', 'fa fa-th', 'gold_product_groups', 'gold_product_groups', 'AdminGoldProductGroupsController', 0, 0, '2019-04-19 18:33:57', NULL, NULL),
(22, 'Loại vàng', 'fa fa-unlink', 'gold_product_types', 'gold_product_types', 'AdminGoldProductTypesController', 0, 0, '2019-04-19 18:48:53', NULL, NULL),
(23, 'Đơn vị tính', 'fa fa-stack-overflow', 'gold_product_units', 'gold_product_units', 'AdminGoldProductUnitsController', 0, 0, '2019-04-20 08:00:45', NULL, NULL),
(24, 'Sản phẩm', 'fa fa-cubes', 'gold_products', 'gold_products', 'AdminGoldProductsController', 0, 0, '2019-04-20 08:24:53', NULL, NULL),
(25, 'Khách hàng', 'fa fa-male', 'gold_customers', 'gold_customers', 'AdminGoldCustomersController', 0, 0, '2019-04-23 08:54:43', NULL, NULL),
(26, 'Công nợ', 'fa fa-money', 'gold_liabilities', 'gold_liabilities', 'AdminGoldLiabilitiesController', 0, 0, '2019-04-23 09:49:28', NULL, NULL),
(27, 'Đơn hàng', 'fa fa-diamond', 'gold_sale_orders', 'gold_sale_orders', 'AdminGoldSaleOrdersController', 0, 0, '2019-04-23 16:50:00', NULL, NULL),
(29, 'Chỉ định kho bán hàng', 'fa fa-usb', 'gold_assign_stocks', 'cms_users', 'AdminGoldAssignStocksController', 0, 0, '2019-05-19 10:17:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_notifications`
--

DROP TABLE IF EXISTS `cms_notifications`;
CREATE TABLE IF NOT EXISTS `cms_notifications` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_cms_users` int(11) DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_privileges`
--

DROP TABLE IF EXISTS `cms_privileges`;
CREATE TABLE IF NOT EXISTS `cms_privileges` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_superadmin` tinyint(1) DEFAULT NULL,
  `theme_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_privileges`
--

INSERT INTO `cms_privileges` (`id`, `name`, `is_superadmin`, `theme_color`, `created_at`, `updated_at`) VALUES
(1, 'Super Administrator', 1, 'skin-blue', '2018-03-28 16:38:50', NULL),
(2, 'Nhân viên bán hàng', 0, 'skin-blue', NULL, NULL),
(3, 'Quản lý đơn hàng sản xuất', 0, 'skin-blue', NULL, NULL),
(4, 'Quản trị hệ thống', 0, 'skin-blue', NULL, NULL),
(5, 'Kế toán', 0, 'skin-blue', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_privileges_roles`
--

DROP TABLE IF EXISTS `cms_privileges_roles`;
CREATE TABLE IF NOT EXISTS `cms_privileges_roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `is_visible` tinyint(1) DEFAULT NULL,
  `is_create` tinyint(1) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `is_edit` tinyint(1) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `id_cms_moduls` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_privileges_roles`
--

INSERT INTO `cms_privileges_roles` (`id`, `is_visible`, `is_create`, `is_read`, `is_edit`, `is_delete`, `id_cms_privileges`, `id_cms_moduls`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 0, 0, 0, 1, 1, '2018-03-28 16:38:50', NULL),
(2, 1, 1, 1, 1, 1, 1, 2, '2018-03-28 16:38:51', NULL),
(3, 0, 1, 1, 1, 1, 1, 3, '2018-03-28 16:38:51', NULL),
(4, 1, 1, 1, 1, 1, 1, 4, '2018-03-28 16:38:51', NULL),
(5, 1, 1, 1, 1, 1, 1, 5, '2018-03-28 16:38:51', NULL),
(6, 1, 1, 1, 1, 1, 1, 6, '2018-03-28 16:38:51', NULL),
(7, 1, 1, 1, 1, 1, 1, 7, '2018-03-28 16:38:51', NULL),
(8, 1, 1, 1, 1, 1, 1, 8, '2018-03-28 16:38:51', NULL),
(9, 1, 1, 1, 1, 1, 1, 9, '2018-03-28 16:38:51', NULL),
(10, 1, 1, 1, 1, 1, 1, 10, '2018-03-28 16:38:51', NULL),
(11, 1, 0, 1, 0, 1, 1, 11, '2018-03-28 16:38:51', NULL),
(12, 1, 1, 1, 1, 1, 2, 4, NULL, NULL),
(13, 1, 1, 1, 1, 1, 1, 12, NULL, NULL),
(14, 1, 1, 1, 1, 1, 1, 13, NULL, NULL),
(15, 1, 1, 1, 1, 1, 1, 14, NULL, NULL),
(16, 1, 1, 1, 1, 1, 1, 15, NULL, NULL),
(17, 1, 1, 1, 1, 1, 1, 16, NULL, NULL),
(18, 1, 1, 1, 1, 1, 1, 17, NULL, NULL),
(19, 1, 1, 1, 1, 1, 2, 17, NULL, NULL),
(20, 1, 1, 1, 1, 1, 1, 18, NULL, NULL),
(21, 1, 0, 0, 0, 0, 3, 13, NULL, NULL),
(22, 1, 0, 0, 0, 0, 4, 12, NULL, NULL),
(23, 1, 0, 0, 0, 0, 4, 14, NULL, NULL),
(24, 1, 0, 0, 0, 0, 4, 18, NULL, NULL),
(25, 1, 0, 0, 0, 0, 4, 13, NULL, NULL),
(26, 1, 0, 0, 0, 0, 4, 15, NULL, NULL),
(27, 1, 0, 0, 0, 0, 4, 16, NULL, NULL),
(28, 1, 0, 0, 0, 0, 4, 17, NULL, NULL),
(29, 1, 1, 1, 1, 1, 4, 4, NULL, NULL),
(30, 1, 1, 1, 1, 1, 1, 19, NULL, NULL),
(31, 1, 1, 1, 1, 1, 1, 20, NULL, NULL),
(32, 1, 1, 1, 1, 1, 1, 21, NULL, NULL),
(33, 1, 1, 1, 1, 1, 1, 22, NULL, NULL),
(34, 1, 1, 1, 1, 1, 5, 20, NULL, NULL),
(35, 1, 1, 1, 1, 1, 5, 19, NULL, NULL),
(36, 1, 1, 1, 1, 1, 5, 22, NULL, NULL),
(37, 1, 1, 1, 1, 1, 5, 21, NULL, NULL),
(38, 1, 1, 1, 1, 1, 1, 23, NULL, NULL),
(39, 1, 1, 1, 1, 1, 1, 24, NULL, NULL),
(40, 1, 1, 1, 1, 1, 5, 23, NULL, NULL),
(41, 1, 1, 1, 1, 1, 5, 24, NULL, NULL),
(42, 1, 0, 1, 0, 0, 4, 23, NULL, NULL),
(43, 1, 0, 1, 0, 0, 4, 20, NULL, NULL),
(44, 1, 0, 1, 0, 0, 4, 19, NULL, NULL),
(45, 1, 0, 1, 0, 0, 4, 22, NULL, NULL),
(46, 1, 0, 1, 0, 0, 4, 21, NULL, NULL),
(47, 1, 0, 1, 0, 0, 4, 24, NULL, NULL),
(48, 1, 1, 1, 1, 1, 1, 25, NULL, NULL),
(49, 1, 1, 1, 1, 1, 1, 26, NULL, NULL),
(50, 1, 1, 1, 1, 1, 1, 27, NULL, NULL),
(51, 1, 1, 1, 1, 1, 5, 26, NULL, NULL),
(52, 1, 1, 1, 0, 0, 5, 27, NULL, NULL),
(53, 1, 1, 1, 1, 1, 5, 25, NULL, NULL),
(54, 1, 0, 1, 0, 0, 4, 25, NULL, NULL),
(55, 1, 0, 1, 0, 0, 3, 23, NULL, NULL),
(56, 1, 0, 1, 0, 0, 3, 20, NULL, NULL),
(57, 1, 0, 1, 0, 0, 3, 19, NULL, NULL),
(58, 1, 0, 1, 0, 0, 3, 22, NULL, NULL),
(59, 1, 0, 1, 0, 0, 3, 21, NULL, NULL),
(60, 1, 0, 1, 0, 0, 3, 24, NULL, NULL),
(61, 1, 0, 1, 0, 0, 2, 26, NULL, NULL),
(62, 1, 1, 1, 0, 0, 2, 27, NULL, NULL),
(63, 1, 0, 1, 0, 0, 2, 23, NULL, NULL),
(64, 1, 1, 1, 1, 0, 2, 25, NULL, NULL),
(65, 1, 0, 1, 0, 0, 2, 20, NULL, NULL),
(66, 1, 0, 1, 0, 0, 2, 19, NULL, NULL),
(67, 1, 0, 1, 0, 0, 2, 22, NULL, NULL),
(68, 1, 0, 1, 0, 0, 2, 21, NULL, NULL),
(69, 1, 0, 1, 0, 0, 2, 24, NULL, NULL),
(70, 1, 1, 1, 1, 1, 1, 28, NULL, NULL),
(71, 1, 1, 1, 1, 1, 1, 29, NULL, NULL),
(72, 1, 0, 1, 1, 0, 5, 29, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_settings`
--

DROP TABLE IF EXISTS `cms_settings`;
CREATE TABLE IF NOT EXISTS `cms_settings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `content_input_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dataenum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `helper` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `group_setting` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_settings`
--

INSERT INTO `cms_settings` (`id`, `name`, `content`, `content_input_type`, `dataenum`, `helper`, `created_at`, `updated_at`, `group_setting`, `label`) VALUES
(1, 'login_background_color', '#4db8ff', 'text', NULL, 'Input hexacode', '2018-03-28 16:38:51', NULL, 'Login Register Style', 'Login Background Color'),
(2, 'login_font_color', NULL, 'text', NULL, 'Input hexacode', '2018-03-28 16:38:51', NULL, 'Login Register Style', 'Login Font Color'),
(3, 'login_background_image', 'uploads/2019-05/30dcdd34c0a8f78de794d690bc428ca8.jpg', 'upload_image', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Login Register Style', 'Login Background Image'),
(4, 'email_sender', 'sales.vietngocjewerly@gmail.com', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'Email Sender'),
(5, 'smtp_driver', 'smtp', 'select', 'smtp,mail,sendmail', NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'Mail Driver'),
(6, 'smtp_host', 'smtp.gmail.com', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Host'),
(7, 'smtp_port', '465', 'text', NULL, 'default 25', '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Port'),
(8, 'smtp_username', 'sales.vietngocjewerly@gmail.com', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Username'),
(9, 'smtp_password', 'pjfmloicjyatzscp', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Password'),
(10, 'appname', 'Việt Ngọc Jewelry', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Application Name'),
(11, 'default_paper_size', 'Legal', 'text', NULL, 'Paper size, ex : A4, Legal, etc', '2018-03-28 16:38:51', NULL, 'Application Setting', 'Default Paper Print Size'),
(12, 'logo', 'uploads/2019-04/c52cca1e0f0865b1a378c1d1395cd51f.png', 'upload_image', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Logo'),
(13, 'favicon', 'uploads/2019-04/5a1ae61c6e05dc9cdf5b4bd46943281b.jpg', 'upload_image', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Favicon'),
(14, 'api_debug_mode', 'true', 'select', 'true,false', NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'API Debug Mode'),
(15, 'google_api_key', NULL, 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Google API Key'),
(16, 'google_fcm_key', NULL, 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Google FCM Key'),
(17, 'do_duc', '62.5', 'text', NULL, 'Bạn chỉ được nhập số', '2019-04-20 16:33:57', '2019-04-20 16:37:09', 'Tuổi vàng', 'Đồ đúc'),
(18, 'do_bong', '63.5', 'text', NULL, 'Bạn chỉ được nhập số', '2019-04-20 16:34:25', '2019-04-20 16:37:32', 'Tuổi vàng', 'Đồ bộng'),
(19, 'tuoi_hang_khac', '64', 'text', NULL, 'Bạn chỉ được nhập số', '2019-05-05 16:00:16', NULL, 'Tuổi vàng', 'Tuổi hàng khác'),
(20, 'trong_luong_tem', '0.012', 'text', NULL, 'Bạn chỉ được nhập số', '2019-05-05 16:01:35', NULL, 'Trọng lượng tem', 'Trọng lượng tem');

-- --------------------------------------------------------

--
-- Table structure for table `cms_statistics`
--

DROP TABLE IF EXISTS `cms_statistics`;
CREATE TABLE IF NOT EXISTS `cms_statistics` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_statistic_components`
--

DROP TABLE IF EXISTS `cms_statistic_components`;
CREATE TABLE IF NOT EXISTS `cms_statistic_components` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_cms_statistics` int(11) DEFAULT NULL,
  `componentID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `component_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_name` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sorting` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_users`
--

DROP TABLE IF EXISTS `cms_users`;
CREATE TABLE IF NOT EXISTS `cms_users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_code` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Mã nhân vin',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Kho hàng của saler',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_users`
--

INSERT INTO `cms_users` (`id`, `name`, `photo`, `email`, `employee_code`, `password`, `id_cms_privileges`, `created_at`, `updated_at`, `status`, `stock_id`) VALUES
(1, 'Super Admin', 'uploads/1/2019-04/vnjlogo.png', 'admin@crudbooster.com', '', '$2y$10$Jevyu0o1N651oyZjHyd0Y.367dhBWYrtCTp8jxak40DaWpGjZhw6a', 1, '2018-03-28 16:38:50', '2019-05-11 09:45:12', 'Active', NULL),
(2, 'ĐẶNG THỊ THANH HUỆ', 'uploads/1/2019-05/vnjlogo.png', 'nv0001.vnj@gmail.com', 'NV0001', '$2y$10$uLs5H1mcys.MJgVQBw0lX./.9bakUuZuFL6I0PTZthpoM.dNmIgSi', 2, '2019-05-21 14:09:39', NULL, NULL, NULL),
(3, 'HỒ TỪ LÂM', 'uploads/1/2019-05/vnjlogo.png', 'nv0008.vnj@gmail.com', 'NV0008', '$2y$10$h0dfHdzdrZFXIN2Hc7RSuO.nHDKZnvb0QhaVopf9G98jTxCVehtW6', 2, '2019-05-21 14:11:07', NULL, NULL, NULL),
(4, 'TRẦN QUỐC HOANH', 'uploads/1/2019-05/vnjlogo.png', 'nv0009.vnj@gmail.com', 'NV0009', '$2y$10$.5jB2h7bN1Upv.Miiqk7NurHvJmFJEqJ1o3LbIhMEPUBTOubfnLme', 2, '2019-05-21 14:12:14', NULL, NULL, NULL),
(5, 'PHẠM THỊ NGỌC KHUYÊN', 'uploads/1/2019-05/vnjlogo.png', 'nv0015.vnj@gmail.com', 'NV0015', '$2y$10$f5RrzWsCIJ2ZTFGcSQR.d.iQ.Zmj.AL5gHTIJfMv.mejT/tJniKem', 2, '2019-05-21 14:14:06', NULL, NULL, NULL),
(6, 'TRẦN THỊ MỸ LỄ', 'uploads/1/2019-05/vnjlogo.png', 'nv0026.vnj@gmail.com', 'NV0026', '$2y$10$ph0KxtaXI20CYHNFFMCFgeBAAgk8BeIFhEtcUJrQHW3bOxtT9ud1m', 2, '2019-05-21 14:15:09', NULL, NULL, NULL),
(7, 'PHẠM VIỆT VŨ', 'uploads/1/2019-05/vnjlogo.png', 'nv0040.vnj@gmail.com', 'NV0040', '$2y$10$WBHZwML94FzxXFAsmAXz8.JYkH6TU0At2V/GxCiTF/wjQzd9v.wKO', 2, '2019-05-21 14:16:14', NULL, NULL, NULL),
(8, 'PHẠM THỊ NHƯ QUỲNH', 'uploads/1/2019-05/vnjlogo.png', 'nv0073.vnj@gmail.com', 'NV0073', '$2y$10$AHMFnBUqx403.tVxl9kuhuyJZFz589AiiVef72BHg6M6iqoyiHgS.', 5, '2019-05-21 14:17:24', NULL, NULL, NULL),
(9, 'NGUYỄN MINH CÓ', 'uploads/1/2019-05/vnjlogo.png', 'ketoanvnj1@gmail.com', 'NV0099', '$2y$10$.w8/wjuherjVOy9ZPsGngutrvaNWz5K3OkLEKfaK0IaEsEdFEW5P6', 5, '2019-05-21 14:18:49', '2019-05-21 14:20:24', NULL, NULL),
(10, 'NGUYỄN TẤN TƯỜNG', 'uploads/1/2019-05/vnjlogo.png', 'tuongnguyen.hce@gmail.com', 'NV0100', '$2y$10$7yeavr6EZMfMefi/AF2xMubv5zyQdw2Z4kFpEs8pAnZOZ5o4LYU0u', 4, '2019-05-21 14:19:48', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_users_gold_stocks`
--

DROP TABLE IF EXISTS `cms_users_gold_stocks`;
CREATE TABLE IF NOT EXISTS `cms_users_gold_stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cms_users_id` int(11) DEFAULT NULL,
  `gold_stocks` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bảng Quan hệ saler với kho';

-- --------------------------------------------------------

--
-- Table structure for table `gold_customers`
--

DROP TABLE IF EXISTS `gold_customers`;
CREATE TABLE IF NOT EXISTS `gold_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tmp_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` timestamp NULL DEFAULT NULL COMMENT 'Ngày sinh chủ tiệm',
  `store_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tên tiệm vàng',
  `address` varchar(420) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_home_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_street` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tên Đường/chợ/ấp/khu phố/thôn/xóm',
  `address_ward` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Xã/phường/thị trấn',
  `address_district` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Huyện/quận/thị xã/thành phố trược thuộc tỉnh',
  `address_province` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tỉnh/thành phố trực thuộc TW',
  `zalo_phone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Số đt có Zalo',
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `saler_id` int(11) DEFAULT NULL COMMENT 'Nhân vin bán hàng',
  `import` int(1) DEFAULT '0' COMMENT '1 = Được import từ bảng công nợ của kế toán, mã được lưu vào cột code\n0 = Được phát sinh tạm thời khi Saler bán cho khách hàng mới, mã được lưu vào cột tmp_code',
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `tmp_code_UNIQUE` (`tmp_code`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=523 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_customers`
--

INSERT INTO `gold_customers` (`id`, `code`, `tmp_code`, `name`, `dob`, `store_name`, `address`, `address_home_number`, `address_street`, `address_ward`, `address_district`, `address_province`, `zalo_phone`, `phone`, `saler_id`, `import`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'KH0269', NULL, 'KIM CHÂU 2', NULL, NULL, '---H. LÁI THIÊU-BÌNH DƯƠNG', '', '', '', 'H. LÁI THIÊU', 'BÌNH DƯƠNG', NULL, '0918485678', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(2, 'KH0277', NULL, 'KIM THÀNH DIỄN', NULL, NULL, '-NGUYỄN THỊ MINH KHAI-P. TÂN ĐÔNG HIỆP-TX. DĨ AN-BÌNH DƯƠNG', '', 'NGUYỄN THỊ MINH KHAI', 'P. TÂN ĐÔNG HIỆP', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0985709305', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(3, 'KH0550', NULL, 'KIM THANH THỊNH', NULL, NULL, '4/8-KP ĐÔNG AN-P. BÌNH HƯNG HÒA-TX. THUẬN AN-BÌNH DƯƠNG', '4/8', 'KP ĐÔNG AN', 'P. BÌNH HƯNG HÒA', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0963891565', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(4, 'KH0539', NULL, 'KIM CHÂU 3', NULL, NULL, '11-DT745-P. LÁI THIÊU-TX. THUẬN AN-BÌNH DƯƠNG', '11', 'DT745', 'P. LÁI THIÊU', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0983692661', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(5, 'KH0498', NULL, 'KIM NGÂN', NULL, NULL, '266/11-ẤP 11-X. AN PHÚ TÂY-H. BÌNH CHÁNH-HCM', '266/11', 'ẤP 11', 'X. AN PHÚ TÂY', 'H. BÌNH CHÁNH', 'HCM', NULL, '0964471417', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(6, 'KH0505', NULL, 'TUẤN KIỆT VĨNH LỘC', NULL, NULL, 'B3/30H-KÊNH TRUNG ƯƠNG-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', 'B3/30H', 'KÊNH TRUNG ƯƠNG', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '0971499366', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(7, 'KH0046', NULL, 'KIM YẾN', NULL, NULL, '-NỮ DÂN CÔNG-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', '', 'NỮ DÂN CÔNG', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '0908685889', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(8, 'KH0231', NULL, 'KIM PHÁT THANH TRÀ', NULL, NULL, '-THỚI HÒA-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', '', 'THỚI HÒA', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '0981828238', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(9, 'KH0149', NULL, 'KIM PHƯỢNG', NULL, NULL, '-VĨNH LỘC A-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', '', 'VĨNH LỘC A', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '02862690339', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(10, 'KH0241', NULL, 'KIM PHÁT NGUYÊN 2', NULL, NULL, '-VÕ VĂN VÂN-X. VĨNH LỘC B-H. BÌNH CHÁNH-HCM', '', 'VÕ VĂN VÂN', 'X. VĨNH LỘC B', 'H. BÌNH CHÁNH', 'HCM', NULL, '0904345224', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(11, 'KH0030', NULL, 'KIM PHÁT NGUYÊN', NULL, NULL, '69/29-VÕ VĂN VÂN-X. VĨNH LỘC B-H. BÌNH CHÁNH-HCM', '69/29', 'VÕ VĂN VÂN', 'X. VĨNH LỘC B', 'H. BÌNH CHÁNH', 'HCM', NULL, '0907333256', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(12, 'KH0512', NULL, 'THANH TUYỀN', NULL, NULL, '-CHỢ VIỆT KIỀU-P. TÂN THÔNG HỘI-H. CỦ CHI-HCM', '', 'CHỢ VIỆT KIỀU', 'P. TÂN THÔNG HỘI', 'H. CỦ CHI', 'HCM', NULL, '0908568395', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(13, 'KH0031', NULL, 'KIM NGÂN (CỦ CHI)', NULL, NULL, '-CHỢ CỦ CHI-TT. CỦ CHI-H. CỦ CHI-HCM', '', 'CHỢ CỦ CHI', 'TT. CỦ CHI', 'H. CỦ CHI', 'HCM', NULL, '0838920379', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(14, 'KH0448', NULL, 'KIM NGÂN HỒNG PHÁT', NULL, NULL, '-CHỢ VIỆT KIỀU-TT. CỦ CHI-H. CỦ CHI-HCM', '', 'CHỢ VIỆT KIỀU', 'TT. CỦ CHI', 'H. CỦ CHI', 'HCM', NULL, '0916043775', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(15, 'KH0251', NULL, 'KIM CHÂU', NULL, NULL, '1764-TL8-X. HÒA PHÚ-H. CỦ CHI-HCM', '1764', 'TL8', 'X. HÒA PHÚ', 'H. CỦ CHI', 'HCM', NULL, '0937976309', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(16, 'KH0260', NULL, 'PHÚC HẬU', NULL, NULL, '1408-TL8-X. TÂN THẠNH ĐÔNG-H. CỦ CHI-HCM', '1408', 'TL8', 'X. TÂN THẠNH ĐÔNG', 'H. CỦ CHI', 'HCM', NULL, '0909329212', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(17, 'KH0013', NULL, 'TRẦN CHƯƠNG', NULL, NULL, '-ẤP TÂN TIẾN-X. TÂN THÔNG HỘI-H. CỦ CHI-HCM', '', 'ẤP TÂN TIẾN', 'X. TÂN THÔNG HỘI', 'H. CỦ CHI', 'HCM', NULL, '0903733225', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(18, 'KH0536', NULL, 'KIM PHÁT HOÀNG', NULL, NULL, '95-TỈNH LỘ 2-X. THƯƠNG HỘI-H. CỦ CHI-HCM', '95', 'TỈNH LỘ 2', 'X. THƯƠNG HỘI', 'H. CỦ CHI', 'HCM', NULL, '0968186236', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(19, 'KH0252', NULL, 'HOÀNG ANH 2', NULL, NULL, '207-QL22--H. CỦ CHI-HCM', '207', 'QL22', '', 'H. CỦ CHI', 'HCM', NULL, '0888684788', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(20, 'KH0211', NULL, 'MỸ VÂN', NULL, NULL, '-QL22--H. CỦ CHI-HCM', '', 'QL22', '', 'H. CỦ CHI', 'HCM', NULL, '0973 5555 79- 08 3892 2376', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(21, 'KH0012', NULL, 'KIM BẢO', NULL, NULL, '-CHỢ BÀ ĐIỂM-BÀ ĐIỂM-H. HÓC MÔN-HCM', '', 'CHỢ BÀ ĐIỂM', 'BÀ ĐIỂM', 'H. HÓC MÔN', 'HCM', NULL, '0937506999', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(22, 'KH0008', NULL, 'KIM PHÁT THÀNH DANH', NULL, NULL, '43/8F-PHAN VĂN ĐỐI-BÀ ĐIỂM-H. HÓC MÔN-HCM', '43/8F', 'PHAN VĂN ĐỐI', 'BÀ ĐIỂM', 'H. HÓC MÔN', 'HCM', NULL, '0961797501', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(23, 'KH0288', NULL, 'XUÂN DUNG ( Củ Chi)', NULL, NULL, '--TT. CỦ CHI-H. HÓC MÔN-HCM', '', '', 'TT. CỦ CHI', 'H. HÓC MÔN', 'HCM', NULL, '0985321070', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(24, 'KH0315', NULL, 'KIM PHƯỚC HÓC MÔN', NULL, NULL, '--TT. HÓC MÔN-H. HÓC MÔN-HCM', '', '', 'TT. HÓC MÔN', 'H. HÓC MÔN', 'HCM', NULL, '02837106711', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(25, 'KH0465', NULL, 'HUỲNH PHƯƠNG', NULL, NULL, '-ÂP XUÂN THỚI ĐÔNG 2-X. XUÂN THỚI THƯỢNG-H. HÓC MÔN-HCM', '', 'ÂP XUÂN THỚI ĐÔNG 2', 'X. XUÂN THỚI THƯỢNG', 'H. HÓC MÔN', 'HCM', NULL, '0786291088', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(26, 'KH0119', NULL, 'KIM PHÁT (CHỢ NHỊ XUÂN)', NULL, NULL, '1A-NGUYỄN VĂN BỨA-X. XUÂN THỚI THƯỢNG-H. HÓC MÔN-HCM', '1A', 'NGUYỄN VĂN BỨA', 'X. XUÂN THỚI THƯỢNG', 'H. HÓC MÔN', 'HCM', NULL, '0986216218', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(27, 'KH0540', NULL, 'KIM PHÁT ANH QUÂN', NULL, NULL, '75/33-TRẦN VĂN MƯỜI-X. XUÂN THỚI THƯỢNG-H. HÓC MÔN-HCM', '75/33', 'TRẦN VĂN MƯỜI', 'X. XUÂN THỚI THƯỢNG', 'H. HÓC MÔN', 'HCM', NULL, '0901282323', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(28, 'KH0335', NULL, 'THANH TUẤN MỸ LỆ', NULL, NULL, '-TRẦN VĂN MƯỜI--H. HÓC MÔN-HCM', '', 'TRẦN VĂN MƯỜI', '', 'H. HÓC MÔN', 'HCM', NULL, '0909896161', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(29, 'KH0529', NULL, 'HOÀNG PHÁT', NULL, NULL, '13/4-TRUNG LÂN--H. HÓC MÔN-HCM', '13/4', 'TRUNG LÂN', '', 'H. HÓC MÔN', 'HCM', NULL, '0979999899', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(30, 'KH0537', NULL, 'KIM CHI Q.7', NULL, NULL, '2047-HUỲNH TẤN PHÁT-TT. NHÀ BÈ-H. NHÀ BÈ-HCM', '2047', 'HUỲNH TẤN PHÁT', 'TT. NHÀ BÈ', 'H. NHÀ BÈ', 'HCM', NULL, '0937466683', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(31, 'KH0532', NULL, 'PHÚC THỊNH', NULL, NULL, '-HUỲNH TẤN PHÁT--H. NHÀ BÈ-HCM', '', 'HUỲNH TẤN PHÁT', '', 'H. NHÀ BÈ', 'HCM', NULL, '0908803082', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(32, 'KH0256', NULL, 'KIM LỘC PHÁT', NULL, NULL, '455-QL 1A-P. AN PHÚ ĐÔNG-Q. 12-HCM', '455', 'QL 1A', 'P. AN PHÚ ĐÔNG', 'Q. 12', 'HCM', NULL, '0822670670', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(33, 'KH0265', NULL, 'KIM THỊNH', NULL, NULL, '2354/1B-VƯỜN LÀI-P. AN PHÚ ĐÔNG-Q. 12-HCM', '2354/1B', 'VƯỜN LÀI', 'P. AN PHÚ ĐÔNG', 'Q. 12', 'HCM', NULL, '0937300797', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(34, 'KH0038', NULL, 'KIM PHÁT KHÁNH', NULL, NULL, '-NGUYỄN ẢNH THỦ-P. HIỆP THÀNH-Q. 12-HCM', '', 'NGUYỄN ẢNH THỦ', 'P. HIỆP THÀNH', 'Q. 12', 'HCM', NULL, '0983044733', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(35, 'KH0141', NULL, 'KIM PHÁT HẢI TOÀN', NULL, NULL, '-NGUYỄN ẢNH THỦ-P. HIỆP THÀNH-Q. 12-HCM', '', 'NGUYỄN ẢNH THỦ', 'P. HIỆP THÀNH', 'Q. 12', 'HCM', NULL, '0996141999', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(36, 'KH0372', NULL, 'TÂN KIM THỊNH', NULL, NULL, '367-HÀ HUY GIÁP-P. THẠNH LỘC-Q. 12-HCM', '367', 'HÀ HUY GIÁP', 'P. THẠNH LỘC', 'Q. 12', 'HCM', NULL, '02837196054', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(37, 'KH0175', NULL, 'KIM PHÁT KHANG TRANG', NULL, NULL, '315-TÔ NGỌC VÂN-P. THANH XUÂN-Q. 12-HCM', '315', 'TÔ NGỌC VÂN', 'P. THANH XUÂN', 'Q. 12', 'HCM', NULL, '02862771666', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(38, 'KH0487', NULL, 'KIM KIM THÀNH', NULL, NULL, '885-HẬU GIANG-P. 11-Q. 6-HCM', '885', 'HẬU GIANG', 'P. 11', 'Q. 6', 'HCM', NULL, '0944933486', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(39, 'KH0549', NULL, 'KIM KIM CHI', NULL, NULL, '1526-HUỲNH TẤN PHÁT-P. PHÚ MỸ-Q. 7-HCM', '1526', 'HUỲNH TẤN PHÁT', 'P. PHÚ MỸ', 'Q. 7', 'HCM', NULL, '02837853234', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(40, 'KH0161', NULL, 'KIM PHÁT HƯNG ( Chú hải)', NULL, NULL, '238D-NGUYỄN THỊ TÚ-P. BÌNH HƯNG HÒA B-Q. BÌNH TÂN-HCM', '238D', 'NGUYỄN THỊ TÚ', 'P. BÌNH HƯNG HÒA B', 'Q. BÌNH TÂN', 'HCM', NULL, '0909 689 908', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(41, 'KH0109', NULL, 'KIM PHÁT HỒNG', NULL, NULL, '504-QUANG TRUNG-P. 10-Q. GÒ VẤP-HCM', '504', 'QUANG TRUNG', 'P. 10', 'Q. GÒ VẤP', 'HCM', NULL, '0906661766', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(42, 'KH0478', NULL, 'KIM KHÁNH TÙNG', NULL, NULL, '579-QUANG TRUNG-P. 11-Q. GÒ VẤP-HCM', '579', 'QUANG TRUNG', 'P. 11', 'Q. GÒ VẤP', 'HCM', NULL, '0986007359', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(43, 'KH0158', NULL, 'KIM LONG 1', NULL, NULL, '-CHỢ AN NHƠN-P. 17-Q. GÒ VẤP-HCM', '', 'CHỢ AN NHƠN', 'P. 17', 'Q. GÒ VẤP', 'HCM', NULL, '02838952596', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(44, 'KH0178', NULL, 'KIM PHÁT TÂN SƠN', NULL, NULL, '-CHỢ TÂN SƠN NHẤT-P. 3-Q. GÒ VẤP-HCM', '', 'CHỢ TÂN SƠN NHẤT', 'P. 3', 'Q. GÒ VẤP', 'HCM', NULL, '01212277776', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(45, 'KH0397', NULL, 'KIM HUYỀN GÒ VẤP', NULL, NULL, '240-NGUYỄN VĂN NGHỊ-P. 7-Q. GÒ VẤP-HCM', '240', 'NGUYỄN VĂN NGHỊ', 'P. 7', 'Q. GÒ VẤP', 'HCM', NULL, '0972797814', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(46, 'KH0220', NULL, 'KIM PHÁT NHƯ HẢO', NULL, NULL, '-LÊ VĂN KHƯƠNG-P. HIỆP THÀNH-Q. GÒ VẤP-HCM', '', 'LÊ VĂN KHƯƠNG', 'P. HIỆP THÀNH', 'Q. GÒ VẤP', 'HCM', NULL, '0907373318', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(47, 'KH0270', NULL, 'HẠNH KHƯƠNG', NULL, NULL, 'KP5-CHỢ TÂN HIỆP THẠNH--Q. PHÚ NHUẬN-HCM', 'KP5', 'CHỢ TÂN HIỆP THẠNH', '', 'Q. PHÚ NHUẬN', 'HCM', NULL, '0974388734', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(48, 'KH0533', NULL, 'KIM NGUYÊN', NULL, NULL, '35-NGUYỄN SỸ SÁCH-P. 15-Q. TÂN BÌNH-HCM', '35', 'NGUYỄN SỸ SÁCH', 'P. 15', 'Q. TÂN BÌNH', 'HCM', NULL, '0908409339', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(49, 'KH0247', NULL, 'HẢI MINH', NULL, NULL, '-CHỢ TÂN BÌNH--Q. TÂN BÌNH-HCM', '', 'CHỢ TÂN BÌNH', '', 'Q. TÂN BÌNH', 'HCM', NULL, '0909964710', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(50, 'KH0244', NULL, 'KIM THỊNH PHÁT 2', NULL, NULL, '138-THOẠI NGỌC HẦU-P. HÒA THẠNH-Q. TÂN PHÚ-HCM', '138', 'THOẠI NGỌC HẦU', 'P. HÒA THẠNH', 'Q. TÂN PHÚ', 'HCM', NULL, '0919990325', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(51, 'KH0044', NULL, 'KIM MÂY', NULL, NULL, '-NGUYỄN SƠN-P. PHÚ THỌ HÒA-Q. TÂN PHÚ-HCM', '', 'NGUYỄN SƠN', 'P. PHÚ THỌ HÒA', 'Q. TÂN PHÚ', 'HCM', NULL, '0989160053', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(52, 'KH0004', NULL, 'ĐỨC BẢO (TIÊM VÀNG)', NULL, NULL, '-CHỢ TÂN HƯƠNG-P. TÂN QUÝ-Q. TÂN PHÚ-HCM', '', 'CHỢ TÂN HƯƠNG', 'P. TÂN QUÝ', 'Q. TÂN PHÚ', 'HCM', NULL, '0254089298', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(53, 'KH0002', NULL, 'KIM OANH (TIỆM VÀNG )', NULL, NULL, '196-TÂN HƯƠNG-P. TÂN QUÝ-Q. TÂN PHÚ-HCM', '196', 'TÂN HƯƠNG', 'P. TÂN QUÝ', 'Q. TÂN PHÚ', 'HCM', NULL, '083470003', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(54, 'KH0458', NULL, 'KIM THÀNH THẢO 2', NULL, NULL, '207-TÂN HƯƠNG-P. TÂN QUÝ-Q. TÂN PHÚ-HCM', '207', 'TÂN HƯƠNG', 'P. TÂN QUÝ', 'Q. TÂN PHÚ', 'HCM', NULL, '02838426771', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(55, 'KH0346', NULL, 'NAM SANG', NULL, NULL, '232A-VÕ VĂN NGÂN-P. BÌNH THỌ-Q. THỦ ĐỨC-HCM', '232A', 'VÕ VĂN NGÂN', 'P. BÌNH THỌ', 'Q. THỦ ĐỨC', 'HCM', NULL, '0982730567', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(56, 'KH0290', NULL, 'MINH NGỌC', NULL, NULL, '35-L5-TTTM RẠCH SỎI-P. RẠCH SỎI-TP. RẠCH GIÁ-KIÊN GIANG', '35-L5', 'TTTM  RẠCH SỎI', 'P. RẠCH SỎI', 'TP. RẠCH GIÁ', 'KIÊN GIANG', NULL, '0919163772', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(57, 'KH0292', NULL, 'PHÚ CƯỜNG', NULL, NULL, '-ẤP KHỞI HÀ-X. CẦU KHỞI-H. DƯƠNG MINH CHÂU-TÂY NINH', '', 'ẤP KHỞI HÀ', 'X. CẦU KHỞI', 'H. DƯƠNG MINH CHÂU', 'TÂY NINH', NULL, '02763773827', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(58, 'KH0295', NULL, 'HƯNG THỜI', NULL, NULL, '-ĐT 784-X. CHÀ LÀ-H. DƯƠNG MINH CHÂU-TÂY NINH', '', 'ĐT 784', 'X. CHÀ LÀ', 'H. DƯƠNG MINH CHÂU', 'TÂY NINH', NULL, '0908610646', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(59, 'KH0356', NULL, 'TIÊN (Tây Ninh)', NULL, NULL, '532-CHỢ TRUÔNG MÍT-X. TRUÔNG MÍT-H. DƯƠNG MINH CHÂU-TÂY NINH', '532', 'CHỢ TRUÔNG MÍT', 'X. TRUÔNG MÍT', 'H. DƯƠNG MINH CHÂU', 'TÂY NINH', NULL, '01669810874', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(60, 'KH0274', NULL, 'NGỌC ÚT', NULL, NULL, '-THUẬN AN-X. TRUÔNG MÍT-H. DƯƠNG MINH CHÂU-TÂY NINH', '', 'THUẬN AN', 'X. TRUÔNG MÍT', 'H. DƯƠNG MINH CHÂU', 'TÂY NINH', NULL, '0906303536', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(61, 'KH0259', NULL, 'KIM CÚC (Tây Ninh)', NULL, NULL, '189-ẤP 2-X. BẦU ĐỒN-H. GÒ DẦU-TÂY NINH', '189', 'ẤP 2', 'X. BẦU ĐỒN', 'H. GÒ DẦU', 'TÂY NINH', NULL, '01633333773', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(62, 'KH0275', NULL, 'KIM PHỤNG', NULL, NULL, '--X. PHƯỚC ĐÔNG-H. GÒ DẦU-TÂY NINH', '', '', 'X. PHƯỚC ĐÔNG', 'H. GÒ DẦU', 'TÂY NINH', NULL, '0663534243', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(63, 'KH0282', NULL, 'NGỌC LỆ', NULL, NULL, '--X. PHƯỚC ĐÔNG-H. GÒ DẦU-TÂY NINH', '', '', 'X. PHƯỚC ĐÔNG', 'H. GÒ DẦU', 'TÂY NINH', NULL, '01679926373', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(64, 'KH0387', NULL, 'KIM THỦY', NULL, NULL, '-CHỢ THẠNH ĐỨC-X. THẠNH ĐỨC-H. GÒ DẦU-TÂY NINH', '', 'CHỢ THẠNH ĐỨC', 'X. THẠNH ĐỨC', 'H. GÒ DẦU', 'TÂY NINH', NULL, '0938949959', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(65, 'KH0279', NULL, 'QUỐC THỊNH PHÁT', NULL, NULL, 'C80-NGUYỄN VĂN LINH-X. LONG THÀNH BẮC-H. HÒA THÀNH-TÂY NINH', 'C80', 'NGUYỄN VĂN LINH', 'X. LONG THÀNH BẮC', 'H. HÒA THÀNH', 'TÂY NINH', NULL, '0907859653', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(66, 'KH0357', NULL, 'KIM DUNG', NULL, NULL, '-CHỢ TRƯỜNG LƯU-X. TRƯỜNG ĐÔNG-H. HÒA THÀNH-TÂY NINH', '', 'CHỢ TRƯỜNG LƯU', 'X. TRƯỜNG ĐÔNG', 'H. HÒA THÀNH', 'TÂY NINH', NULL, '0983977520', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(67, 'KH0541', NULL, 'KIM MINH 2', NULL, NULL, 'TỔ 10-KP1-TT. TÂN CHÂU-H. TÂN CHÂU-TÂY NINH', 'TỔ 10', 'KP1', 'TT. TÂN CHÂU', 'H. TÂN CHÂU', 'TÂY NINH', NULL, '0983975287', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(68, 'KH0523', NULL, 'KIM MINH TÂN CHÂU', NULL, NULL, '--TT. TÂN CHÂU-H. TÂN CHÂU-TÂY NINH', '', '', 'TT. TÂN CHÂU', 'H. TÂN CHÂU', 'TÂY NINH', NULL, '0976248669', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(69, 'KH0522', NULL, 'KIM LONG TÂN CHÂU', NULL, NULL, '--TT. TÂN CHÂU-H. TÂN CHÂU-TÂY NINH', '', '', 'TT. TÂN CHÂU', 'H. TÂN CHÂU', 'TÂY NINH', NULL, '0333416522', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(70, 'KH0369', NULL, 'KIM HỮU 2', NULL, NULL, '134-TRƯNG NỮ VƯƠNG-TT. CÁI BÈ-H. CÁI BÈ-TIỀN GIANG', '134', 'TRƯNG NỮ VƯƠNG', 'TT. CÁI BÈ', 'H. CÁI BÈ', 'TIỀN GIANG', NULL, '0913824393', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(71, 'KH0359', NULL, 'KIM HỮU', NULL, NULL, '181-TRƯNG NỮ VƯƠNG-TT. CÁI BÈ-H. CÁI BÈ-TIỀN GIANG', '181', 'TRƯNG NỮ VƯƠNG', 'TT. CÁI BÈ', 'H. CÁI BÈ', 'TIỀN GIANG', NULL, '0933697339', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(72, 'KH0358', NULL, 'KIM LOAN PHƯỢNG', NULL, NULL, '205-TRƯNG NỮ VƯƠNG-TT. CÁI BÈ-H. CÁI BÈ-TIỀN GIANG', '205', 'TRƯNG NỮ VƯƠNG', 'TT. CÁI BÈ', 'H. CÁI BÈ', 'TIỀN GIANG', NULL, '0908778736', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(73, 'KH0490', NULL, 'KIM HƯNG', NULL, NULL, '245-ẤP 4-X. AN HỮU-H. CÁI BÈ-TIỀN GIANG', '245', 'ẤP 4', 'X. AN HỮU', 'H. CÁI BÈ', 'TIỀN GIANG', NULL, '02733767676', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(74, 'KH0355', NULL, 'KIM PHƯỢNG ( Cai Lậy)', NULL, NULL, '-CHỢ CAI LẬY-TT. CAI LẬY-H. CAI LẬY-TIỀN GIANG', '', 'CHỢ CAI LẬY', 'TT. CAI LẬY', 'H. CAI LẬY', 'TIỀN GIANG', NULL, '0983977520', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(75, 'KH0430', NULL, 'KIM PHƯỢNG 3 (Cai Lậy)', NULL, NULL, '-ĐƯỜNG 808-P. 1-TX. CAI LẬY-TIỀN GIANG', '', 'ĐƯỜNG 808', 'P. 1', 'TX. CAI LẬY', 'TIỀN GIANG', NULL, '01633366975', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(76, 'KH0263', NULL, 'TRI ÂN', NULL, NULL, '38-TRƯƠNG ĐỊNH--TX. GÒ CÔNG-TIỀN GIANG', '38', 'TRƯƠNG ĐỊNH', '', 'TX. GÒ CÔNG', 'TIỀN GIANG', NULL, '02733841828', 2, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(77, 'KH0557', NULL, 'KIM TẤN LỘC- CÔ DIỆU', NULL, NULL, '5-ĐƯỜNG N5--TX. BẾN CÁT-BÌNH DƯƠNG', '5', 'ĐƯỜNG N5', '', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0909979362', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(78, 'KH0182', NULL, 'KIM HUYỀN TIẾN ( CHÚ LÂM)', NULL, NULL, '300-NGUYỄN AN NINH-KP BÌNH MINH 1-TX. DĨ AN-BÌNH DƯƠNG', '300', 'NGUYỄN AN NINH', 'KP BÌNH MINH 1', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0948054805', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(79, 'KH0218', NULL, 'KIM THÀNH', NULL, NULL, '--P. AN BÌNH-TX. DĨ AN-BÌNH DƯƠNG', '', '', 'P. AN BÌNH', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '023822670670', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(80, 'KH0172', NULL, 'KIM HUYỀN TƯỜNG VY', NULL, NULL, '-ĐƯỜNG MỒI--TX. DĨ AN-BÌNH DƯƠNG', '', 'ĐƯỜNG MỒI', '', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '01234313579', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(81, 'KH0291', NULL, 'KIM CƯƠNG THÁI', NULL, NULL, '286-NGUYỄN AN NINH--TX. DĨ AN-BÌNH DƯƠNG', '286', 'NGUYỄN AN NINH', '', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0933431347', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(82, 'KH0520', NULL, 'KIM HẠNH PHÚC', NULL, NULL, '56-NGUYỄN AN NINH--TX. DĨ AN-BÌNH DƯƠNG', '56', 'NGUYỄN AN NINH', '', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0932806700', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(83, 'KH0257', NULL, 'KIM HUYỀN TƯỜNG VY 2', NULL, NULL, '-NGUYỄN TRÃI--TX. DĨ AN-BÌNH DƯƠNG', '', 'NGUYỄN TRÃI', '', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0918473009', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(84, 'KH0544', NULL, 'PHÚC ĐẠT', NULL, NULL, '88-NGUYỄN TRÃI--TX. DĨ AN-BÌNH DƯƠNG', '88', 'NGUYỄN TRÃI', '', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0907554086', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(85, 'KH0185', NULL, 'KIM THÀNH LÂM ( chú lâm)', NULL, NULL, '---TX. TÂN UYÊN-BÌNH DƯƠNG', '', '', '', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0933802927', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(86, 'KH0525', NULL, 'KIM GIAO', NULL, NULL, 'KIOT 34-NGÔ SĨ LIÊN - CHỢ PHAN THIẾT-P. ĐỨC NGHĨA-TP. PHAN THIẾT-BÌNH THUẬN', 'KIOT 34', 'NGÔ SĨ LIÊN - CHỢ PHAN THIẾT', 'P. ĐỨC NGHĨA', 'TP. PHAN THIẾT', 'BÌNH THUẬN', NULL, '0938197897', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(87, 'KH0223', NULL, 'PHÁT NGỌC - PHAN THIẾT', NULL, NULL, '24/7-LÊ VĂN PHẤN-P. PHÚ THỦY-TP. PHAN THIẾT-BÌNH THUẬN', '24/7', 'LÊ VĂN PHẤN', 'P. PHÚ THỦY', 'TP. PHAN THIẾT', 'BÌNH THUẬN', NULL, '0914142949', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(88, 'KH0547', NULL, 'KIM YẾN- PHAN THIẾT', NULL, NULL, '445-ĐƯỜNG THỐNG NHẤT-P. TÂN AN-TX. LAGI-BÌNH THUẬN', '445', 'ĐƯỜNG THỐNG NHẤT', 'P. TÂN AN', 'TX. LAGI', 'BÌNH THUẬN', NULL, '0898662066', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(89, 'KH0311', NULL, 'TOÀN HẰNG', NULL, NULL, '-TỔ 10 - THÔN 3-X. NHÂN CƠ-H. ĐẮC R\'LẤP-ĐẮC NÔNG', '', 'TỔ 10 - THÔN 3', 'X. NHÂN CƠ', 'H. ĐẮC R\'LẤP', 'ĐẮC NÔNG', NULL, '0903549699', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(90, 'KH0439', NULL, 'DIỄM KIỀU', NULL, NULL, '--X. PHƯỚC THIỆN-H. NHƠN TRẠCH-ĐỒNG NAI', '', '', 'X. PHƯỚC THIỆN', 'H. NHƠN TRẠCH', 'ĐỒNG NAI', NULL, '02513540734', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(91, 'KH0170', NULL, 'KIM CÚC', NULL, NULL, 'C3/3-NỮ DÂN CÔNG-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', 'C3/3', 'NỮ DÂN CÔNG', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '0989296939', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(92, 'KH0206', NULL, 'KIM PHÁT A BÔN (Chú lâm)', NULL, NULL, '705-NGUYỄN VĂN TẠO-P. PHƯỚC KIỂN-H. NHÀ BÈ-HCM', '705', 'NGUYỄN VĂN TẠO', 'P. PHƯỚC KIỂN', 'H. NHÀ BÈ', 'HCM', NULL, '0979 093 093', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(93, 'KH0545', NULL, 'KIM QUYÊN PHÁT', NULL, NULL, '816-NGUYỄN VĂN TẠO-X. HIỆP PHƯỚC-H. NHÀ BÈ-HCM', '816', 'NGUYỄN VĂN TẠO', 'X. HIỆP PHƯỚC', 'H. NHÀ BÈ', 'HCM', NULL, '0986826868', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(94, 'KH0313', NULL, 'TUYẾT DUNG', NULL, NULL, '-CHỢ BẾN THÀNH-P. BẾN THÀNH-Q. 1-HCM', '', 'CHỢ BẾN THÀNH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(95, 'KH0298', NULL, 'CÔ THƯ (Hiếu Nhân)', NULL, NULL, '-CHỢ BẾN THÀNH-P. BẾN THÀNH-Q. 1-HCM', '', 'CHỢ BẾN THÀNH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(96, 'KH0226', NULL, 'HIẾU NHÂN 2 (CHỊ THANH)', NULL, NULL, '-CHỢ BẾN THÀNH-P. BẾN THÀNH-Q. 1-HCM', '', 'CHỢ BẾN THÀNH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(97, 'KH0225', NULL, 'KIM LỘC BẾN THÀNH (CÔ LỘC)', NULL, NULL, '-CHỢ BẾN THÀNH-P. BẾN THÀNH-Q. 1-HCM', '', 'CHỢ BẾN THÀNH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(98, 'KH0144', NULL, 'HỮU LỢI', NULL, NULL, '-CHỢ BẾN THÀNH-P. BẾN THÀNH-Q. 1-HCM', '', 'CHỢ BẾN THÀNH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(99, 'KH0010', NULL, 'NGỌC ANH (TIỆM VÀNG )', NULL, NULL, '-CỬA TÂY CHỢ BẾN THÀNH-P. BẾN THÀNH-Q. 1-HCM', '', 'CỬA TÂY CHỢ BẾN THÀNH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '01682270307', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(100, 'KH0095', NULL, 'MINH DIỆP', NULL, NULL, '178-LÊ THÁNH TÔN-P. BẾN THÀNH-Q. 1-HCM', '178', 'LÊ THÁNH TÔN', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '0908540526', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(101, 'KH0515', NULL, 'KARA JEWELRY', NULL, NULL, '-LÊ THÁNH TÔN-P. BẾN THÀNH-Q. 1-HCM', '', 'LÊ THÁNH TÔN', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(102, 'KH0396', NULL, 'THIÊN HỒNG', NULL, NULL, '8B-PHẠM NGŨ LÃO-P. BẾN THÀNH-Q. 1-HCM', '8B', 'PHẠM NGŨ LÃO', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '0902804053', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(103, 'KH0033', NULL, 'KIM LỘC 2(CÔ TRINH)', NULL, NULL, '-PHAN BỘI CHÂU-P. BẾN THÀNH-Q. 1-HCM', '', 'PHAN BỘI CHÂU', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '0906378286', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(104, 'KH0096', NULL, 'MỸ TÍN THỊNH', NULL, NULL, '30-36-PHAN BỘI CHÂU-P. BẾN THÀNH-Q. 1-HCM', '30-36', 'PHAN BỘI CHÂU', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(105, 'KH0097', NULL, 'NGÂN CHÂU', NULL, NULL, '30-36-PHAN BỘI CHÂU-P. BẾN THÀNH-Q. 1-HCM', '30-36', 'PHAN BỘI CHÂU', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(106, 'KH0102', NULL, 'LAN THUẬN', NULL, NULL, '30-36-PHAN BỘI CHÂU-P. BẾN THÀNH-Q. 1-HCM', '30-36', 'PHAN BỘI CHÂU', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(107, 'KH0164', NULL, 'SG KIM TÍN ', NULL, NULL, '56-58-PHAN BỘI CHÂU-P. BẾN THÀNH-Q. 1-HCM', '56-58', 'PHAN BỘI CHÂU', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '0912141824', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(108, 'KH0006', NULL, 'CHỊ GẤM', NULL, NULL, '-PHAN BỘI CHÂU-P. BẾN THÀNH-Q. 1-HCM', '', 'PHAN BỘI CHÂU', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '0906378286', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(109, 'KH0255', NULL, 'CÔ TUYẾT VĨNH THÀNH PHÁT', NULL, NULL, '7-PHAN CHÂU TRINH-P. BẾN THÀNH-Q. 1-HCM', '7', 'PHAN CHÂU TRINH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(110, 'KH0011', NULL, 'HIẾU NHÂN(BẢO NGỌC)', NULL, NULL, '5-PHAN CHÂU TRINH-P. BẾN THÀNH-Q. 1-HCM', '5', 'PHAN CHÂU TRINH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '0238277158', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(111, 'KH0246', NULL, 'HÙNG VĨNH THÀNH PHÁT', NULL, NULL, '-PHAN CHÂU TRINH-P. BẾN THÀNH-Q. 1-HCM', '', 'PHAN CHÂU TRINH', 'P. BẾN THÀNH', 'Q. 1', 'HCM', NULL, '0903975245', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(112, 'KH0531', NULL, 'TÂN PHÚC THỊNH', NULL, NULL, '90-NGUYỄN HỮU CẦU-P. TÂN ĐỊNH-Q. 1-HCM', '90', 'NGUYỄN HỮU CẦU', 'P. TÂN ĐỊNH', 'Q. 1', 'HCM', NULL, '0903777653', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(113, 'KH0056', NULL, 'CHỊ NGA KIM THÀNH', NULL, NULL, '87-TÔ HIẾN THÀNH-P. 13-Q. 10-HCM', '87', 'TÔ HIẾN THÀNH', 'P. 13', 'Q. 10', 'HCM', NULL, '0903669429', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(114, 'KH0151', NULL, 'QUAN KIM PHÁT', NULL, NULL, '-TÔN THẤT THIỆP-P. BÌNH THỚI-Q. 11-HCM', '', 'TÔN THẤT THIỆP', 'P. BÌNH THỚI', 'Q. 11', 'HCM', NULL, '0239628372-5406788', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(115, 'KH0087', NULL, 'KIM PHƯỚC TÍN (CHÚ PHƯỚC)', NULL, NULL, '23H3-NGUYỄN ẢNH THỦ-P. HIỆP THÀNH-Q. 12-HCM', '23H3', 'NGUYỄN ẢNH THỦ', 'P. HIỆP THÀNH', 'Q. 12', 'HCM', NULL, '0906650440', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(116, 'KH0301', NULL, 'KIM KHÁNH DUNG', NULL, NULL, '168-NGUYỄN DUY TRINH--Q. 2-HCM', '168', 'NGUYỄN DUY TRINH', '', 'Q. 2', 'HCM', NULL, '0909978939', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(117, 'KH0074', NULL, 'TIỆM VÀNG LAN NGỌC', NULL, NULL, '25C-LÊ VĂN SỸ-P. 13-Q. 3-HCM', '25C', 'LÊ VĂN SỸ', 'P. 13', 'Q. 3', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(118, 'KH0146', NULL, 'KIM MINH TÂM(CHỊ THUỶ)', NULL, NULL, '60-CHỢ PHÚ LÂM-P.13-Q. 6-HCM', '60', 'CHỢ PHÚ LÂM', 'P.13', 'Q. 6', 'HCM', NULL, '0907689689', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(119, 'KH0156', NULL, 'MINH TÂM ( HIẾU)', NULL, NULL, '60-CHỢ PHÚ LÂM-P.13-Q. 6-HCM', '60', 'CHỢ PHÚ LÂM', 'P.13', 'Q. 6', 'HCM', NULL, '0937689689', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(120, 'KH0195', NULL, 'NGỌC CỦA ( C LÂM)', NULL, NULL, '43-LÊ VĂN LƯƠNG-P. TÂN KIỂNG-Q. 7-HCM', '43', 'LÊ VĂN LƯƠNG', 'P. TÂN KIỂNG', 'Q. 7', 'HCM', NULL, '02837712320', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(121, 'KH0207', NULL, 'KIM PHÁT A LINH ( Chú lâm)', NULL, NULL, '-BÙI VĂN BA--Q. 7-HCM', '', 'BÙI VĂN BA', '', 'Q. 7', 'HCM', NULL, '0935080578', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(122, 'KH0324', NULL, 'NGỌC THU', NULL, NULL, '1514A-HUỲNH TẤN PHÁT--Q. 7-HCM', '1514A', 'HUỲNH TẤN PHÁT', '', 'Q. 7', 'HCM', NULL, '0913648939', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(123, 'KH0053', NULL, 'KIM HOÀNG NHUNG', NULL, NULL, '197-BÙI MINH TRỰC-P. 5-Q. 8-HCM', '197', 'BÙI MINH TRỰC', 'P. 5', 'Q. 8', 'HCM', NULL, '0903995057', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(124, 'KH0491', NULL, 'KIM PHÚC', NULL, NULL, '-BÌNH THẠNH-P. BÌNH HƯNG HÒA-Q. BÌNH TÂN-HCM', '', 'BÌNH THẠNH', 'P. BÌNH HƯNG HÒA', 'Q. BÌNH TÂN', 'HCM', NULL, '0918761650', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(125, 'KH0510', NULL, 'HỒNG PHÁT', NULL, NULL, '99-PHẠM ĐĂNG GIẢNG-P. BÌNH HƯNG HÒA A-Q. BÌNH TÂN-HCM', '99', 'PHẠM ĐĂNG GIẢNG', 'P. BÌNH HƯNG HÒA A', 'Q. BÌNH TÂN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(126, 'KH0507', NULL, 'KIM THÀNH 4 XA', NULL, NULL, '-NGÃ TƯ 4 XÃ-P. BÌNH TRỊ ĐÔNG-Q. BÌNH TÂN-HCM', '', 'NGÃ TƯ 4 XÃ', 'P. BÌNH TRỊ ĐÔNG', 'Q. BÌNH TÂN', 'HCM', NULL, '0987131467', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(127, 'KH0057', NULL, 'KIM HƯNG THÀNH (ANH ĐỒNG)', NULL, NULL, '-TL 10-P. BÌNH TRỊ ĐÔNG B-Q. BÌNH TÂN-HCM', '', 'TL 10', 'P. BÌNH TRỊ ĐÔNG B', 'Q. BÌNH TÂN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(128, 'KH0526', NULL, 'KIM HƯNG ( bình Tân)', NULL, NULL, '30-LỘ TẺ-P. TÂN TẠO-Q. BÌNH TÂN-HCM', '30', 'LỘ TẺ', 'P. TÂN TẠO', 'Q. BÌNH TÂN', 'HCM', NULL, '0834632424', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(129, 'KH0103', NULL, 'LOAN THẢO', NULL, NULL, '7-HỒNG BÀNG-P. 1-Q. BÌNH THẠNH-HCM', '7', 'HỒNG BÀNG', 'P. 1', 'Q. BÌNH THẠNH', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(130, 'KH0148', NULL, 'KIM PHÁT NGỌC (GÒ VẤP)', NULL, NULL, '579-QUANG TRUNG-P. 11-Q. GÒ VẤP-HCM', '579', 'QUANG TRUNG', 'P. 11', 'Q. GÒ VẤP', 'HCM', NULL, '0986007359', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(131, 'KH0017', NULL, 'KIM THÀNH GÒ VẤP', NULL, NULL, '236-238-NGUYỄN VĂN NGHỊ-P. 7-Q. GÒ VẤP-HCM', '236-238', 'NGUYỄN VĂN NGHỊ', 'P. 7', 'Q. GÒ VẤP', 'HCM', NULL, '    0903096025 -  0903604670', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(132, 'KH0055', NULL, 'KIM PHÁT 1 (CHÚ CHÁNH)', NULL, NULL, '206-NGUYỄN VĂN NGHỊ-P. 7-Q. GÒ VẤP-HCM', '206', 'NGUYỄN VĂN NGHỊ', 'P. 7', 'Q. GÒ VẤP', 'HCM', NULL, '0908392182', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(133, 'KH0085', NULL, 'KIM PHÁT GÒ VẤP (A VƯƠNG)', NULL, NULL, '224-NGUYỄN VĂN NGHỊ-P. 7-Q. GÒ VẤP-HCM', '224', 'NGUYỄN VĂN NGHỊ', 'P. 7', 'Q. GÒ VẤP', 'HCM', NULL, '0903010627', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(134, 'KH0024', NULL, 'CHỊ THƯ KIM THÀNH', NULL, NULL, '40-HOÀNG HOA THÁM-P. 13-Q. TÂN BÌNH-HCM', '40', 'HOÀNG HOA THÁM', 'P. 13', 'Q. TÂN BÌNH', 'HCM', NULL, '0908119246', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(135, 'KH0115', NULL, 'KIM LINH_CHÚ LÂM', NULL, NULL, '218-NGUYỄN HỒNG ĐÀO-P. 14-Q. TÂN BÌNH-HCM', '218', 'NGUYỄN HỒNG ĐÀO', 'P. 14', 'Q. TÂN BÌNH', 'HCM', NULL, '905109688', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(136, 'KH0032', NULL, 'TOÀN KIM THÀNH (CHỊ LINH)', NULL, NULL, '545-TRƯỜNG CHINH-P. 14-Q. TÂN BÌNH-HCM', '545', 'TRƯỜNG CHINH', 'P. 14', 'Q. TÂN BÌNH', 'HCM', NULL, '0238425369', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(137, 'KH0524', NULL, 'BẢO TÍN 1', NULL, NULL, '865-867-CÁCH MẠNG THÁNG 8--Q. TÂN BÌNH-HCM', '865-867', 'CÁCH MẠNG THÁNG 8', '', 'Q. TÂN BÌNH', 'HCM', NULL, '0908212515', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(138, 'KH0300', NULL, 'KIM HOÀN MỸ ( chú Lâm)', NULL, NULL, '---Q. TÂN PHÚ-HCM', '', '', '', 'Q. TÂN PHÚ', 'HCM', NULL, '0976855779', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(139, 'KH0233', NULL, 'KIM THÀNH PHƯƠNG', NULL, NULL, '----HCM', '', '', '', '', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(140, 'KH0025', NULL, 'CÔ LOAN', NULL, NULL, '---TP. QUẢNG NGÃI-QUẢNG NGÃI', '', '', '', 'TP. QUẢNG NGÃI', 'QUẢNG NGÃI', NULL, '0909828582', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(141, 'KH0111', NULL, 'CHÚ LUẬT', NULL, NULL, '---TP. QUẢNG NGÃI-QUẢNG NGÃI', '', '', '', 'TP. QUẢNG NGÃI', 'QUẢNG NGÃI', NULL, '0903644051', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(142, 'KH0331', NULL, 'KIM NAM', NULL, NULL, '---H. BẾN CÁT-BÌNH DƯƠNG', '', '', '', 'H. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0913950027', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(143, 'KH0328', NULL, 'KIM CHI A8', NULL, NULL, '---H. DẦU TIẾNG-BÌNH DƯƠNG', '', '', '', 'H. DẦU TIẾNG', 'BÌNH DƯƠNG', NULL, '0938159399', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(144, 'KH0373', NULL, 'BẢO NGỌC', NULL, NULL, '---H. DẦU TIẾNG-BÌNH DƯƠNG', '', '', '', 'H. DẦU TIẾNG', 'BÌNH DƯƠNG', NULL, '0965549028', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(145, 'KH0307', NULL, 'KIM HUYỀN VŨ', NULL, NULL, 'DB08-KP3-P. MỸ PHƯỚC-TX. BẾN CÁT-BÌNH DƯƠNG', 'DB08', 'KP3', 'P. MỸ PHƯỚC', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0982123859', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(146, 'KH0338', NULL, 'KIM TUYẾT', NULL, NULL, '---TX. BẾN CÁT-BÌNH DƯƠNG', '', '', '', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0919908070', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(147, 'KH0262', NULL, 'KIM THÀNH HẢI NAM', NULL, NULL, '79-ĐƯỜNG D1-KDC ĐÔNG AN-TX. DĨ AN-BÌNH DƯƠNG', '79', 'ĐƯỜNG D1', 'KDC ĐÔNG AN', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0986592892', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(148, 'KH0278', NULL, 'KIM THÀNH AN BÌNH 1', NULL, NULL, '-NGUYỄN TRI PHƯƠNG-P. AN BÌNH-TX. DĨ AN-BÌNH DƯƠNG', '', 'NGUYỄN TRI PHƯƠNG', 'P. AN BÌNH', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0902578579', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(149, 'KH0347', NULL, 'KIM THÀNH VŨ', NULL, NULL, '-KP2-P. TÂN BÌNH-TX. DĨ AN-BÌNH DƯƠNG', '', 'KP2', 'P. TÂN BÌNH', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0905550795', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(150, 'KH0222', NULL, 'KIM BÌNH', NULL, NULL, '-LÊ ĐỘ-P. CHÍNH GIÁNG-Q. SƠN TRÀ-ĐÀ NẴNG', '', 'LÊ ĐỘ', 'P. CHÍNH GIÁNG', 'Q. SƠN TRÀ', 'ĐÀ NẴNG', NULL, '0903122240', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(151, 'KH0459', NULL, 'KIM PHÁT THUẬN ĐẠT', NULL, NULL, 'F41/68-ẤP 6 - LIÊN ẤP 26-X. HƯNG LONG-H. BÌNH CHÁNH-HCM', 'F41/68', 'ẤP 6 - LIÊN ẤP 26', 'X. HƯNG LONG', 'H. BÌNH CHÁNH', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(152, 'KH0071', NULL, 'KIM THÀNH BÀ LÁT', NULL, NULL, '1A90-ẤP 1-X. PHẠM VĂN HAI-H. BÌNH CHÁNH-HCM', '1A90', 'ẤP 1', 'X. PHẠM VĂN HAI', 'H. BÌNH CHÁNH', 'HCM', NULL, '0933553792', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(153, 'KH0367', NULL, 'KIM NGỌC THẢO', NULL, NULL, '2254-VĨNH LỘC-X. VĨNH LỘC-H. BÌNH CHÁNH-HCM', '2254', 'VĨNH LỘC', 'X. VĨNH LỘC', 'H. BÌNH CHÁNH', 'HCM', NULL, '0988157580', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(154, 'KH0240', NULL, 'KIM THÀNH VĨNH LỘC', NULL, NULL, 'F7/6A-ẤP 6-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', 'F7/6A', 'ẤP 6', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '0837655322-0909.554.040', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(155, 'KH0219', NULL, 'KIM PHÁT BẢO AN', NULL, NULL, 'E12/29A1-QUÁCH ĐIÊU-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', 'E12/29A1', 'QUÁCH ĐIÊU', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '0908097857', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(156, 'KH0467', NULL, 'KIM THỊNH (Vĩnh Lộc)', NULL, NULL, '-VÕ VĂN VÂN-X. VĨNH LỘC B-H. BÌNH CHÁNH-HCM', '', 'VÕ VĂN VÂN', 'X. VĨNH LỘC B', 'H. BÌNH CHÁNH', 'HCM', NULL, '0903904212', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(157, 'KH0268', NULL, 'PHƯƠNG DUNG QUỐC VINH', NULL, NULL, '-CHỢ VIỆT KIỀU-P. TÂN THÔNG HỘI-H. CỦ CHI-HCM', '', 'CHỢ VIỆT KIỀU', 'P. TÂN THÔNG HỘI', 'H. CỦ CHI', 'HCM', NULL, '0906995659', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(158, 'KH0253', NULL, 'PHƯƠNG THÙY', NULL, NULL, '131-NGUYỄN VĂN KHẠ-TT. CỦ CHI-H. CỦ CHI-HCM', '131', 'NGUYỄN VĂN KHẠ', 'TT. CỦ CHI', 'H. CỦ CHI', 'HCM', NULL, '0918181577', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(159, 'KH0229', NULL, 'KIM PHÁT TÂN QUY', NULL, NULL, '-TỈNH LỘ 8-X. TÂN AN HỘI-H. CỦ CHI-HCM', '', 'TỈNH LỘ 8', 'X. TÂN AN HỘI', 'H. CỦ CHI', 'HCM', NULL, '0822670670', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(160, 'KH0191', NULL, 'KIM NGỌC THI', NULL, NULL, '114-QUỐC LỘ 22-X. TÂN PHÚ TRUNG-H. CỦ CHI-HCM', '114', 'QUỐC LỘ 22', 'X. TÂN PHÚ TRUNG', 'H. CỦ CHI', 'HCM', NULL, '0909907151', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(161, 'KH0272', NULL, 'ÁNH HẰNG', NULL, NULL, '-TL8-X. TÂN THẠNH ĐÔNG-H. CỦ CHI-HCM', '', 'TL8', 'X. TÂN THẠNH ĐÔNG', 'H. CỦ CHI', 'HCM', NULL, '0907517807', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(162, 'KH0383', NULL, 'KIM PHÁT KIỀU VY', NULL, NULL, '-ẤP 1-X. TÂN THẠNH TÂY-H. CỦ CHI-HCM', '', 'ẤP 1', 'X. TÂN THẠNH TÂY', 'H. CỦ CHI', 'HCM', NULL, '0906691974', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(163, 'KH0242', NULL, 'KIM PHÁT TÂN AN', NULL, NULL, '213C-NGUYỄN VĂN KHẠ--H. CỦ CHI-HCM', '213C', 'NGUYỄN VĂN KHẠ', '', 'H. CỦ CHI', 'HCM', NULL, '0935608094', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(164, 'KH0077', NULL, 'KIM THIỆN PHÁT', NULL, NULL, '2/4-ĐẶNG THÚC VỊNH-ẤP TAM ĐÔNG-H. HÓC MÔN-HCM', '2/4', 'ĐẶNG THÚC VỊNH', 'ẤP TAM ĐÔNG', 'H. HÓC MÔN', 'HCM', NULL, '0905972779', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(165, 'KH0068', NULL, 'KIM PHÁT TỨ', NULL, NULL, '-ĐẶNG THÚC VỊNH-ẤP TAM ĐÔNG-H. HÓC MÔN-HCM', '', 'ĐẶNG THÚC VỊNH', 'ẤP TAM ĐÔNG', 'H. HÓC MÔN', 'HCM', NULL, '0969244979', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(166, 'KH0135', NULL, 'KIM PHÁT MINH HỒNG', NULL, NULL, '-PHAN VĂN HỚN-P. TÂN THỚI NHẤT-H. HÓC MÔN-HCM', '', 'PHAN VĂN HỚN', 'P. TÂN THỚI NHẤT', 'H. HÓC MÔN', 'HCM', NULL, '0903778172', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(167, 'KH0289', NULL, 'KIM LÝ ĐĂNG', NULL, NULL, '--TT. CỦ CHI-H. HÓC MÔN-HCM', '', '', 'TT. CỦ CHI', 'H. HÓC MÔN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(168, 'KH0173', NULL, 'KIM PHÁT ĐÔNG THẠNH', NULL, NULL, '172A-ĐẶNG THÚ VỊNH-X. ĐÔNG THẠNH-H. HÓC MÔN-HCM', '172A', 'ĐẶNG THÚ VỊNH', 'X. ĐÔNG THẠNH', 'H. HÓC MÔN', 'HCM', NULL, '0984217979', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(169, 'KH0449', NULL, 'THÔNG PHƯƠNG', NULL, NULL, '90-TRẦN VĂN MƯỜI-X. TÂN THỚI ĐÔNG-H. HÓC MÔN-HCM', '90', 'TRẦN VĂN MƯỜI', 'X. TÂN THỚI ĐÔNG', 'H. HÓC MÔN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(170, 'KH0169', NULL, 'LONG PHỤNG', NULL, NULL, '-QL22 - NGÃ 4 TRUNG CHÁNH-X. XUÂN THỚI ĐÔNG-H. HÓC MÔN-HCM', '', 'QL22 - NGÃ 4 TRUNG CHÁNH', 'X. XUÂN THỚI ĐÔNG', 'H. HÓC MÔN', 'HCM', NULL, '0837183666', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(171, 'KH0047', NULL, 'KIM PHÁT NHI', NULL, NULL, '-NGUYỄN VĂN BỨA-X. XUÂN THỚI THƯỢNG-H. HÓC MÔN-HCM', '', 'NGUYỄN VĂN BỨA', 'X. XUÂN THỚI THƯỢNG', 'H. HÓC MÔN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(172, 'KH0157', NULL, 'KIM PHÁT AN', NULL, NULL, '-NGUYỄN THỊ MẾN--H. HÓC MÔN-HCM', '', 'NGUYỄN THỊ MẾN', '', 'H. HÓC MÔN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(173, 'KH0072', NULL, 'KIM PHÁT BẢO', NULL, NULL, '---H. HÓC MÔN-HCM', '', '', '', 'H. HÓC MÔN', 'HCM', NULL, '0983977019', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(174, 'KH0499', NULL, 'KIM PHÚC THỊNH', NULL, NULL, '883-NGUYỄN VĂN TẠO-X. HIỆP PHƯỚC-H. NHÀ BÈ-HCM', '883', 'NGUYỄN VĂN TẠO', 'X. HIỆP PHƯỚC', 'H. NHÀ BÈ', 'HCM', NULL, '0903997470', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(175, 'KH0070', NULL, 'KIM NGỌC NỮ', NULL, NULL, '118/8-ĐÔNG BẮC-P. TÂN CHÁNH HIỆP-Q. 12-HCM', '118/8', 'ĐÔNG BẮC', 'P. TÂN CHÁNH HIỆP', 'Q. 12', 'HCM', NULL, '0938 918377', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(176, 'KH0248', NULL, 'VŨ NGỌC TÂM', NULL, NULL, '-NGÃ 3 BẦU-P. TÂN CHÁNH HIỆP-Q. 12-HCM', '', 'NGÃ 3 BẦU', 'P. TÂN CHÁNH HIỆP', 'Q. 12', 'HCM', NULL, '0937199779', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(177, 'KH0166', NULL, 'KIM THÀNH 4', NULL, NULL, '761A-NGUYỄN ẢNH THỦ-P. TÂN CHÁNH HIỆP-Q. 12-HCM', '761A', 'NGUYỄN ẢNH THỦ', 'P. TÂN CHÁNH HIỆP', 'Q. 12', 'HCM', NULL, '02837189629', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(178, 'KH0232', NULL, 'KIM PHÁT ĐẠI HẢI', NULL, NULL, '-PHAN VĂN HỚN-P. TÂN THỚI NHẤT-Q. 12-HCM', '', 'PHAN VĂN HỚN', 'P. TÂN THỚI NHẤT', 'Q. 12', 'HCM', NULL, '0902590015', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(179, 'KH0508', NULL, 'KIM HOÀN PHÁT', NULL, NULL, '-ĐƯỜNG TX21-P. THẠNH XUÂN-Q. 12-HCM', '', 'ĐƯỜNG TX21', 'P. THẠNH XUÂN', 'Q. 12', 'HCM', NULL, '0987274757', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(180, 'KH0352', NULL, 'ĐỨC TÍN', NULL, NULL, 'A14-TÔ KÝ-P. TRUNG MỸ TÂY-Q. 12-HCM', 'A14', 'TÔ KÝ', 'P. TRUNG MỸ TÂY', 'Q. 12', 'HCM', NULL, '01627270208', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(181, 'KH0258', NULL, 'LAN ANH', NULL, NULL, '1-NGUYỄN ẢNH THỦ--Q. 12-HCM', '1', 'NGUYỄN ẢNH THỦ', '', 'Q. 12', 'HCM', NULL, '0978494944', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(182, 'KH0136', NULL, 'KIM PHÁT KHỞI NGHIỆP', NULL, NULL, '190-26 THÁNG 3-P. BÌNH HƯNG HÒA-Q. BÌNH TÂN-HCM', '190', '26 THÁNG 3', 'P. BÌNH HƯNG HÒA', 'Q. BÌNH TÂN', 'HCM', NULL, '0909342079', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(183, 'KH0050', NULL, 'KIM THÀNH PHÁT', NULL, NULL, '768-LÊ TRỌNG TẤN-P. BÌNH HƯNG HÒA-Q. BÌNH TÂN-HCM', '768', 'LÊ TRỌNG TẤN', 'P. BÌNH HƯNG HÒA', 'Q. BÌNH TÂN', 'HCM', NULL, '02854357504', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(184, 'KH0132', NULL, 'KIM PHÁT PHƯỚC', NULL, NULL, '60-TÂN KỲ TÂN QUÝ-P. BÌNH HƯNG HÒA A-Q. BÌNH TÂN-HCM', '60', 'TÂN KỲ TÂN QUÝ', 'P. BÌNH HƯNG HÒA A', 'Q. BÌNH TÂN', 'HCM', NULL, '0289122401', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(185, 'KH0264', NULL, 'KIM ANH 2', NULL, NULL, '70-HỒ VĂN LONG-P. BÌNH HƯNG HÒA B-Q. BÌNH TÂN-HCM', '70', 'HỒ VĂN LONG', 'P. BÌNH HƯNG HÒA B', 'Q. BÌNH TÂN', 'HCM', NULL, '0979587718', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(186, 'KH0276', NULL, 'KIM ĐỨC', NULL, NULL, '-NGUYỄN THỊ TÚ-P. BÌNH HƯNG HÒA B-Q. BÌNH TÂN-HCM', '', 'NGUYỄN THỊ TÚ', 'P. BÌNH HƯNG HÒA B', 'Q. BÌNH TÂN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(187, 'KH0174', NULL, 'KIM PHÁT BẢO PHƯƠNG', NULL, NULL, '412-HƯƠNG LỘ 2-P. BÌNH TRỊ ĐÔNG-Q. BÌNH TÂN-HCM', '412', 'HƯƠNG LỘ 2', 'P. BÌNH TRỊ ĐÔNG', 'Q. BÌNH TÂN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(188, 'KH0351', NULL, 'NGỌC HẢO', NULL, NULL, '426-PHẠM VĂN CHIÊU-P. 14-Q. GÒ VẤP-HCM', '426', 'PHẠM VĂN CHIÊU', 'P. 14', 'Q. GÒ VẤP', 'HCM', NULL, '0909999167', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(189, 'KH0213', NULL, 'KIM PHÚ HẢO', NULL, NULL, '1346-QUANG TRUNG-P. 14-Q. GÒ VẤP-HCM', '1346', 'QUANG TRUNG', 'P. 14', 'Q. GÒ VẤP', 'HCM', NULL, '01636847777', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(190, 'KH0530', NULL, 'KIM HƯNG PHÁT', NULL, NULL, '128-NGUYỄN VĂN NGHI-P. 5-Q. GÒ VẤP-HCM', '128', 'NGUYỄN VĂN NGHI', 'P. 5', 'Q. GÒ VẤP', 'HCM', NULL, '0909110838', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(191, 'KH0350', NULL, 'KIM PHÁT NGA GÒ VẤP', NULL, NULL, '170-NGUYỄN VĂN NGHỊ-P. 5-Q. GÒ VẤP-HCM', '170', 'NGUYỄN VĂN NGHỊ', 'P. 5', 'Q. GÒ VẤP', 'HCM', NULL, '0965808279', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(192, 'KH0243', NULL, 'KIM THÀNH HẢO', NULL, NULL, '-PHAN ĐÌNH PHÙNG-P. 2-Q. PHÚ NHUẬN-HCM', '', 'PHAN ĐÌNH PHÙNG', 'P. 2', 'Q. PHÚ NHUẬN', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(193, 'KH0052', NULL, 'KIM MAI(HHT)', NULL, NULL, '-CHỢ HOÀNG HOA THÁM-P. 13-Q. TÂN BÌNH-HCM', '', 'CHỢ HOÀNG HOA THÁM', 'P. 13', 'Q. TÂN BÌNH', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(194, 'KH0239', NULL, 'KIM PHÁT (Hoàng Hoa Thám)', NULL, NULL, '-HOÀNG HOA THÁM-P. 13-Q. TÂN BÌNH-HCM', '', 'HOÀNG HOA THÁM', 'P. 13', 'Q. TÂN BÌNH', 'HCM', NULL, '0909904445', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(195, 'KH0082', NULL, 'KIM THÀNH THẢO', NULL, NULL, '-CHỢ TÂN HƯƠNG-P. TÂN QUÝ-Q. TÂN PHÚ-HCM', '', 'CHỢ TÂN HƯƠNG', 'P. TÂN QUÝ', 'Q. TÂN PHÚ', 'HCM', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(196, 'KH0321', NULL, 'KIM BẢO MINH', NULL, NULL, '----LONG AN', '', '', '', '', 'LONG AN', NULL, '0985921481', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(197, 'KH0327', NULL, 'KIM NGỌC HIẾU', NULL, NULL, '-ẤP PHƯỚC ĐỨC-X. PHƯỚC ĐÔNG-H. GÒ DẦU-TÂY NINH', '', 'ẤP PHƯỚC ĐỨC', 'X. PHƯỚC ĐÔNG', 'H. GÒ DẦU', 'TÂY NINH', NULL, '0984959183', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(198, 'KH0334', NULL, 'KIM TIẾN', NULL, NULL, '-CHỢ LONG HOA-TT. HÒA THÀNH-H. HÒA THÀNH-TÂY NINH', '', 'CHỢ LONG HOA', 'TT. HÒA THÀNH', 'H. HÒA THÀNH', 'TÂY NINH', NULL, '02763841241', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(199, 'KH0451', NULL, 'KIM HIẾU', NULL, NULL, '-NGUYỄN VĂN LINH--H. HÒA THÀNH-TÂY NINH', '', 'NGUYỄN VĂN LINH', '', 'H. HÒA THÀNH', 'TÂY NINH', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(200, 'KH0452', NULL, 'KIM HUỲNH', NULL, NULL, '-CHỢ TÂN BIÊN-TT. TÂN BIÊN-H. TÂN BIÊN-TÂY NINH', '', 'CHỢ TÂN BIÊN ', 'TT. TÂN BIÊN', 'H. TÂN BIÊN', 'TÂY NINH', NULL, '', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(201, 'KH0267', NULL, 'KIM NGÂN NGỌC', NULL, NULL, '-NGÃ TƯ AN BÌNH--H. TRẢNG BÀNG-TÂY NINH', '', 'NGÃ TƯ AN BÌNH', '', 'H. TRẢNG BÀNG', 'TÂY NINH', NULL, '0909344949', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(202, 'KH0371', NULL, 'NGỌC TẠO', NULL, NULL, '34F-LÊ LỢI--TP. MỸ THO-TIỀN GIANG', '34F', 'LÊ LỢI', '', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '0902818199', 3, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(203, 'KH0453', NULL, 'KIM MAI VŨNG TÀU', NULL, NULL, '76-LÝ THƯỜNG KIỆT-P. 1-TP. VŨNG TÀU-BÀ RỊA - VT', '76', 'LÝ THƯỜNG KIỆT', 'P. 1', 'TP. VŨNG TÀU', 'BÀ RỊA - VT', NULL, '0915867171', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(204, 'KH0142', NULL, 'KIM TÀI_ VŨNG TÀU', NULL, NULL, '73B-30/04-P. 11-TP. VŨNG TÀU-BÀ RỊA - VT', '73B', '30/04', 'P. 11', 'TP. VŨNG TÀU', 'BÀ RỊA - VT', NULL, '0643620945', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(205, 'KH0340', NULL, 'KIM TRÂN', NULL, NULL, '1001/15-BÌNH DÃ-P. RẠCH DỨA-TP. VŨNG TÀU-BÀ RỊA - VT', '1001/15', 'BÌNH DÃ', 'P. RẠCH DỨA', 'TP. VŨNG TÀU', 'BÀ RỊA - VT', NULL, '0907779520', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(206, 'KH0152', NULL, 'KIM PHÁT 3', NULL, NULL, '-30/04-P. RẠCH DỪA-TP. VŨNG TÀU-BÀ RỊA - VT', '', '30/04', 'P. RẠCH DỪA', 'TP. VŨNG TÀU', 'BÀ RỊA - VT', NULL, '064 3848328', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(207, 'KH0023', NULL, 'KIM THÀNH - NGỌC MAI', NULL, NULL, '241-30/04-P. RẠCH DỪA-TP. VŨNG TÀU-BÀ RỊA - VT', '241', '30/04', 'P. RẠCH DỪA', 'TP. VŨNG TÀU', 'BÀ RỊA - VT', NULL, '0643848132', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(208, 'KH0150', NULL, 'KIM PHÁT 1 (Chú Hoanh)', NULL, NULL, '---TP. VŨNG TÀU-BÀ RỊA - VT', '', '', '', 'TP. VŨNG TÀU', 'BÀ RỊA - VT', NULL, '0643848351', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(209, 'KH0171', NULL, 'KIM PHÁT 2 (Chú hoanh)', NULL, NULL, '---TP. VŨNG TÀU-BÀ RỊA - VT', '', '', '', 'TP. VŨNG TÀU', 'BÀ RỊA - VT', NULL, '0903 917 171', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(210, 'KH0084', NULL, 'KIM SƠN', NULL, NULL, '-ẤP TÂN MỸ-TT. THÁI HÒA-H. TÂN UYÊN-BÌNH DƯƠNG', '', 'ẤP TÂN MỸ', 'TT. THÁI HÒA', 'H. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0913690405', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(211, 'KH0326', NULL, 'KIM THẾ VINH', NULL, NULL, '-CHỢ QUANG VINH 1--H. TÂN UYÊN-BÌNH DƯƠNG', '', 'CHỢ QUANG VINH 1', '', 'H. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0906380717', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(212, 'KH0089', NULL, 'KIM MAI 4', NULL, NULL, '1/379--KP HÒA LÂN 2-H. THUẬN GIAO-BÌNH DƯƠNG', '1/379', '', 'KP HÒA LÂN 2', 'H. THUẬN GIAO', 'BÌNH DƯƠNG', NULL, '6503713840', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `gold_customers` (`id`, `code`, `tmp_code`, `name`, `dob`, `store_name`, `address`, `address_home_number`, `address_street`, `address_ward`, `address_district`, `address_province`, `zalo_phone`, `phone`, `saler_id`, `import`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(213, 'KH0045', NULL, 'KIM MAI(BD)', NULL, NULL, '342-ẤP HÒA LÂN--H. THUẬN GIAO-BÌNH DƯƠNG', '342', 'ẤP HÒA LÂN', '', 'H. THUẬN GIAO', 'BÌNH DƯƠNG', NULL, '', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(214, 'KH0143', NULL, 'NGỌC HUỆ_TỈNH', NULL, NULL, '11-CHỢ PHÚ CHÁNH A-P. PHÚ CHÁNH-TP. MỚI BÌNH DƯƠNG-BÌNH DƯƠNG', '11', 'CHỢ PHÚ CHÁNH A', 'P. PHÚ CHÁNH', 'TP. MỚI BÌNH DƯƠNG', 'BÌNH DƯƠNG', NULL, '0972364656', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(215, 'KH0455', NULL, 'KIM MẠNH', NULL, NULL, '16-CHỢ PHÚ CHÁNH A-P. PHÚ CHÁNH-TP. MỚI BÌNH DƯƠNG-BÌNH DƯƠNG', '16', 'CHỢ PHÚ CHÁNH A', 'P. PHÚ CHÁNH', 'TP. MỚI BÌNH DƯƠNG', 'BÌNH DƯƠNG', NULL, '0909106335', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(216, 'KH0410', NULL, 'KIM NGÂN ( Thủ Dầu)', NULL, NULL, '61A-AN PHÚ-P. PHÚ MỸ-TP. THỦ DẦU MỘT-BÌNH DƯƠNG', '61A', 'AN PHÚ', 'P. PHÚ MỸ', 'TP. THỦ DẦU MỘT', 'BÌNH DƯƠNG', NULL, '0903647887', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(217, 'KH0435', NULL, 'LÊ THÀNH 4', NULL, NULL, '-DT 741-P. HÒA LỢI-TX. BẾN CÁT-BÌNH DƯƠNG', '', 'DT 741', 'P. HÒA LỢI', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '02743589633', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(218, 'KH0314', NULL, 'NGỌC HƯNG', NULL, NULL, '-KP. PHÚ NGHỊ-P. HÒA LỢI-TX. BẾN CÁT-BÌNH DƯƠNG', '', 'KP. PHÚ NGHỊ', 'P. HÒA LỢI', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0919036379', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(219, 'KH0310', NULL, 'THÀNH TÂM', NULL, NULL, '-KP. PHÚ NGHỊ-P. HÒA LỢI-TX. BẾN CÁT-BÌNH DƯƠNG', '', 'KP. PHÚ NGHỊ', 'P. HÒA LỢI', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '01693377700', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(220, 'KH0138', NULL, 'KIM THÀNH DANH', NULL, NULL, '75-ĐƯỜNG D3 KP4-P. MỸ PHƯỚC-TX. BẾN CÁT-BÌNH DƯƠNG', '75', 'ĐƯỜNG D3 KP4', 'P. MỸ PHƯỚC', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0916249999', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(221, 'KH0297', NULL, 'KIM NGỌC PHÚ', NULL, NULL, '-DDJ9-P. THỚI HÒA-TX. BẾN CÁT-BÌNH DƯƠNG', '', 'DDJ9', 'P. THỚI HÒA', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0981259279', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(222, 'KH0391', NULL, 'LÊ THÀNH 1', NULL, NULL, '-KP1-X. CHÁNH PHÚ HÒA-TX. BẾN CÁT-BÌNH DƯƠNG', '', 'KP1', 'X. CHÁNH PHÚ HÒA', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0916562660', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(223, 'KH0392', NULL, 'LÊ THÀNH 5', NULL, NULL, '59-DT 744-X. PHÚ AN-TX. BẾN CÁT-BÌNH DƯƠNG', '59', 'DT 744', 'X. PHÚ AN', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0949377139', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(224, 'KH0101', NULL, 'KIM NGỌC TÂN', NULL, NULL, '55-LÊ HỒNG PHONG-KP CHIÊU LIÊU-TX. DĨ AN-BÌNH DƯƠNG', '55', 'LÊ HỒNG PHONG', 'KP CHIÊU LIÊU', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0918025263', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(225, 'KH0245', NULL, 'NGỌC HÀ CHIÊU LIÊU', NULL, NULL, '365-LÊ HỒNG PHONG-P. TÂN BÌNH-TX. DĨ AN-BÌNH DƯƠNG', '365', 'LÊ HỒNG PHONG', 'P. TÂN BÌNH', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '01655575123', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(226, 'KH0092', NULL, 'KIM VÂN LONG', NULL, NULL, '23/29-ĐOÀN THỊ KIA-P. TÂN ĐÔNG HIỆP-TX. DĨ AN-BÌNH DƯƠNG', '23/29', 'ĐOÀN THỊ KIA', 'P. TÂN ĐÔNG HIỆP', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0912001143', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(227, 'KH0468', NULL, 'KIM HUYỀN TRÂN', NULL, NULL, '307-NGUYỄN THỊ MINH KHAI-P. TÂN ĐÔNG HIỆP-TX. DĨ AN-BÌNH DƯƠNG', '307', 'NGUYỄN THỊ MINH KHAI', 'P. TÂN ĐÔNG HIỆP', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0908717008', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(228, 'KH0098', NULL, 'NHÂN SINH', NULL, NULL, '---TX. DĨ AN-BÌNH DƯƠNG', '', '', '', 'TX. DĨ AN', 'BÌNH DƯƠNG', NULL, '0937667186', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(229, 'KH0094', NULL, 'HUỲNH HOA 3', NULL, NULL, '-TỔ 2A-P. HỘI NGHĨA-TX. TÂN UYÊN-BÌNH DƯƠNG', '', 'TỔ 2A', 'P. HỘI NGHĨA', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0907301324', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(230, 'KH0296', NULL, 'HỒNG HẠNH', NULL, NULL, '-KP KHÁNH LỘC-P. KHÁNH BÌNH-TX. TÂN UYÊN-BÌNH DƯƠNG', '', 'KP KHÁNH LỘC', 'P. KHÁNH BÌNH', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0949095979', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(231, 'KH0304', NULL, 'KIM PHÁT ĐẠT', NULL, NULL, 'TỔ 1-KP KHÁNH LỘC-P. KHÁNH BÌNH-TX. TÂN UYÊN-BÌNH DƯƠNG', 'TỔ 1', 'KP KHÁNH LỘC', 'P. KHÁNH BÌNH', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0988818794', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(232, 'KH0382', NULL, 'KIM NHƠN', NULL, NULL, 'TỔ 1-KP THẠNH LỘC-P. KHÁNH BÌNH-TX. TÂN UYÊN-BÌNH DƯƠNG', 'TỔ 1', 'KP THẠNH LỘC', 'P. KHÁNH BÌNH', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0964629639', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(233, 'KH0475', NULL, 'KIM LOAN AN', NULL, NULL, 'D1-KP ỐNG ĐỒNG-P. TÂN HIỆP-TX. TÂN UYÊN-BÌNH DƯƠNG', 'D1', 'KP ỐNG ĐỒNG', 'P. TÂN HIỆP', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0978386828', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(234, 'KH0123', NULL, 'HUỲNH HOA TÂN HIỆP', NULL, NULL, '2-TỔ 1-P. TÂN HIỆP-TX. TÂN UYÊN-BÌNH DƯƠNG', '2', 'TỔ 1', 'P. TÂN HIỆP', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0916969250', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(235, 'KH0466', NULL, 'PHI HÙNG PHÁT', NULL, NULL, '--P. TÂN HIỆP-TX. TÂN UYÊN-BÌNH DƯƠNG', '', '', 'P. TÂN HIỆP', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(236, 'KH0419', NULL, 'THƯ PHƯỚC', NULL, NULL, '-ĐƯỜNG 401-P. THÁI HÒA-TX. TÂN UYÊN-BÌNH DƯƠNG', '', 'ĐƯỜNG 401', 'P. THÁI HÒA', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '01628030379', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(237, 'KH0005', NULL, 'HUỲNH HOA 4', NULL, NULL, '-TỔ 5-P. UYÊN HƯNG-TX. TÂN UYÊN-BÌNH DƯƠNG', '', 'TỔ 5', 'P. UYÊN HƯNG', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '01633051799', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(238, 'KH0385', NULL, 'BẢO NAM', NULL, NULL, 'ẤP 4-VĨNH TÂN-P. VĨNH TÂN-TX. TÂN UYÊN-BÌNH DƯƠNG', 'ẤP 4', 'VĨNH TÂN', 'P. VĨNH TÂN', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0916340488', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(239, 'KH0118', NULL, 'KIM PHÚ', NULL, NULL, '-ẤP 1-X. HỘI NGHĨA-TX. TÂN UYÊN-BÌNH DƯƠNG', '', 'ẤP 1', 'X. HỘI NGHĨA', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0650.3648444 - 0912648444', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(240, 'KH0108', NULL, 'TIỆM VÀNG HUỲNH HOA 5', NULL, NULL, '169-ẤP 1-X. HỘI NGHĨA-TX. TÂN UYÊN-BÌNH DƯƠNG', '169', 'ẤP 1', 'X. HỘI NGHĨA', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '01667711600', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(241, 'KH0107', NULL, 'KIM KIM HOA', NULL, NULL, '19-D5-X. HỘI NGHĨA-TX. TÂN UYÊN-BÌNH DƯƠNG', '19', 'D5', 'X. HỘI NGHĨA', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0972527174', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(242, 'KH0198', NULL, 'KIM THẢO ( Chú hoanh)', NULL, NULL, '--X. HỘI NGHĨA-TX. TÂN UYÊN-BÌNH DƯƠNG', '', '', 'X. HỘI NGHĨA', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0982 560 237- 0985 325 806', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(243, 'KH0266', NULL, 'KIM PHÚ PHÁT', NULL, NULL, '105/B-TỔ 3A - ẤP 1-XÃ HỘI NGHĨA-TX. TÂN UYÊN-BÌNH DƯƠNG', '105/B', 'TỔ 3A - ẤP 1', 'XÃ HỘI NGHĨA', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0909119011', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(244, 'KH0154', NULL, 'KIM LINH 2 (Chú hoanh)', NULL, NULL, '-CHỢ QUANG VINH 1--TX. TÂN UYÊN-BÌNH DƯƠNG', '', 'CHỢ QUANG VINH 1', '', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0989224749', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(245, 'KH0099', NULL, 'KIM MẠNH PHÁT', NULL, NULL, '---TX. TÂN UYÊN-BÌNH DƯƠNG', '', '', '', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0979754276', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(246, 'KH0133', NULL, 'NGỌC TUYỀN', NULL, NULL, '---TX. TÂN UYÊN-BÌNH DƯƠNG', '', '', '', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '01685357754', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(247, 'KH0100', NULL, 'KIM ANH', NULL, NULL, '---TX. TÂN UYÊN-BÌNH DƯƠNG', '', '', '', 'TX. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0973653665', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(248, 'KH0083', NULL, 'KIM THÀNH MINH VŨ', NULL, NULL, '1/109D--KP HÒA TÂN 2-TX. THUẬN AN-BÌNH DƯƠNG', '1/109D', '', 'KP HÒA TÂN 2', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0977507676', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(249, 'KH0088', NULL, 'KIM LOAN', NULL, NULL, '113C/2--P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '113C/2', '', 'P.  AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0979142222', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(250, 'KH0305', NULL, 'KIM PHÁT LOAN', NULL, NULL, '109 D1/D5-KDC VIỆT SING-P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '109 D1/D5', 'KDC VIỆT SING', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0976069996', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(251, 'KH0286', NULL, 'HỮU LỘC', NULL, NULL, '58H/1-KP1A-P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '58H/1', 'KP1A', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0985840790', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(252, 'KH0104', NULL, 'PHÚC THỊNH PHÁT', NULL, NULL, '303/2-KP1B-P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '303/2', 'KP1B', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0987341117', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(253, 'KH0054', NULL, 'KIM THÀNH - AN PHÚ', NULL, NULL, '30B2/A11-KP3-P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '30B2/A11', 'KP3', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0979586746', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(254, 'KH0418', NULL, 'PHÚC KIM HƯNG', NULL, NULL, '271M/2-PHAN ĐÌNH GIÓT-P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '271M/2', 'PHAN ĐÌNH GIÓT', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0903048003', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(255, 'KH0093', NULL, 'KIM MAI 2', NULL, NULL, '64/1--P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '64/1', '', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '06503710039', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(256, 'KH0339', NULL, 'QUỐC THẢO', NULL, NULL, '-BÌNH QUỚI-P. BÌNH CHUẨN-TX. THUẬN AN-BÌNH DƯƠNG', '', 'BÌNH QUỚI', 'P. BÌNH CHUẨN', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0968554138', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(257, 'KH0299', NULL, 'PHÚC KIM QUANG', NULL, NULL, 'KIOT 10-CHỢ PHÚ PHONG-P. BÌNH CHUẨN-TX. THUẬN AN-BÌNH DƯƠNG', 'KIOT 10', 'CHỢ PHÚ PHONG', 'P. BÌNH CHUẨN', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0908809139', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(258, 'KH0384', NULL, 'KIM PHƯỚC HIỀN', NULL, NULL, '55/21-KP BÌNH PHÚ-P. BÌNH CHUẨN-TX. THUẬN AN-BÌNH DƯƠNG', '55/21', 'KP BÌNH PHÚ', 'P. BÌNH CHUẨN', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0932873158', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(259, 'KH0254', NULL, 'KIM ĐỊNH', NULL, NULL, '82/4-KP BÌNH PHƯỚC-P. BÌNH CHUẨN-TX. THUẬN AN-BÌNH DƯƠNG', '82/4', 'KP BÌNH PHƯỚC', 'P. BÌNH CHUẨN', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '01643496782', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(260, 'KH0201', NULL, 'KIM HOÀNG BẢO ANH ( Chú Hoanh)', NULL, NULL, '19A-KP BÌNH THUẬN 2-P. BÌNH THUẬN GIAO-TX. THUẬN AN-BÌNH DƯƠNG', '19A', 'KP BÌNH THUẬN 2', 'P. BÌNH THUẬN GIAO', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0983692268', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(261, 'KH0209', NULL, 'KIM PHÚC AN (Chú Hoanh)', NULL, NULL, '108L/2-KP 1B-P. PHÚ AN-TX. THUẬN AN-BÌNH DƯƠNG', '108L/2', 'KP 1B', 'P. PHÚ AN', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0988953682', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(262, 'KH0216', NULL, 'KIM TOM', NULL, NULL, 'LÔ DC81-KDC VIỆT SING-P. THUẬN GIAO-TX. THUẬN AN-BÌNH DƯƠNG', 'LÔ DC81', 'KDC VIỆT SING', 'P. THUẬN GIAO', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '02822670670', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(263, 'KH0228', NULL, 'KIM VÂN LONG 2', NULL, NULL, '79-LÔ 56 KDC VIỆT SING-P. THUẬN GIAO-TX. THUẬN AN-BÌNH DƯƠNG', '79', 'LÔ 56 KDC VIỆT SING', 'P. THUẬN GIAO', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0962251692', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(264, 'KH0121', NULL, 'HUY THÀNH PHÁT', NULL, NULL, '--P. THUẬN GIAO-TX. THUẬN AN-BÌNH DƯƠNG', '', '', 'P. THUẬN GIAO', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0987158239', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(265, 'KH0081', NULL, 'LƯU KIM THÀNH', NULL, NULL, '--P. THUẬN GIAO-TX. THUẬN AN-BÌNH DƯƠNG', '', '', 'P. THUẬN GIAO', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '026503718728', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(266, 'KH0106', NULL, 'KIM PHÁT XUÂN (chị nga)', NULL, NULL, '24/31-KP BÌNH PHƯỚC A-X. BÌNH CHUẨN-TX. THUẬN AN-BÌNH DƯƠNG', '24/31', 'KP BÌNH PHƯỚC A', 'X. BÌNH CHUẨN', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '01633966084', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(267, 'KH0333', NULL, 'KIM PHÁT LOAN 2', NULL, NULL, '-KDC VIỆT SING--TX. THUẬN AN-BÌNH DƯƠNG', '', 'KDC VIỆT SING', '', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '01636293246', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(268, 'KH0514', NULL, 'KIM QUANG PHÁT', NULL, NULL, '-THỦ KHOA HUÂN--TX. THUẬN AN-BÌNH DƯƠNG', '', 'THỦ KHOA HUÂN', '', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0384121040', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(269, 'KH0250', NULL, 'KIM QUANG 3', NULL, NULL, '---TX. THUẬN AN-BÌNH DƯƠNG', '', '', '', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0982563567', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(270, 'KH0462', NULL, 'HOÀNG THI', NULL, NULL, '188-QL 13--H. HỚN QUẢNG-BÌNH PHƯỚC', '188', 'QL 13', '', 'H. HỚN QUẢNG', 'BÌNH PHƯỚC', NULL, '0938590929', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(271, 'KH0463', NULL, 'KHÁNH LINH', NULL, NULL, '50-LÝ TỰ TRỌNG-P. AN LỘC-TX. BÌNH LONG-BÌNH PHƯỚC', '50', 'LÝ TỰ TRỌNG', 'P. AN LỘC', 'TX. BÌNH LONG', 'BÌNH PHƯỚC', NULL, '0918680585', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(272, 'KH0461', NULL, 'HÀ ANH', NULL, NULL, '47-TRẦN HƯNG ĐẠO-P. AN LỘC-TX. BÌNH LONG-BÌNH PHƯỚC', '47', 'TRẦN HƯNG ĐẠO', 'P. AN LỘC', 'TX. BÌNH LONG', 'BÌNH PHƯỚC', NULL, '0679777818', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(273, 'KH0428', NULL, 'KIM HƯƠNG 2', NULL, NULL, '-TTTM ĐỒNG XOÀI--TX. ĐỒNG XOÀI-BÌNH PHƯỚC', '', 'TTTM ĐỒNG XOÀI', '', 'TX. ĐỒNG XOÀI ', 'BÌNH PHƯỚC', NULL, '0913937049', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(274, 'KH0035', NULL, 'KIM XUÂN', NULL, NULL, '-KHU 4-X. AN PHƯỚC-H. LONG THÀNH-ĐỒNG NAI', '', 'KHU 4', 'X. AN PHƯỚC', 'H. LONG THÀNH', 'ĐỒNG NAI', NULL, '01696706539', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(275, 'KH0127', NULL, 'CẨM DỰ', NULL, NULL, '--X. TÂN HIỆP-H. LONG THÀNH-ĐỒNG NAI', '', '', 'X. TÂN HIỆP', 'H. LONG THÀNH', 'ĐỒNG NAI', NULL, '0975492836', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(276, 'KH0129', NULL, 'HUỲNH HOA 2', NULL, NULL, '--X. TÂN HIỆP-H. LONG THÀNH-ĐỒNG NAI', '', '', 'X. TÂN HIỆP', 'H. LONG THÀNH', 'ĐỒNG NAI', NULL, '0985533747', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(277, 'KH0130', NULL, 'KIM NGỌC PHÁT TAM HIỆP', NULL, NULL, '--X. TÂN HIỆP-H. LONG THÀNH-ĐỒNG NAI', '', '', 'X. TÂN HIỆP', 'H. LONG THÀNH', 'ĐỒNG NAI', NULL, '01299995268', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(278, 'KH0168', NULL, 'KIM HẰNG (ĐN)', NULL, NULL, '--TT. TRẢNG BOM-H. TRẢNG BOM-ĐỒNG NAI', '', '', 'TT. TRẢNG BOM', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '02613968 012', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(279, 'KH0329', NULL, 'KIM KIM THANH', NULL, NULL, '--P. ĐAN PHƯỚC-TP. BIÊN HÒA-ĐỒNG NAI', '', '', 'P. ĐAN PHƯỚC', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0912678878', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(280, 'KH0202', NULL, 'KIM NGUYÊN PHÁT (Chú Hoanh)', NULL, NULL, '65-BÙI VĂN HÒA-P. LONG BÌNH-TP. BIÊN HÒA-ĐỒNG NAI', '65', 'BÙI VĂN HÒA', 'P. LONG BÌNH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '02613936379', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(281, 'KH0528', NULL, 'KIM NGỌC BẢO', NULL, NULL, '3/F2-QL51-P. LONG BÌNH TÂN-TP. BIÊN HÒA-ĐỒNG NAI', '3/F2', 'QL51', 'P. LONG BÌNH TÂN', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0907835428', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(282, 'KH0167', NULL, 'KIM NHƯ THỦY', NULL, NULL, '-CHỢ TÂN MAI 2-P. PHƯỚC TÂN-TP. BIÊN HÒA-ĐỒNG NAI', '', 'CHỢ TÂN MAI 2', 'P. PHƯỚC TÂN', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0938646998', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(283, 'KH0317', NULL, 'NGỌC PHÁT', NULL, NULL, '10E-PHAN ĐÌNH PHÙNG-P. QUANG VINH-TP. BIÊN HÒA-ĐỒNG NAI', '10E', 'PHAN ĐÌNH PHÙNG', 'P. QUANG VINH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0613846020 - 0903850292', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(284, 'KH0128', NULL, 'LÂM KHÁNH', NULL, NULL, '6D-ẤP LONG ĐỨC 1-P. TAM PHƯỚC-TP. BIÊN HÒA-ĐỒNG NAI', '6D', 'ẤP LONG ĐỨC 1', 'P. TAM PHƯỚC', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0974437978', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(285, 'KH0470', NULL, 'NGOC DUNG ', NULL, NULL, '--X. TAM PHƯỚC-TP. BIÊN HÒA-ĐỒNG NAI', '', '', 'X. TAM PHƯỚC', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0937506718', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(286, 'KH0160', NULL, 'KIM THI', NULL, NULL, '---TP. BIÊN HÒA-ĐỒNG NAI', '', '', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0612 600 801- 093480 7777-0913897145', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(287, 'KH0543', NULL, 'NHẬT TÍN', NULL, NULL, '183-HỒ VĂN TĂNG-TT. CỦ CHI-H. CỦ CHI-HCM', '183', 'HỒ VĂN TĂNG', 'TT. CỦ CHI', 'H. CỦ CHI', 'HCM', NULL, '0976795279', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(288, 'KH0420', NULL, 'KIM BẢO (Củ Chi)', NULL, NULL, '-TỈNH LỘ 2-X. TÂN THÔNG HỘI-H. CỦ CHI-HCM', '', 'TỈNH LỘ 2', 'X. TÂN THÔNG HỘI', 'H. CỦ CHI', 'HCM', NULL, '0965586468', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(289, 'KH0113', NULL, 'KIM PHÁT DANH', NULL, NULL, '---H. HÓC MÔN-HCM', '', '', '', 'H. HÓC MÔN', 'HCM', NULL, '0962117119', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(290, 'KH0137', NULL, 'KHÁNH ĐÌNH', NULL, NULL, '152-HOÀNG TĂNG BÍ-TRUNG MỸ TÂY-Q. 12-HCM', '152', 'HOÀNG TĂNG BÍ', 'TRUNG MỸ TÂY', 'Q. 12', 'HCM', NULL, '0873001468 - 0907131221', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(291, 'KH0349', NULL, 'MINH HƯNG', NULL, NULL, '9-LÊ VĂN VIỆT-P. HIỆP PHÚ-Q. 9-HCM', '9', 'LÊ VĂN VIỆT', 'P. HIỆP PHÚ', 'Q. 9', 'HCM', NULL, '02838961493', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(292, 'KH0444', NULL, 'NGỌC HUỆ PHÁT', NULL, NULL, '619-LÊ VĂN VIỆT-P. TÂN PHÚ-Q. 9-HCM', '619', 'LÊ VĂN VIỆT', 'P. TÂN PHÚ', 'Q. 9', 'HCM', NULL, '0902065065', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(293, 'KH0345', NULL, 'VŨ NGỌC VY', NULL, NULL, '462A-NGUYỄN VĂN TẦNG--Q. 9-HCM', '462A', 'NGUYỄN VĂN TẦNG', '', 'Q. 9', 'HCM', NULL, '02837331421', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(294, 'KH0342', NULL, 'KHÁNH NGỌC', NULL, NULL, '265-LÊ VĂN VIỆT--Q. THỦ ĐỨC-HCM', '265', 'LÊ VĂN VIỆT', '', 'Q. THỦ ĐỨC', 'HCM', NULL, '0933337779', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(295, 'KH0117', NULL, 'KIM NGỌC (LONG AN)', NULL, NULL, '-ẤP MỚI 1-X. MỸ HẠNH NAM-H. ĐỨC HÒA-LONG AN', '', 'ẤP MỚI 1', 'X. MỸ HẠNH NAM', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0987158239', 4, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(296, 'KH0051', NULL, 'MỸ LONG', NULL, NULL, '---TP. QUY NHƠN-BÌNH ĐỊNH', '', '', '', 'TP. QUY NHƠN', 'BÌNH ĐỊNH', NULL, '0935561564', NULL, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(297, 'KH0034', NULL, 'KIM PHÁT ( ANH PHÊ )', NULL, NULL, '---TP. QUY NHƠN-BÌNH ĐỊNH', '', '', '', 'TP. QUY NHƠN', 'BÌNH ĐỊNH', NULL, '0913421666', NULL, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(298, 'KH0134', NULL, 'CHỊ HÂN', NULL, NULL, '----BÌNH ĐỊNH', '', '', '', '', 'BÌNH ĐỊNH', NULL, '0977782800', NULL, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(299, 'KH0500', NULL, 'KIM LỘC PHÚ', NULL, NULL, '-THUẬN GIAO 16-P. THUẬN GIAO-TX. THUẬN AN-BÌNH DƯƠNG', '', 'THUẬN GIAO 16', 'P. THUẬN GIAO', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0938373779', NULL, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(300, 'KH0422', NULL, 'THANH XUÂN ( An Giang)', NULL, NULL, '-CHỢ TRI TÔN-TT. TRI TÔN-H. TRI TÔN-AN GIANG', '', 'CHỢ TRI TÔN', 'TT. TRI TÔN', 'H. TRI TÔN', 'AN GIANG', NULL, '0918338184', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(301, 'KH0552', NULL, 'MỸ HOÀN', NULL, NULL, '7-9-LÊ MINH XUÂN-P. MỸ LONG-TP. LONG XUYÊN-AN GIANG', '7-9', 'LÊ MINH XUÂN', 'P. MỸ LONG', 'TP. LONG XUYÊN', 'AN GIANG', NULL, '0763845321-0913601496', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(302, 'KH0048', NULL, 'TÂN LÊ QUANG', NULL, NULL, '---TP. LONG XUYÊN-AN GIANG', '', '', '', 'TP. LONG XUYÊN', 'AN GIANG', NULL, '0918899807', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(303, 'KH0180', NULL, 'HOÀNG MINH', NULL, NULL, '520A-TỔ 5-TT. THÁI HÒA-H. TÂN UYÊN-BÌNH DƯƠNG', '520A', 'TỔ 5', 'TT. THÁI HÒA', 'H. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0909290209', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(304, 'KH0179', NULL, 'BẢO TRANG', NULL, NULL, 'QL13-KCN MỸ PHƯỚC 1-P. MỸ PHƯỚC-TX. BẾN CÁT-BÌNH DƯƠNG', 'QL13', 'KCN MỸ PHƯỚC 1', 'P. MỸ PHƯỚC', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0906889199', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(305, 'KH0189', NULL, 'BẢO HƯNG ( A SÂM)', NULL, NULL, '97-HÙNG VƯƠNG-P. MỸ PHƯỚC 1-TX. BẾN CÁT-BÌNH DƯƠNG', '97', 'HÙNG VƯƠNG', 'P. MỸ PHƯỚC 1', 'TX. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '06503564645 - 0913788899', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(306, 'KH0312', NULL, 'KIM THÙY DƯƠNG', NULL, NULL, '-ĐƯỜNG D5 VIỆT SING-P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '', 'ĐƯỜNG D5 VIỆT SING', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0941735079', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(307, 'KH0332', NULL, 'KIM PHÁT NHUNG', NULL, NULL, '172/5-TỔ 3 - KP 4-P. AN PHÚ-TX. THUẬN AN-BÌNH DƯƠNG', '172/5', 'TỔ 3 - KP 4', 'P. AN PHÚ', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '01689970449', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(308, 'KH0199', NULL, 'KIM ĐẠI PHƯỚC ( A SÂM)', NULL, NULL, 'F33-35--P. BÌNH HÒA-TX. THUẬN AN-BÌNH DƯƠNG', 'F33-35', '', 'P. BÌNH HÒA', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0822670670 - 0977599789', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(309, 'KH0285', NULL, 'BẢY NHUNG', NULL, NULL, '36-PHAN ĐÌNH PHÙNG-P. LÁI THIÊU-TX. THUẬN AN-BÌNH DƯƠNG', '36', 'PHAN ĐÌNH PHÙNG', 'P. LÁI THIÊU', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0969275290-02743760548', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(310, 'KH0086', NULL, 'KIM KIM TIỀN', NULL, NULL, '56-58--P. LÁI THIÊU-TX. THUẬN AN-BÌNH DƯƠNG', '56-58', '', 'P. LÁI THIÊU', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0919446369', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(311, 'KH0188', NULL, 'KIM HOA ( A SÂM)', NULL, NULL, '79--TT. AN THẠNH-TX. THUẬN AN-BÌNH DƯƠNG', '79', '', 'TT. AN THẠNH', 'TX. THUẬN AN', 'BÌNH DƯƠNG', NULL, '0650 382 2706', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(312, 'KH0200', NULL, 'HOÀNG TRỌNG ( A SÂM)', NULL, NULL, '7--TT. LỘC NINH-H. LỘC NINH-BÌNH PHƯỚC', '7', '', 'TT. LỘC NINH', 'H. LỘC NINH', 'BÌNH PHƯỚC', NULL, '0822670670', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(313, 'KH0079', NULL, 'A Vũ', NULL, NULL, '---H. PHƯỚC BÌNH-BÌNH PHƯỚC', '', '', '', 'H. PHƯỚC BÌNH', 'BÌNH PHƯỚC', NULL, '', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(314, 'KH0159', NULL, 'BẢO TRÂN (Bình Phước)', NULL, NULL, '---H. PHƯỚC BÌNH-BÌNH PHƯỚC', '', '', '', 'H. PHƯỚC BÌNH', 'BÌNH PHƯỚC', NULL, '0975018537', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(315, 'KH0474', NULL, 'PHƯƠNG KIM DUNG', NULL, NULL, '70/2A-VÕ VÕNG-X. GIA KIỆM-H. THỐNG NHẤT-ĐỒNG NAI', '70/2A', 'VÕ VÕNG', 'X. GIA KIỆM', 'H. THỐNG NHẤT', 'ĐỒNG NAI', NULL, '0919668182', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(316, 'KH0163', NULL, 'THANH KIM HƯƠNG', NULL, NULL, '573-QL 1A-CHỢ ĐÔNG HÀ-H. TRẢNG BOM-ĐỒNG NAI', '573', 'QL 1A', 'CHỢ ĐÔNG HÀ', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0613868311 - 0834146478', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(317, 'KH0165', NULL, 'KIM CHI', NULL, NULL, '-HÙNG VƯƠNG-TT. TRẢNG BOM-H. TRẢNG BOM-ĐỒNG NAI', '', 'HÙNG VƯƠNG', 'TT. TRẢNG BOM', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0917471407', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(318, 'KH0224', NULL, 'KIM CHI 2', NULL, NULL, '-HÙNG VƯƠNG-TT. TRẢNG BOM-H. TRẢNG BOM-ĐỒNG NAI', '', 'HÙNG VƯƠNG', 'TT. TRẢNG BOM', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0918719011', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(319, 'KH0464', NULL, 'PHÁT NGỌC NGÂN', NULL, NULL, '31-HÙNG VƯƠNG-TT. TRẢNG BOM-H. TRẢNG BOM-ĐỒNG NAI', '31', 'HÙNG VƯƠNG', 'TT. TRẢNG BOM', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0937436403', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(320, 'KH0283', NULL, 'KIM NGỌC TRÂM', NULL, NULL, '-CHỢ BÙI CHU-X. BẮC SƠN-H. TRẢNG BOM-ĐỒNG NAI', '', 'CHỢ BÙI CHU', 'X. BẮC SƠN', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0909513882', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(321, 'KH0287', NULL, 'NGỌC VŨ (Chợ An Chu)', NULL, NULL, '-CHỢ BÙI CHU-X. BẮC SƠN-H. TRẢNG BOM-ĐỒNG NAI', '', 'CHỢ BÙI CHU', 'X. BẮC SƠN', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0906650440', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(322, 'KH0281', NULL, 'KIM MAI VŨ', NULL, NULL, '26/3-HỐ NAI-X. BẮC SƠN-H. TRẢNG BOM-ĐỒNG NAI', '26/3', 'HỐ NAI', 'X. BẮC SƠN', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '01655149815', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(323, 'KH0303', NULL, 'ÁNH NHƯ', NULL, NULL, '7-ĐƯỜNG CHỢ 2-X. ĐÔNG HÒA-H. TRẢNG BOM-ĐỒNG NAI', '7', 'ĐƯỜNG CHỢ 2', 'X. ĐÔNG HÒA', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0933209337', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(324, 'KH0293', NULL, 'NGỌC HƯNG HUY', NULL, NULL, '-QL1A-X. HỐ NAI-H. TRẢNG BOM-ĐỒNG NAI', '', 'QL1A', 'X. HỐ NAI', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0918284898', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(325, 'KH0341', NULL, 'MINH NGỌC ( Đồng Nai)', NULL, NULL, '-CHỢ HƯNG LONG-X. HƯNG THỊNH-H. TRẢNG BOM-ĐỒNG NAI', '', 'CHỢ HƯNG LONG', 'X. HƯNG THỊNH', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '0909246828', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(326, 'KH0162', NULL, 'Kim Ngọc Phước Huy 2', NULL, NULL, '899-CHỢ QUẢNG ĐIỀN-X. QUẢNG TIẾN-H. TRẢNG BOM-ĐỒNG NAI', '899', 'CHỢ QUẢNG ĐIỀN', 'X. QUẢNG TIẾN', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '02613864304', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(327, 'KH0437', NULL, 'KIM VÂN', NULL, NULL, '---H. TRẢNG BOM-ĐỒNG NAI', '', '', '', 'H. TRẢNG BOM', 'ĐỒNG NAI', NULL, '01628910863', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(328, 'KH0482', NULL, 'KIM DUNG H', NULL, NULL, '41/1-50/1--P. BÌNH ĐA-TP. BIÊN HÒA-ĐỒNG NAI', '41/1-50/1', '', 'P. BÌNH ĐA', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '090803822', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(329, 'KH0261', NULL, 'KIM TUẤN', NULL, NULL, '181-CMT8-P. THANH BÌNH-TP. BIÊN HÒA-ĐỒNG NAI', '181', 'CMT8', 'P. THANH BÌNH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0908042568', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(330, 'KH0187', NULL, 'HOÀNG ANH ', NULL, NULL, '-CHỢ TAM HIỆP--TP. BIÊN HÒA-ĐỒNG NAI', '', 'CHỢ TAM HIỆP', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0913755397', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(331, 'KH0553', NULL, 'KIM HOA BÉ SÁU', NULL, NULL, '133-THIÊN HỘ-P. AN THẠNH-H. HỒNG NGỰ-ĐỒNG THÁP', '133', 'THIÊN HỘ', 'P. AN THẠNH', 'H. HỒNG NGỰ', 'ĐỒNG THÁP', NULL, '0945678722', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(332, 'KH0551', NULL, 'KIM HOA ÚT DIỂM', NULL, NULL, 'TỔ 21-ẤP LONG THÁI-X. LONG KHÁNH-H. HỒNG NGỰ-ĐỒNG THÁP', 'TỔ 21', 'ẤP LONG THÁI ', 'X. LONG KHÁNH', 'H. HỒNG NGỰ', 'ĐỒNG THÁP', NULL, '0769993333', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(333, 'KH0511', NULL, 'VĨNH THANH GIA LAI', NULL, NULL, '100-TRẦN PHÚ-P. DIÊN HỒNG-TP. PLEIKU-GIA LAI', '100', 'TRẦN PHÚ', 'P. DIÊN HỒNG', 'TP. PLEIKU', 'GIA LAI', NULL, '0906442668', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(334, 'KH0058', NULL, 'NGỌC HOA', NULL, NULL, '-NGUYỄN THỊ TÚ-VĨNH LỘC-H. BÌNH CHÁNH-HCM', '', 'NGUYỄN THỊ TÚ', 'VĨNH LỘC', 'H. BÌNH CHÁNH', 'HCM', NULL, '', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(335, 'KH0559', NULL, 'KIM LỢI ( Chợ Thuận Đạt)', NULL, NULL, 'F12B/68--X. HƯNG LONG-H. BÌNH CHÁNH-HCM', 'F12B/68', '', 'X. HƯNG LONG', 'H. BÌNH CHÁNH', 'HCM', NULL, '0934768723', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(336, 'KH0411', NULL, 'KIM PHÁT CẦU XÁNG', NULL, NULL, '3C-68-THANH NIÊN-X. PHẠM VĂN HAI-H. BÌNH CHÁNH-HCM', '3C-68', 'THANH NIÊN', 'X. PHẠM VĂN HAI', 'H. BÌNH CHÁNH', 'HCM', NULL, '01688565405', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(337, 'KH0330', NULL, 'TÂN KIM THÀNH', NULL, NULL, '1451A-NGUYỄN CỬU PHÚ-X. TÂN KIÊN-H. BÌNH CHÁNH-HCM', '1451A', 'NGUYỄN CỬU PHÚ', 'X. TÂN KIÊN', 'H. BÌNH CHÁNH', 'HCM', NULL, '0918864246', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(338, 'KH0210', NULL, 'KIM PHÁT LÝ ( A LỢI)', NULL, NULL, '1565A-NGUYỄN CỬU PHÚ-X. TÂN KIÊN-H. BÌNH CHÁNH-HCM', '1565A', 'NGUYỄN CỬU PHÚ', 'X. TÂN KIÊN', 'H. BÌNH CHÁNH', 'HCM', NULL, '0977.630.303', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(339, 'KH0236', NULL, 'KIM DUYÊN', NULL, NULL, 'F2/24/12-ẤP 6 - LIÊN ẤP 26-X. VĨNH LỘC A-H. BÌNH CHÁNH-HCM', 'F2/24/12', 'ẤP 6 - LIÊN ẤP 26', 'X. VĨNH LỘC A', 'H. BÌNH CHÁNH', 'HCM', NULL, '0903607205', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(340, 'KH0469', NULL, 'KIM NGỌC VĨNH LỘC', NULL, NULL, 'A9/16-VÕ VĂN VÂN-X. VĨNH LỘC B-H. BÌNH CHÁNH-HCM', 'A9/16', 'VÕ VĂN VÂN', 'X. VĨNH LỘC B', 'H. BÌNH CHÁNH', 'HCM', NULL, '0904332334', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(341, 'KH0040', NULL, 'KIM NGUYÊN THÀNH', NULL, NULL, '20/10A-BÙI CÔNG TRỪNG-ẤP 4-H. HÓC MÔN-HCM', '20/10A', 'BÙI CÔNG TRỪNG', 'ẤP 4', 'H. HÓC MÔN', 'HCM', NULL, '       08.37112186 - 0908465029', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(342, 'KH0343', NULL, 'TRỌNG NGHĨA', NULL, NULL, '86-102-CHỢ TRẦN NHÂN TÔN-P. 2-Q. 10-HCM', '86-102', 'CHỢ TRẦN NHÂN TÔN', 'P. 2', 'Q. 10', 'HCM', NULL, '0913102323', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(343, 'KH0479', NULL, 'KIM HỒNG HẠNH', NULL, NULL, '-CHỢ NGUYỄN TRI PHƯƠNG-P. 6-Q. 10-HCM', '', 'CHỢ NGUYỄN TRI PHƯƠNG', 'P. 6', 'Q. 10', 'HCM', NULL, '0903600357', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(344, 'KH0480', NULL, 'MAI ANH', NULL, NULL, '-CHỢ NGUYỄN TRI PHƯƠNG-P. 6-Q. 10-HCM', '', 'CHỢ NGUYỄN TRI PHƯƠNG', 'P. 6', 'Q. 10', 'HCM', NULL, '0906570494', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(345, 'KH0003', NULL, 'KỲ KIM PHÁT HIỆP THÀNH', NULL, NULL, '-NGUYỄN ẢNH THỦ-P. HIỆP THÀNH-Q. 12-HCM', '', 'NGUYỄN ẢNH THỦ', 'P. HIỆP THÀNH', 'Q. 12', 'HCM', NULL, '01999551774', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(346, 'KH0153', NULL, 'KIM PHÁT HIỆP THÀNH_CƯỜNGVT', NULL, NULL, '-NGUYỄN ẢNH THỦ-P. HIỆP THÀNH-Q. 12-HCM', '', 'NGUYỄN ẢNH THỦ', 'P. HIỆP THÀNH', 'Q. 12', 'HCM', NULL, '0946314051', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(347, 'KH0007', NULL, 'KIM PHÁT HIỆP THÀNH_CƯỜNG', NULL, NULL, '27-NGUYỄN ẢNH THỦ-P. HIỆP THÀNH-Q. 12-HCM', '27', 'NGUYỄN ẢNH THỦ', 'P. HIỆP THÀNH', 'Q. 12', 'HCM', NULL, '0946314051', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(348, 'KH0066', NULL, 'MINH CHÂU', NULL, NULL, '252/2-TÔ KÝ-P. TÂN CHÁNH HIỆP-Q. 12-HCM', '252/2', 'TÔ KÝ', 'P. TÂN CHÁNH HIỆP', 'Q. 12', 'HCM', NULL, '0938467157', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(349, 'KH0062', NULL, 'KIM THÀNH TRỌNG TUYỀN', NULL, NULL, '78/1-PHAN VĂN HỚN-P. TÂN THỚI NHẤT-Q. 12-HCM', '78/1', 'PHAN VĂN HỚN', 'P. TÂN THỚI NHẤT', 'Q. 12', 'HCM', NULL, '0907831999', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(350, 'KH0284', NULL, 'KIM THÀNH HÓC MÔN', NULL, NULL, '366A-NGUYỄN ẢNH THỦ-P. TRUNG MỸ TÂY-Q. 12-HCM', '366A', 'NGUYỄN ẢNH THỦ', 'P. TRUNG MỸ TÂY', 'Q. 12', 'HCM', NULL, '02837182391 - 0962997039', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(351, 'KH0377', NULL, 'KIM LOAN ( Quận 5)', NULL, NULL, '17-BÙI HỮU NGHĨA-P. 5-Q. 5-HCM', '17', 'BÙI HỮU NGHĨA', 'P. 5', 'Q. 5', 'HCM', NULL, '0911799499', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(352, 'KH0227', NULL, 'KIM MINH (An Đông)', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0903939428', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(353, 'KH0318', NULL, 'NGỌC THẢO ( An Đông)', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0938159399', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(354, 'KH0029', NULL, 'KIM NGỌC', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '    0985888870 - 0903888870', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(355, 'KH0316', NULL, 'KIM ANH ( An Đông)', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0988868043', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(356, 'KH0021', NULL, 'KIM NHI', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0907415344', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(357, 'KH0122', NULL, 'KIM HOA', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0909633680', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(358, 'KH0319', NULL, 'KIM HÀ (An Đông)', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0903977177', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(359, 'KH0320', NULL, 'NGỌC THANH (An Đông)', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0933787989', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(360, 'KH0429', NULL, 'HOÀNG YÊN (An Đông)', NULL, NULL, '-AN ĐÔNG PLAZA-P. 9-Q. 5-HCM', '', 'AN ĐÔNG PLAZA', 'P. 9', 'Q. 5', 'HCM', NULL, '0908373096', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(361, 'KH0294', NULL, 'KIM NGA ĐIỀN (Minh Phụng)', NULL, NULL, '-MINH PHỤNG-P. 5-Q. 6-HCM', '', 'MINH PHỤNG', 'P. 5', 'Q. 6', 'HCM', NULL, '0903944634', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(362, 'KH0018', NULL, 'KIM NGA ĐIỀN', NULL, NULL, '213P-MINH PHỤNG-P. 9-Q. 6-HCM', '213P', 'MINH PHỤNG', 'P. 9', 'Q. 6', 'HCM', NULL, '0902737459', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(363, 'KH0237', NULL, 'KIM NGA ĐIỀN 2', NULL, NULL, '129A-MINH PHỤNG--Q. 6-HCM', '129A', 'MINH PHỤNG', '', 'Q. 6', 'HCM', NULL, '0909474918', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(364, 'KH0075', NULL, 'KIM MỸ TUYẾT', NULL, NULL, '965-TẠ QUANG BỬU-P. 6-Q. 7-HCM', '965', 'TẠ QUANG BỬU', 'P. 6', 'Q. 7', 'HCM', NULL, '0903931580', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(365, 'KH0196', NULL, 'KIM PHÁT LONG PHỤNG ( A LỢI)', NULL, NULL, '99-NGUYỄN LƯƠNG BẰNG-P. TÂN PHÚ-Q. 7-HCM', '99', 'NGUYỄN LƯƠNG BẰNG', 'P. TÂN PHÚ', 'Q. 7', 'HCM', NULL, '0936836871', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(366, 'KH0214', NULL, 'KIM HOÀN (Chợ Xóm Củi)', NULL, NULL, '5-CHỢ XÓM CỦI-P. 11-Q. 8-HCM', '5', 'CHỢ XÓM CỦI', 'P. 11', 'Q. 8', 'HCM', NULL, '0918.888.788', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(367, 'KH0064', NULL, 'TÂN MỸ HƯNG', NULL, NULL, '1-PHONG PHÚ-P. 11-Q. 8-HCM', '1', 'PHONG PHÚ', 'P. 11', 'Q. 8', 'HCM', NULL, '02839512207 - 0903788131', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(368, 'KH0190', NULL, 'TRÚC ĐÀO', NULL, NULL, '26-AN DƯƠNG VƯƠNG-P. 16-Q. 8-HCM', '26', 'AN DƯƠNG VƯƠNG', 'P. 16', 'Q. 8', 'HCM', NULL, '0936522245', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(369, 'KH0105', NULL, 'KIM THANH (THU TRANG)', NULL, NULL, '-AN DƯƠNG VƯƠNG-P. 16-Q. 8-HCM', '', 'AN DƯƠNG VƯƠNG', 'P. 16', 'Q. 8', 'HCM', NULL, '0918582077', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(370, 'KH0271', NULL, 'HOÀNG TUYẾT', NULL, NULL, '-CHỢ PHẠM THẾ HIỂN-P. 4-Q. 8-HCM', '', 'CHỢ PHẠM THẾ HIỂN', 'P. 4', 'Q. 8', 'HCM', NULL, '0903988705', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(371, 'KH0080', NULL, 'HỒNG VINH', NULL, NULL, 'KIOT 20-PHẠM THẾ HIỂN-P. 4-Q. 8-HCM', 'KIOT 20', 'PHẠM THẾ HIỂN', 'P. 4', 'Q. 8', 'HCM', NULL, '0907676991', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(372, 'KH0147', NULL, 'KIM PHÁT THÀNH LONG', NULL, NULL, '26A-BÙI MINH TRỰC-P. 5-Q. 8-HCM', '26A', 'BÙI MINH TRỰC', 'P. 5', 'Q. 8', 'HCM', NULL, '0937799154', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(373, 'KH0416', NULL, 'MINH NGỌC  ( Đường NAm Cao)', NULL, NULL, '3/16-ĐƯỜNG NAM CAO-P. TÂN PHÚ-Q. 9-HCM', '3/16', 'ĐƯỜNG NAM CAO', 'P. TÂN PHÚ', 'Q. 9', 'HCM', NULL, '0909248828', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(374, 'KH0389', NULL, 'KIM LỢI', NULL, NULL, '-NAM CAO-P. TÂN PHÚ-Q. 9-HCM', '', 'NAM CAO', 'P. TÂN PHÚ', 'Q. 9', 'HCM', NULL, '0908102030', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(375, 'KH0438', NULL, 'MINH HƯNG ( Quận 9)', NULL, NULL, '09-LÊ VĂN VIỆT-P. TĂNG NHƠN PHÚ A-Q. 9-HCM', '09', 'LÊ VĂN VIỆT', 'P. TĂNG NHƠN PHÚ A', 'Q. 9', 'HCM', NULL, '0936764567', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(376, 'KH0221', NULL, 'PHÁT LỢI', NULL, NULL, '279-GÒ XOÀI-P. BÌNH HƯNG HÒA-Q. BÌNH TÂN-HCM', '279', 'GÒ XOÀI', 'P. BÌNH HƯNG HÒA', 'Q. BÌNH TÂN', 'HCM', NULL, '0939394397', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(377, 'KH0067', NULL, 'KIM HOÀN MỸ 2', NULL, NULL, '327D-LÊ VĂN QUỚI-P. BÌNH HƯNG HÒA-Q. BÌNH TÂN-HCM', '327D', 'LÊ VĂN QUỚI', 'P. BÌNH HƯNG HÒA', 'Q. BÌNH TÂN', 'HCM', NULL, '0934944611', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(378, 'KH0076', NULL, 'KIM NGỌC THÀNH', NULL, NULL, '-NGÃ TƯ 4 XÃ-P. BÌNH HƯNG HÒA-Q. BÌNH TÂN-HCM', '', 'NGÃ TƯ 4 XÃ', 'P. BÌNH HƯNG HÒA', 'Q. BÌNH TÂN', 'HCM', NULL, '0909181457', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(379, 'KH0432', NULL, 'KIM THÀNH HƯNG', NULL, NULL, '162-LIÊN KHU 4-5-P. BÌNH HƯNG HÒA B-Q. BÌNH TÂN-HCM', '162', 'LIÊN KHU 4-5', 'P. BÌNH HƯNG HÒA B', 'Q. BÌNH TÂN', 'HCM', NULL, '0965828883', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(380, 'KH0036', NULL, 'KIM THÀNH KHÁNH', NULL, NULL, '957A-HƯƠNG LỘ 2-P. BÌNH TRỊ ĐÔNG A-Q. BÌNH TÂN-HCM', '957A', 'HƯƠNG LỘ 2', 'P. BÌNH TRỊ ĐÔNG A', 'Q. BÌNH TÂN', 'HCM', NULL, '0908666055', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(381, 'KH0090', NULL, 'MINH HÀO', NULL, NULL, '85-TÂY LÂN-P. BÌNH TRỊ ĐÔNG A-Q. BÌNH TÂN-HCM', '85', 'TÂY LÂN', 'P. BÌNH TRỊ ĐÔNG A', 'Q. BÌNH TÂN', 'HCM', NULL, '0906367436', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(382, 'KH0091', NULL, 'KIM HUY', NULL, NULL, '574/111-SINCO-P. BÌNH TRỊ ĐÔNG B-Q. BÌNH TÂN-HCM', '574/111', 'SINCO', 'P. BÌNH TRỊ ĐÔNG B', 'Q. BÌNH TÂN', 'HCM', NULL, '0939662727', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(383, 'KH0028', NULL, 'MINH HOÀNG 3 (Chị Giêng)', NULL, NULL, '52-TÊN LỬA-P. BÌNH TRỊ ĐÔNG B-Q. BÌNH TÂN-HCM', '52', 'TÊN LỬA', 'P. BÌNH TRỊ ĐÔNG B', 'Q. BÌNH TÂN', 'HCM', NULL, '0903331369', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(384, 'KH0001', NULL, 'MINH HOÀNG (TIÊM VÀNG)', NULL, NULL, '36-LÊ ĐÌNH CẨN-P. TÂN TẠO-Q. BÌNH TÂN-HCM', '36', 'LÊ ĐÌNH CẨN', 'P. TÂN TẠO', 'Q. BÌNH TÂN', 'HCM', NULL, '0903388755', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(385, 'KH0325', NULL, 'KIM NGỌC IV', NULL, NULL, '445-HƯƠNG LỘ 2--Q. BÌNH TÂN-HCM', '445', 'HƯƠNG LỘ 2', '', 'Q. BÌNH TÂN', 'HCM', NULL, '0982970992', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(386, 'KH0517', NULL, 'KIM NGA ( Hương Lộ 2)', NULL, NULL, '-HƯƠNG LỘ 2--Q. BÌNH TÂN-HCM', '', 'HƯƠNG LỘ 2', '', 'Q. BÌNH TÂN', 'HCM', NULL, '', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(387, 'KH0407', NULL, 'HOÀNG NGỌC LAN', NULL, NULL, '-CHỢ BÀ CHIỂU--Q. BÌNH THẠNH-HCM', '', 'CHỢ BÀ CHIỂU', '', 'Q. BÌNH THẠNH', 'HCM', NULL, '0903104727', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(388, 'KH0308', NULL, 'KIM THỊNH LỢI', NULL, NULL, '37-BÙI THẾ MỸ-P. 10-Q. TÂN BÌNH-HCM', '37', 'BÙI THẾ  MỸ', 'P. 10', 'Q. TÂN BÌNH', 'HCM', NULL, '02838617917 - 0918842740', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(389, 'KH0483', NULL, 'KIM TÂM', NULL, NULL, '444-PHẠM VĂN HAI-P. 5-Q. TÂN BÌNH-HCM', '444', 'PHẠM VĂN HAI', 'P. 5', 'Q. TÂN BÌNH', 'HCM', NULL, '0931934199', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(390, 'KH0212', NULL, 'KIM THÀNH TÚ', NULL, NULL, '1830-TỈNH LỘ 10-P. TÂN TẠO-Q. TÂN BÌNH-HCM', '1830', 'TỈNH LỘ 10', 'P. TÂN TẠO', 'Q. TÂN BÌNH', 'HCM', NULL, '0908244909', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(391, 'KH0476', NULL, 'VINH KIM PHÁT', NULL, NULL, '16D-LŨY BÁN BÍCH--Q. TÂN BÌNH-HCM', '16D', 'LŨY BÁN BÍCH', '', 'Q. TÂN BÌNH', 'HCM', NULL, '0909626967', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(392, 'KH0215', NULL, 'KIM NGÂN (ANH PHI)', NULL, NULL, '194-TÂN HƯƠNG-P. TÂN QUÝ-Q. TÂN PHÚ-HCM', '194', 'TÂN HƯƠNG', 'P. TÂN QUÝ', 'Q. TÂN PHÚ', 'HCM', NULL, '0938482439', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(393, 'KH0014', NULL, 'QUẢNG ĐÔNG 2', NULL, NULL, '205-TÂN HƯƠNG-P. TÂN QUÝ-Q. TÂN PHÚ-HCM', '205', 'TÂN HƯƠNG', 'P. TÂN QUÝ', 'Q. TÂN PHÚ', 'HCM', NULL, '0909347456', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(394, 'KH0016', NULL, 'NGỌC TUẤN', NULL, NULL, '63A-NGUYỄN BÁ TÒNG-P. TÂN THÀNH-Q. TÂN PHÚ-HCM', '63A', 'NGUYỄN BÁ TÒNG', 'P. TÂN THÀNH', 'Q. TÂN PHÚ', 'HCM', NULL, '02838496929', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(395, 'KH0205', NULL, 'KIM HOÀN (A KỲ)', NULL, NULL, '1146-TL43-P. BÌNH CHIỂU-Q. THỦ ĐỨC-HCM', '1146', 'TL43', 'P. BÌNH CHIỂU', 'Q. THỦ ĐỨC', 'HCM', NULL, '02822670670', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(396, 'KH0406', NULL, 'HOÀNG CHIÊU', NULL, NULL, '-TÔ NGỌC VÂN-P. TAM PHÚ-Q. THỦ ĐỨC-HCM', '', 'TÔ NGỌC VÂN', 'P. TAM PHÚ', 'Q. THỦ ĐỨC', 'HCM', NULL, '0909669002', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(397, 'KH0073', NULL, 'KIM NGA 2 (CHỊ QUYÊN)', NULL, NULL, '148A-NGUYỄN TRUNG TRỰC-P. DƯƠNG ĐÔNG-TP. PHÚ QUỐC-KIÊN GIANG', '148A', 'NGUYỄN TRUNG TRỰC', 'P. DƯƠNG ĐÔNG', 'TP. PHÚ QUỐC', 'KIÊN GIANG', NULL, '0918729997', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(398, 'KH0344', NULL, 'KIM NGÂN THUẬN ĐẠO', NULL, NULL, '-KCN BẾN LỨC--H. BẾN LỨC-LONG AN', '', 'KCN BẾN LỨC', '', 'H. BẾN LỨC', 'LONG AN', NULL, '0909565534', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(399, 'KH0558', NULL, 'PHÚC DUYÊN', NULL, NULL, '71 KHU 3-QL50-KHU 3-H. CẦN ĐƯỚC-LONG AN', '71 KHU 3', 'QL50', 'KHU 3', 'H. CẦN ĐƯỚC', 'LONG AN', NULL, '0919949178', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(400, 'KH0306', NULL, 'PHƯỚC THÀNH', NULL, NULL, '-CHỢ RẠCH KIẾN-X. LONG HÒA-H. CẦN ĐƯỚC-LONG AN', '', 'CHỢ RẠCH KIẾN', 'X. LONG HÒA', 'H. CẦN ĐƯỚC', 'LONG AN', NULL, '0922367412', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(401, 'KH0302', NULL, 'BẢO QUỐC', NULL, NULL, '-RẠCH KIẾN-X. LONG HÒA-H. CẦN ĐƯỚC-LONG AN', '', 'RẠCH KIẾN', 'X. LONG HÒA', 'H. CẦN ĐƯỚC', 'LONG AN', NULL, '0983251335', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(402, 'KH0323', NULL, 'PHƯỚC THÀNH 2', NULL, NULL, '244-ẤP XOÀI ĐÔI-X. LONG TRẠCH-H. CẦN ĐƯỚC-LONG AN', '244', 'ẤP XOÀI ĐÔI', 'X. LONG TRẠCH', 'H. CẦN ĐƯỚC', 'LONG AN', NULL, '02723880260 - 0937775242', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(403, 'KH0322', NULL, 'PHƯỚC THÀNH CHỢ ĐÀO', NULL, NULL, '133-NGUYỄN VĂN TIẾN-X. MỸ LỆ-H. CẦN ĐƯỚC-LONG AN', '133', 'NGUYỄN VĂN TIẾN', 'X. MỸ LỆ', 'H. CẦN ĐƯỚC', 'LONG AN', NULL, '0908455969-0933787989', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(404, 'KH0208', NULL, 'KIM NHẬT LINH (A SÂM)', NULL, NULL, '-CHỢ RẠCH KIẾN-X. RẠCH KIẾN-H. CẦN ĐƯỚC-LONG AN', '', 'CHỢ RẠCH KIẾN', 'X. RẠCH KIẾN', 'H. CẦN ĐƯỚC', 'LONG AN', NULL, '', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(405, 'KH0026', NULL, 'KIM THÀNH PHÁT (ANH THẢO)', NULL, NULL, '---H. CẦN ĐƯỚC-LONG AN', '', '', '', 'H. CẦN ĐƯỚC', 'LONG AN', NULL, '0976585522', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(406, 'KH0495', NULL, 'KIM BÉ', NULL, NULL, '77-QL 50-TT. CẦN GIUỘC-H. CẦN GIUỘC-LONG AN', '77', 'QL 50', 'TT. CẦN GIUỘC', 'H. CẦN GIUỘC', 'LONG AN', NULL, '02723741777 - 0961778255', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(407, 'KH0546', NULL, 'KIM PHÁT HẢI', NULL, NULL, '-NGÃ 3 TÂN KIM-X. TÂN KIM-H. CẦN GIUỘC-LONG AN', '', 'NGÃ 3 TÂN KIM', 'X. TÂN KIM', 'H. CẦN GIUỘC', 'LONG AN', NULL, '0968990039', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(408, 'KH0181', NULL, 'KIM PHƯỚC TÂN ĐỨC (A SÂM)', NULL, NULL, '325-TỈNH LỘ 825-ẤP BÌNH ĐIỀN 2-H. ĐỨC HÒA-LONG AN', '325', 'TỈNH LỘ 825', 'ẤP BÌNH ĐIỀN 2', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0908662046', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(409, 'KH0309', NULL, 'KIM NGỌC 4', NULL, NULL, '185-THỬA ĐẤT 592-MỸ HẠNH BẮC-H. ĐỨC HÒA-LONG AN', '185', 'THỬA ĐẤT 592', 'MỸ HẠNH BẮC', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0933639881', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(410, 'KH0273', NULL, 'KIM MAI ( 6 TRẦM)', NULL, NULL, '-CHỢ HẬU NGHĨA-TT. HẬU NGHĨA-H. ĐỨC HÒA-LONG AN', '', 'CHỢ HẬU NGHĨA', 'TT. HẬU NGHĨA', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0723814550', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(411, 'KH0502', NULL, 'TRƯỜNG SƠN', NULL, NULL, '-CHỢ TT HIỆP HÒA-TT. HIỆP HÒA-H. ĐỨC HÒA-LONG AN', '', 'CHỢ TT HIỆP HÒA', 'TT. HIỆP HÒA', 'H. ĐỨC HÒA', 'LONG AN', NULL, '02723854039 - 0908867037', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(412, 'KH0555', NULL, 'KIM HOÀN KHÔI', NULL, NULL, '757E-ẤP 5-X. ĐỨC HÒA ĐÔNG-H. ĐỨC HÒA-LONG AN', '757E', 'ẤP 5', 'X. ĐỨC HÒA ĐÔNG', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0907865875', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(413, 'KH0401', NULL, 'KIM PHÁT ĐỊNH', NULL, NULL, '-ĐỨC HÒA ĐÔNG-X. ĐỨC HÒA ĐÔNG-H. ĐỨC HÒA-LONG AN', '', 'ĐỨC HÒA ĐÔNG', 'X. ĐỨC HÒA ĐÔNG', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0975439376', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(414, 'KH0155', NULL, 'KIM THÀNH TUÂN', NULL, NULL, '372-ẤP BÌNH TIỀN-X. ĐỨC HÒA HẠ-H. ĐỨC HÒA-LONG AN', '372', 'ẤP BÌNH TIỀN', 'X. ĐỨC HÒA HẠ', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0909 373 950 - 0723 826 428', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(415, 'KH0496', NULL, 'KIM GIA BÁCH', NULL, NULL, '35-ẤP BÌNH TIỀN 2-X. ĐỨC HÒA HẠ-H. ĐỨC HÒA-LONG AN', '35', 'ẤP BÌNH TIỀN 2', 'X. ĐỨC HÒA HẠ', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0961032504', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(416, 'KH0280', NULL, 'KIM TÚ ( Chợ Chiều)', NULL, NULL, '373-BÌNH TIỀN 2-X. ĐỨC HÒA HẠ-H. ĐỨC HÒA-LONG AN', '373', 'BÌNH TIỀN 2', 'X. ĐỨC HÒA HẠ', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0904775697', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(417, 'KH0193', NULL, 'KIM PHÚ ( A LỢI)', NULL, NULL, '-NGÃ 3 MỸ HẠNH-X. MỸ HẠNH-H. ĐỨC HÒA-LONG AN', '', 'NGÃ 3 MỸ HẠNH', 'X. MỸ HẠNH', 'H. ĐỨC HÒA', 'LONG AN', NULL, '02723751411 - 0908521966', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(418, 'KH0535', NULL, 'KIM THÀNH CẦU NHỎ', NULL, NULL, 'LÔ 2-TỈNH LỘ 9-X. MỸ HẠNH BẮC-H. ĐỨC HÒA-LONG AN', 'LÔ 2', 'TỈNH LỘ 9', 'X. MỸ HẠNH BẮC', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0985874570 - 0767084084', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `gold_customers` (`id`, `code`, `tmp_code`, `name`, `dob`, `store_name`, `address`, `address_home_number`, `address_street`, `address_ward`, `address_district`, `address_province`, `zalo_phone`, `phone`, `saler_id`, `import`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(419, 'KH0192', NULL, 'KIM ÁNH ( A SÂM)', NULL, NULL, '---H. ĐỨC HÒA-LONG AN', '', '', '', 'H. ĐỨC HÒA', 'LONG AN', NULL, '0948711333', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(420, 'KH0194', NULL, 'KIM KHANH ( A SÂM)', NULL, NULL, '401--X. BÌNH TIỀN 2-H. ĐỨC HÒA HẠ-LONG AN', '401', '', 'X. BÌNH TIỀN 2', 'H. ĐỨC HÒA HẠ', 'LONG AN', NULL, '01229870656', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(421, 'KH0337', NULL, 'KIM THANH II', NULL, NULL, '2D-NGUYỄN ĐÌNH CHIỂU--TP. TÂN AN-LONG AN', '2D', 'NGUYỄN ĐÌNH CHIỂU', '', 'TP. TÂN AN', 'LONG AN', NULL, '0982826672', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(422, 'KH0043', NULL, 'THẾ ĐÀO (ANH PHƯƠNG)', NULL, NULL, '---TP. TÂN AN-LONG AN', '', '', '', 'TP. TÂN AN', 'LONG AN', NULL, '', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(423, 'KH0203', NULL, 'KIM LONG (A SÂM)', NULL, NULL, '1240-LONG HÒA-X. LONG THUẬN-H. BẾN CẦU-TÂY NINH', '1240', 'LONG HÒA', 'X. LONG THUẬN', 'H. BẾN CẦU', 'TÂY NINH', NULL, '0984755756', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(424, 'KH0204', NULL, 'KIM THOA ( A SÂM)', NULL, NULL, '233-TỔ 11 ẤP NINH HIỆP-X. BÀU NĂNG-H. DƯƠNG MINH CHÂU-TÂY NINH', '233', 'TỔ 11 ẤP NINH HIỆP', 'X. BÀU NĂNG', 'H. DƯƠNG MINH CHÂU', 'TÂY NINH', NULL, '02663822724', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(425, 'KH0230', NULL, 'KIM LONG', NULL, NULL, '-CHỢ GÒ DẦU-TT. GÒ DẦU-H. GÒ DẦU-TÂY NINH', '', 'CHỢ GÒ DẦU', 'TT. GÒ DẦU', 'H. GÒ DẦU', 'TÂY NINH', NULL, '01293522663', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(426, 'KH0183', NULL, 'NGỌC ĐÁNG', NULL, NULL, 'KP2/76-CHỢ GÒ DẦU-TT.GÒ DẦU-H. GÒ DẦU-TÂY NINH', 'KP2/76', 'CHỢ GÒ DẦU', 'TT.GÒ DẦU', 'H. GÒ DẦU', 'TÂY NINH', NULL, '0908 920 292 - 0908.92.92.92', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(427, 'KH0184', NULL, 'KIM QUANG - TÂY NINH (SÂM)', NULL, NULL, '-CHỢ MỚI TRẢNG BÀNG-TT. TRẢNG BÀNG-H. TRẢNG BÀNG-TÂY NINH', '', 'CHỢ MỚI TRẢNG BÀNG', 'TT. TRẢNG BÀNG', 'H. TRẢNG BÀNG', 'TÂY NINH', NULL, '0909877299', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(428, 'KH0492', NULL, 'KIM CHÂU ( chợ Long Định)', NULL, NULL, '288-ẤP MỚI-X. LONG ĐỊNH-H. CHÂU THÀNH-TIỀN GIANG', '288', 'ẤP MỚI', 'X. LONG ĐỊNH', 'H. CHÂU THÀNH', 'TIỀN GIANG', NULL, '02733834426', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(429, 'KH0238', NULL, 'NGỌC THẢO', NULL, NULL, '-LÊ LỢI-P. 1-TX. GÒ CÔNG-TIỀN GIANG', '', 'LÊ LỢI', 'P. 1', 'TX. GÒ CÔNG', 'TIỀN GIANG', NULL, '02733841527', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(430, 'KH0116', NULL, 'KIM TÙNG', NULL, NULL, '---TX. GÒ CÔNG-TIỀN GIANG', '', '', '', 'TX. GÒ CÔNG', 'TIỀN GIANG', NULL, '01259747959', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(431, 'KH0366', NULL, 'NGỌC LỄ', NULL, NULL, '---TX. GÒ CÔNG-TIỀN GIANG', '', '', '', 'TX. GÒ CÔNG', 'TIỀN GIANG', NULL, '01232026465', 5, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(432, 'KH0348', NULL, 'LÂM PHÙNG', NULL, NULL, '-CHỢ GIỒNG TRÔM-TT. GIỒNG TRÔM-H. BA TRI-BẾN TRE', '', 'CHỢ GIỒNG TRÔM', 'TT. GIỒNG TRÔM', 'H. BA TRI', 'BẾN TRE', NULL, '0989105789', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(433, 'KH0414', NULL, 'HUỲNH DUNG 680', NULL, NULL, '-CHỢ BÌNH ĐẠI-TT. BÌNH ĐẠI-H. BÌNH ĐẠI-BẾN TRE', '', 'CHỢ BÌNH ĐẠI', 'TT. BÌNH ĐẠI', 'H. BÌNH ĐẠI', 'BẾN TRE', NULL, '0901070622', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(434, 'KH0415', NULL, 'KIM SƠN HOA 680', NULL, NULL, '-CHỢ BÌNH ĐẠI-TT. BÌNH ĐẠI-H. BÌNH ĐẠI-BẾN TRE', '', 'CHỢ BÌNH ĐẠI', 'TT. BÌNH ĐẠI', 'H. BÌNH ĐẠI', 'BẾN TRE', NULL, '0945933398', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(435, 'KH0426', NULL, 'ĐẶNG KHÁ 4', NULL, NULL, '--TT. BÌNH ĐẠI-H. BÌNH ĐẠI-BẾN TRE', '', '', 'TT. BÌNH ĐẠI', 'H. BÌNH ĐẠI', 'BẾN TRE', NULL, '01289604666', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(436, 'KH0427', NULL, 'NGỌC THẠCH 680', NULL, NULL, '--TT. BÌNH ĐẠI-H. BÌNH ĐẠI-BẾN TRE', '', '', 'TT. BÌNH ĐẠI', 'H. BÌNH ĐẠI', 'BẾN TRE', NULL, '01678189929', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(437, 'KH0489', NULL, 'HUỲNH NGUYÊN 680', NULL, NULL, '--X. QUẾ THÀNH-H. CHÂU THÀNH-BẾN TRE', '', '', 'X. QUẾ THÀNH', 'H. CHÂU THÀNH', 'BẾN TRE', NULL, '0987488188', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(438, 'KH0457', NULL, 'BẢO NGÂN 680', NULL, NULL, '-CHỢ TÂN PHÚ-X. TÂN PHÚ-H. CHÂU THÀNH-BẾN TRE', '', 'CHỢ TÂN PHÚ', 'X. TÂN PHÚ', 'H. CHÂU THÀNH', 'BẾN TRE', NULL, '02753867117', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(439, 'KH0443', NULL, 'ĐẶNG KHÁ 1', NULL, NULL, '-ẤP 8-X. TÂN THẠCH-H. CHÂU THÀNH-BẾN TRE', '', 'ẤP 8', 'X. TÂN THẠCH', 'H. CHÂU THÀNH', 'BẾN TRE', NULL, '', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(440, 'KH0484', NULL, 'SỈ TÍN II 680', NULL, NULL, '---H. CHÂU THÀNH-BẾN TRE', '', '', '', 'H. CHÂU THÀNH', 'BẾN TRE', NULL, '0985308241', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(441, 'KH0433', NULL, 'PHƯƠNG VY 680', NULL, NULL, '-CHỢ LÁCH-TT. CHỢ LÁCH-H. CHỢ LÁCH-BẾN TRE', '', 'CHỢ LÁCH', 'TT. CHỢ LÁCH', 'H. CHỢ LÁCH', 'BẾN TRE', NULL, '0972868386', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(442, 'KH0412', NULL, 'NGÂN HÀ 680', NULL, NULL, '-CHỢ LÁCH-TT. CHỢ LÁCH-H. CHỢ LÁCH-BẾN TRE', '', 'CHỢ LÁCH', 'TT. CHỢ LÁCH', 'H. CHỢ LÁCH', 'BẾN TRE', NULL, '02753874131', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(443, 'KH0434', NULL, 'SĨ TÍN 680', NULL, NULL, '-CHỢ LÁCH-TT. CHỢ LÁCH-H. CHỢ LÁCH-BẾN TRE', '', 'CHỢ LÁCH', 'TT. CHỢ LÁCH', 'H. CHỢ LÁCH', 'BẾN TRE', NULL, '0985308241', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(444, 'KH0471', NULL, 'PHƯƠNG LOAN 680', NULL, NULL, '-CHỢ LÁCH-TT. CHỢ LÁCH-H. CHỢ LÁCH-BẾN TRE', '', 'CHỢ LÁCH', 'TT. CHỢ LÁCH', 'H. CHỢ LÁCH', 'BẾN TRE', NULL, '0938191891', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(445, 'KH0493', NULL, 'TÂN VĂN ĐÁ 680', NULL, NULL, '-QL57-X. LONG THỚI-H. CHỢ LÁCH-BẾN TRE', '', 'QL57', 'X. LONG THỚI', 'H. CHỢ LÁCH', 'BẾN TRE', NULL, '', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(446, 'KH0554', NULL, 'VĂN THOÀNG 680', NULL, NULL, '-QL57-X. LONG THỚI-H. CHỢ LÁCH-BẾN TRE', '', 'QL57', 'X. LONG THỚI', 'H. CHỢ LÁCH', 'BẾN TRE', NULL, '02753873328', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(447, 'KH0560', NULL, 'THÀNH NHÂN 680', NULL, NULL, '-CHỢ PHÚ ĐIỀN-X. THUẬN ĐIỀN-H. GIỒNG TRÔM-BẾN TRE', '', 'CHỢ PHÚ ĐIỀN', 'X. THUẬN ĐIỀN', 'H. GIỒNG TRÔM', 'BẾN TRE', NULL, '02753863033', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(448, 'KH0472', NULL, 'VĂN DŨNG ANH 680', NULL, NULL, '-QL 57--H. LONG THỚI-BẾN TRE', '', 'QL 57', '', 'H. LONG THỚI', 'BẾN TRE', NULL, '0275873400', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(449, 'KH0436', NULL, 'TÂN PHƯỚC THÀNH 680', NULL, NULL, '-ẤP PHƯỚC KHÁNH-X. PHƯỚC MỸ TRUNG-H. MỎ CÀY-BẾN TRE', '', 'ẤP PHƯỚC KHÁNH', 'X. PHƯỚC MỸ TRUNG', 'H. MỎ CÀY', 'BẾN TRE', NULL, '02753845032', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(450, 'KH0446', NULL, 'KIM THÀNH II 680', NULL, NULL, '-CHỢ BA VÁT-X. PHƯỚC MỸ TRUNG-H. MỎ CÀY-BẾN TRE', '', 'CHỢ BA VÁT', 'X. PHƯỚC MỸ TRUNG', 'H. MỎ CÀY', 'BẾN TRE', NULL, '0974818784', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(451, 'KH0506', NULL, 'KIM THANH THÚY 680', NULL, NULL, '-ẤP TÂN LỢI-X. TÂN PHÚ TÂY-H. MỎ CÀY-BẾN TRE', '', 'ẤP TÂN LỢI', 'X. TÂN PHÚ TÂY ', 'H. MỎ CÀY', 'BẾN TRE', NULL, '0983089054', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(452, 'KH0518', NULL, 'KIM PHƯỚC NHUNG 680', NULL, NULL, '-ẤP TÂN NHUẬN-X. NHUẬN PHÚ TÂN-H. MỎ CÀY BẮC-BẾN TRE', '', 'ẤP TÂN NHUẬN', 'X. NHUẬN PHÚ TÂN', 'H. MỎ CÀY BẮC', 'BẾN TRE', NULL, '0982693179', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(453, 'KH0527', NULL, 'KIM PHÚC HƯNG 680', NULL, NULL, '-CHỢ BANG TRA-X. NHUẬN PHÚ TÂN-H. MỎ CÀY BẮC-BẾN TRE', '', 'CHỢ BANG TRA', 'X. NHUẬN PHÚ TÂN', 'H. MỎ CÀY BẮC', 'BẾN TRE', NULL, '02753846234', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(454, 'KH0497', NULL, 'KIM HÂN 680', NULL, NULL, '-CHỢ BA VÁT-X. PHƯỚC MỸ TRUNG-H. MỎ CÀY BẮC-BẾN TRE', '', 'CHỢ BA VÁT', 'X. PHƯỚC MỸ TRUNG', 'H. MỎ CÀY BẮC', 'BẾN TRE', NULL, '0933751340', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(455, 'KH0538', NULL, 'MỸ HÂN 680', NULL, NULL, '-CHỢ GIỒNG KEO-X. TÂN BÌNH-H. MỎ CÀY BẮC-BẾN TRE', '', 'CHỢ GIỒNG KEO', 'X. TÂN BÌNH', 'H. MỎ CÀY BẮC', 'BẾN TRE', NULL, '0395395530', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(456, 'KH0516', NULL, 'MỸ ANH 680', NULL, NULL, '157-LÊ LAI--H. MỎ CÀY NAM-BẾN TRE', '157', 'LÊ LAI', '', 'H. MỎ CÀY NAM', 'BẾN TRE', NULL, '0912787943', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(457, 'KH0400', NULL, 'KIM HẢI HẢI 680', NULL, NULL, '4-NGUYỄN ĐÌNH CHIỂU--H. MỎ CÀY NAM-BẾN TRE', '4', 'NGUYỄN ĐÌNH CHIỂU', '', 'H. MỎ CÀY NAM', 'BẾN TRE', NULL, '0983843210', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(458, 'KH0456', NULL, 'KIM HẢI HẢI 600', NULL, NULL, '4-NGUYỄN ĐÌNH CHIỂU--H. MỎ CÀY NAM-BẾN TRE', '4', 'NGUYỄN ĐÌNH CHIỂU', '', 'H. MỎ CÀY NAM', 'BẾN TRE', NULL, '0983843210', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(459, 'KH0445', NULL, 'KIM HÀ TIÊN II 680', NULL, NULL, '-CHỢ CÁI MƠN-TT. CÁI MƠN-H. MỸ THẠNH-BẾN TRE', '', 'CHỢ CÁI MƠN', 'TT. CÁI MƠN', 'H. MỸ THẠNH', 'BẾN TRE', NULL, '0982875559', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(460, 'KH0403', NULL, 'KIM BÍCH PHƯƠNG 680', NULL, NULL, '57/2-ẤP 10-TT. THẠNH PHÚ-H. THẠNH PHÚ-BẾN TRE', '57/2', 'ẤP 10 ', 'TT. THẠNH PHÚ', 'H. THẠNH PHÚ', 'BẾN TRE', NULL, '0907302228', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(461, 'KH0442', NULL, 'NGỌC HIỂN 680', NULL, NULL, '-ẤP 4-TT. THẠNH PHÚ-H. THẠNH PHÚ-BẾN TRE', '', 'ẤP 4', 'TT. THẠNH PHÚ', 'H. THẠNH PHÚ', 'BẾN TRE', NULL, '02753870255', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(462, 'KH0460', NULL, 'VŨ LAN 2 680', NULL, NULL, '-CHỢ THẠNH PHÚ-TT. THẠNH PHÚ-H. THẠNH PHÚ-BẾN TRE', '', 'CHỢ THẠNH PHÚ', 'TT. THẠNH PHÚ', 'H. THẠNH PHÚ', 'BẾN TRE', NULL, '0273878606', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(463, 'KH0404', NULL, 'KIM TIỂU MY 680', NULL, NULL, '-Đại lộ Hòa Lợi-TT. THẠNH PHÚ-H. THẠNH PHÚ-BẾN TRE', '', 'Đại lộ Hòa Lợi', 'TT. THẠNH PHÚ', 'H. THẠNH PHÚ', 'BẾN TRE', NULL, '0979187844', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(464, 'KH0441', NULL, 'KIM HOÀNG OANH 680', NULL, NULL, '--TT. THẠNH PHÚ-H. THẠNH PHÚ-BẾN TRE', '', '', 'TT. THẠNH PHÚ', 'H. THẠNH PHÚ', 'BẾN TRE', NULL, '0918407000', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(465, 'KH0521', NULL, 'CHÍN LIÊM 680', NULL, NULL, '48/2-CHỢ GIỒNG LUÔNG-X. ĐẠI ĐIỀN-H. THẠNH PHÚ-BẾN TRE', '48/2', 'CHỢ GIỒNG LUÔNG', 'X. ĐẠI ĐIỀN', 'H. THẠNH PHÚ', 'BẾN TRE', NULL, '0903549472', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(466, 'KH0548', NULL, 'ĐẶNG KHÁ 5', NULL, NULL, '1-LÊ LAI-P. 1-TP. BẾN TRE-BẾN TRE', '1', 'LÊ LAI', 'P. 1', 'TP. BẾN TRE', 'BẾN TRE', NULL, '02753510777', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(467, 'KH0364', NULL, 'THANH BẠCH', NULL, NULL, '2-LÊ LAI-P. 2-TP. BẾN TRE-BẾN TRE', '2', 'LÊ LAI', 'P. 2', 'TP. BẾN TRE', 'BẾN TRE', NULL, '02753829556 - 0913645158', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(468, 'KH0380', NULL, 'HUY THANH 680', NULL, NULL, '13-NGUYỄN BỈNH KHIÊM-P. 2-TP. BẾN TRE-BẾN TRE', '13', 'NGUYỄN BỈNH KHIÊM', 'P. 2', 'TP. BẾN TRE', 'BẾN TRE', NULL, '0983811263', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(469, 'KH0379', NULL, 'DŨNG KIM LAN 680', NULL, NULL, '15-NGUYỄN BỈNH KHIÊM-P. 2-TP. BẾN TRE-BẾN TRE', '15', 'NGUYỄN BỈNH KHIÊM', 'P. 2', 'TP. BẾN TRE', 'BẾN TRE', NULL, '0913722343', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(470, 'KH0363', NULL, 'TÂN NGỌC GIÁC 2', NULL, NULL, '130-132-NGUYỄN ĐÌNH CHIỂU-P. 2-TP. BẾN TRE-BẾN TRE', '130-132', 'NGUYỄN ĐÌNH CHIỂU', 'P. 2', 'TP. BẾN TRE', 'BẾN TRE', NULL, '02753829662 - 0918469099', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(471, 'KH0362', NULL, 'NGỌC BÌNH', NULL, NULL, '21-23-NGUYỄN DU-P. 2-TP. BẾN TRE-BẾN TRE', '21-23', 'NGUYỄN DU', 'P. 2', 'TP. BẾN TRE', 'BẾN TRE', NULL, '02753829465 - 0903021199', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(472, 'KH0378', NULL, 'PHÚ HÀO 2 (680)', NULL, NULL, '34-NGUYỄN TRÃI-P. 2-TP. BẾN TRE-BẾN TRE', '34', 'NGUYỄN TRÃI', 'P. 2', 'TP. BẾN TRE', 'BẾN TRE', NULL, '0944394699', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(473, 'KH0425', NULL, 'KIM TUẤN HÀ 680', NULL, NULL, '-ẤP PHÚ CHÁNH-X. PHÚ HƯNG-TP. BẾN TRE-BẾN TRE', '', 'ẤP PHÚ CHÁNH', 'X. PHÚ HƯNG', 'TP. BẾN TRE', 'BẾN TRE', NULL, '01684864893', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(474, 'KH0417', NULL, 'BẢO PHÚC 680', NULL, NULL, '---H. BẾN CÁT-BÌNH DƯƠNG', '', '', '', 'H. BẾN CÁT', 'BÌNH DƯƠNG', NULL, '0919436677', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(475, 'KH0481', NULL, 'HOÀNG MINH 680', NULL, NULL, '520A-TỔ 5-TT. THÁI HÒA-H. TÂN UYÊN-BÌNH DƯƠNG', '520A', 'TỔ 5', 'TT. THÁI HÒA', 'H. TÂN UYÊN', 'BÌNH DƯƠNG', NULL, '0909290209', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(476, 'KH0494', NULL, 'KIM THANH PHÚC 680', NULL, NULL, '164-ẤP TRẦN CAO VÂN-X. BẦU HÒM 2-H. THỐNG NHẤT-ĐỒNG NAI', '164', 'ẤP TRẦN CAO VÂN', 'X. BẦU HÒM 2', 'H. THỐNG NHẤT', 'ĐỒNG NAI', NULL, '02513771081', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(477, 'KH0513', NULL, 'KIM DUNG H 680', NULL, NULL, '41/1-50/1--P. BÌNH ĐA-TP. BIÊN HÒA-ĐỒNG NAI', '41/1-50/1', '', 'P. BÌNH ĐA', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '090803822', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(478, 'KH0519', NULL, 'THÀNH NGÔN 680', NULL, NULL, '65-QL 51-P. LONG BÌNH TÂN-TP. BIÊN HÒA-ĐỒNG NAI', '65', 'QL 51', 'P. LONG BÌNH TÂN', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '02513831486', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(479, 'KH0354', NULL, 'NGỌC PHÁT 680', NULL, NULL, '10E-PHAN ĐÌNH PHÙNG-P. QUANG VINH-TP. BIÊN HÒA-ĐỒNG NAI', '10E', 'PHAN ĐÌNH PHÙNG', 'P. QUANG VINH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0613846020 - 0903850292', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(480, 'KH0386', NULL, 'LỰC NGỌC THANH 680', NULL, NULL, '-PHAN ĐÌNH PHÙNG-P. QUANG VINH-TP. BIÊN HÒA-ĐỒNG NAI', '', 'PHAN ĐÌNH PHÙNG', 'P. QUANG VINH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '01223956789', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(481, 'KH0353', NULL, 'QUỐC BẢO', NULL, NULL, '-CHỢ TAM HIỆP-P. TAM HIỆP-TP. BIÊN HÒA-ĐỒNG NAI', '', 'CHỢ TAM HIỆP', 'P. TAM HIỆP', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0918068816', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(482, 'KH0556', NULL, 'QUỐC BẢO SƠN 680', NULL, NULL, '-CHỢ TAM HIỆP-P. TAM HIỆP-TP. BIÊN HÒA-ĐỒNG NAI', '', 'CHỢ TAM HIỆP', 'P. TAM HIỆP', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0913851288', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(483, 'KH0477', NULL, 'QUỐC BẢO GOLD 680', NULL, NULL, '87/5-KP9-P. TÂN BIÊN-TP. BIÊN HÒA-ĐỒNG NAI', '87/5', 'KP9', 'P. TÂN BIÊN', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0613884504', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(484, 'KH0234', NULL, 'Ý NGỌC', NULL, NULL, '132-NGUYỄN ÁI QUỐC-P. TÂN BIÊN-TP. BIÊN HÒA-ĐỒNG NAI', '132', 'NGUYỄN ÁI QUỐC', 'P. TÂN BIÊN', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0933393968', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(485, 'KH0509', NULL, 'MINH CHÂU 680', NULL, NULL, '-CHỢ BIÊN HÒA-P. THANH BÌNH-TP. BIÊN HÒA-ĐỒNG NAI', '', 'CHỢ BIÊN HÒA', 'P. THANH BÌNH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0918523929', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(486, 'KH0395', NULL, 'KIM TUẤN 680', NULL, NULL, '181-CMT8-P. THANH BÌNH-TP. BIÊN HÒA-ĐỒNG NAI', '181', 'CMT8', 'P. THANH BÌNH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0908042568', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(487, 'KH0408', NULL, 'QUANG VINH 680', NULL, NULL, '9-NGUYỄN THỊ GIANG-P. THANH BÌNH-TP. BIÊN HÒA-ĐỒNG NAI', '9', 'NGUYỄN THỊ GIANG', 'P. THANH BÌNH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '02513846635', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(488, 'KH0368', NULL, 'LỰC JEWELRY', NULL, NULL, '2-4-NGUYỄN VĂN NGHĨA-P. THANH BÌNH-TP. BIÊN HÒA-ĐỒNG NAI', '2-4', 'NGUYỄN VĂN NGHĨA', 'P. THANH BÌNH', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0922222279', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(489, 'KH0534', NULL, 'KIM NGỌC PHÁT 2 680', NULL, NULL, '76-BÙI VĂN HÒA--TP. BIÊN HÒA-ĐỒNG NAI', '76', 'BÙI VĂN HÒA', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0918305448', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(490, 'KH0409', NULL, 'HOÀNG ANH 680', NULL, NULL, '-CHỢ TAM HIỆP--TP. BIÊN HÒA-ĐỒNG NAI', '', 'CHỢ TAM HIỆP', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0913755397', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(491, 'KH0423', NULL, 'KIM KHÁNH 680', NULL, NULL, '-CMT8--TP. BIÊN HÒA-ĐỒNG NAI', '', 'CMT8', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0919035100', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(492, 'KH0376', NULL, 'KIM NGỌC PHÁT 680', NULL, NULL, '-CÔNG VIÊN TAM HIỆP--TP. BIÊN HÒA-ĐỒNG NAI', '', 'CÔNG VIÊN TAM HIỆP', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0918305448', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(493, 'KH0393', NULL, 'KIM BÍCH CƯƠNG 680', NULL, NULL, '10-ĐỒNG KHỞI--TP. BIÊN HÒA-ĐỒNG NAI', '10', 'ĐỒNG KHỞI', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0919252599', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(494, 'KH0394', NULL, 'KIM HẢI 680', NULL, NULL, '364-NGUYỄN ÁI QUỐC--TP. BIÊN HÒA-ĐỒNG NAI', '364', 'NGUYỄN ÁI QUỐC', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0919252599', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(495, 'KH0405', NULL, 'BẢO TÍN 680', NULL, NULL, '93-PHẠM VĂN THUẬN--TP. BIÊN HÒA-ĐỒNG NAI', '93', 'PHẠM VĂN THUẬN', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '02513813108', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(496, 'KH0501', NULL, 'THÀNH TÍN 680', NULL, NULL, '1029-PHẠM VĂN THUẬN--TP. BIÊN HÒA-ĐỒNG NAI', '1029', 'PHẠM VĂN THUẬN', '', 'TP. BIÊN HÒA', 'ĐỒNG NAI', NULL, '0985661780', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(497, 'KH0504', NULL, 'KIM NGÂN 680', NULL, NULL, '266/11-ẤP 11-X. AN PHÚ TÂY-H. BÌNH CHÁNH-HCM', '266/11', 'ẤP 11', 'X. AN PHÚ TÂY', 'H. BÌNH CHÁNH', 'HCM', NULL, '0964471417', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(498, 'KH0402', NULL, 'XUÂN DUNG 680', NULL, NULL, '-QL 22-TT. CỦ CHI-H. CỦ CHI-HCM', '', 'QL 22', 'TT. CỦ CHI', 'H. CỦ CHI', 'HCM', NULL, '0985321070', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(499, 'KH0440', NULL, 'LỘC THỌ 680', NULL, NULL, '-QL22-TT. HÓC MÔN-H. HÓC MÔN-HCM', '', 'QL22', 'TT. HÓC MÔN', 'H. HÓC MÔN', 'HCM', NULL, '02838910305', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(500, 'KH0398', NULL, 'NGỌC BÍCH VÂN 680', NULL, NULL, '384-NGUYỄN VĂN CỪ-P. LỘC PHÁT-TP. BẢO LỘC-LÂM ĐỒNG', '384', 'NGUYỄN VĂN CỪ', 'P. LỘC PHÁT', 'TP. BẢO LỘC', 'LÂM ĐỒNG', NULL, '0982063380', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(501, 'KH0485', NULL, 'HUẤN HOÀNG 680', NULL, NULL, '---TP. BẢO LỘC-LÂM ĐỒNG', '', '', '', 'TP. BẢO LỘC', 'LÂM ĐỒNG', NULL, '0982405436', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(502, 'KH0486', NULL, 'KIM TUẤN TÚ 680', NULL, NULL, '---TP. BẢO LỘC-LÂM ĐỒNG', '', '', '', 'TP. BẢO LỘC', 'LÂM ĐỒNG', NULL, '02633864651', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(503, 'KH0413', NULL, 'KIM THANH II 680', NULL, NULL, '2D-NGUYỄN ĐÌNH CHIỂU--TP. TÂN AN-LONG AN', '2D', 'NGUYỄN ĐÌNH CHIỂU', '', 'TP. TÂN AN', 'LONG AN', NULL, '0982826672', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(504, 'KH0450', NULL, 'KIM PHƯỢNG 2 680', NULL, NULL, '460-CMT8--TP. TÂY NINH-TÂY NINH', '460', 'CMT8', '', 'TP. TÂY NINH', 'TÂY NINH', NULL, '0918383836', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(505, 'KH0381', NULL, 'THỦY 680', NULL, NULL, '-CHỢ HÒA KHÁNH-TT. CÁI BÈ-H. CÁI BÈ-TIỀN GIANG', '', 'CHỢ HÒA KHÁNH', 'TT. CÁI BÈ', 'H. CÁI BÈ', 'TIỀN GIANG', NULL, '02733819929', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(506, 'KH0503', NULL, 'KIM HƯNG 680', NULL, NULL, '245-ẤP 4-X. AN HỮU-H. CÁI BÈ-TIỀN GIANG', '245', 'ẤP 4', 'X. AN HỮU', 'H. CÁI BÈ', 'TIỀN GIANG', NULL, '02733767676', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(507, 'KH0542', NULL, 'TƯƠI 680', NULL, NULL, '92A-Ô 1 - KHU 2-TT. CHỢ GẠO-H. CHỢ GẠO-TIỀN GIANG', '92A', 'Ô 1 - KHU 2', 'TT. CHỢ GẠO', 'H. CHỢ GẠO', 'TIỀN GIANG', NULL, '02733835272 - 0962482082', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(508, 'KH0399', NULL, 'NGỌC HOA 680', NULL, NULL, '34-LÊ LỢI-P. 1-TP. MỸ THO-TIỀN GIANG', '34', 'LÊ LỢI', 'P. 1', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '02733871328', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(509, 'KH0361', NULL, 'KIM NGỌC HOA', NULL, NULL, '17-LÊ VĂN DUYỆT-P. 1-TP. MỸ THO-TIỀN GIANG', '17', 'LÊ VĂN DUYỆT', 'P. 1', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '0983970328 - 0733970328', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(510, 'KH0370', NULL, 'KIM YẾN 680', NULL, NULL, '28-LÊ VĂN DUYỆT-P. 1-TP. MỸ THO-TIỀN GIANG', '28', 'LÊ VĂN DUYỆT', 'P. 1', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '02733872079', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(511, 'KH0454', NULL, 'HÔNG THỦY 2 680', NULL, NULL, '-ĐINH BỘ LĨNH-P. 9-TP. MỸ THO-TIỀN GIANG', '', 'ĐINH BỘ LĨNH', 'P. 9', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '09751711268', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(512, 'KH0473', NULL, 'HỒNG THỦY 680', NULL, NULL, '468-KP5-P. 9-TP. MỸ THO-TIỀN GIANG', '468', 'KP5', 'P. 9', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '07536252115', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(513, 'KH0421', NULL, 'KIM TÍN 680', NULL, NULL, '-CHỢ MỸ THO--TP. MỸ THO-TIỀN GIANG', '', 'CHỢ MỸ THO', '', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '0907224145', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(514, 'KH0447', NULL, 'KIM TÍN IV 680', NULL, NULL, '112-LÊ THỊ HỒNG GẤM--TP. MỸ THO-TIỀN GIANG', '112', 'LÊ THỊ HỒNG GẤM', '', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '02733870155', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(515, 'KH0360', NULL, 'ĐẶNG KHÁ 3', NULL, NULL, '1-NGUYỄN HUỲNH ĐỨC--TP. MỸ THO-TIỀN GIANG', '1', 'NGUYỄN HUỲNH ĐỨC', '', 'TP. MỸ THO', 'TIỀN GIANG', NULL, '0918332453', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(516, 'KH0365', NULL, 'NGỌC LỄ 680', NULL, NULL, '---TX. GÒ CÔNG-TIỀN GIANG', '', '', '', 'TX. GÒ CÔNG', 'TIỀN GIANG', NULL, '0985321070', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(517, 'KH0431', NULL, 'KIM THẢO 680', NULL, NULL, '---TX. GÒ CÔNG-TIỀN GIANG', '', '', '', 'TX. GÒ CÔNG', 'TIỀN GIANG', NULL, '0913703974', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(518, 'KH0424', NULL, 'TƯ CÓ 680', NULL, NULL, '--TT. TRÀ CÚ-H. TRÀ CÚ-TRÀ VINH', '', '', 'TT. TRÀ CÚ', 'H. TRÀ CÚ', 'TRÀ VINH', NULL, '01215822666', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(519, 'KH0390', NULL, 'MƯỜI TUẤN THẢO 680', NULL, NULL, '---H. TRÀ CÚ-TRÀ VINH', '', '', '', 'H. TRÀ CÚ', 'TRÀ VINH', NULL, '01243221199', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(520, 'KH0374', NULL, 'PHÚ QUÝ 2', NULL, NULL, '80-ĐỘC LẬP-P. 2-TP. TRÀ VINH-TRÀ VINH', '80', 'ĐỘC LẬP', 'P. 2', 'TP. TRÀ VINH', 'TRÀ VINH', NULL, '02943753588', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(521, 'KH0375', NULL, 'PHƯƠNG DUNG 680', NULL, NULL, '03-VÕ THỊ SÁU-P. 3-TP. TRÀ VINH-TRÀ VINH', '03', 'VÕ THỊ SÁU', 'P. 3', 'TP. TRÀ VINH', 'TRÀ VINH', NULL, '01687373722', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL),
(522, 'KH0388', NULL, 'MỸ NGỌC 680', NULL, NULL, '56-ĐƯỜNG 1/5-P. 1-TP. VĨNH LONG-VĨNH LONG', '56', 'ĐƯỜNG 1/5', 'P. 1', 'TP. VĨNH LONG', 'VĨNH LONG', NULL, '0975015878', 6, 1, NULL, '2019-05-21 15:09:40', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_import_liabilities`
--

DROP TABLE IF EXISTS `gold_import_liabilities`;
CREATE TABLE IF NOT EXISTS `gold_import_liabilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_liabilities`
--

DROP TABLE IF EXISTS `gold_liabilities`;
CREATE TABLE IF NOT EXISTS `gold_liabilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_liabilities_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL COMMENT 'id khách hàng',
  `saler_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tên người bán',
  `date` timestamp NULL DEFAULT NULL COMMENT 'ngày công nợ',
  `age_sell` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tuổi ban',
  `exchange_g10_credit` double NOT NULL DEFAULT '0' COMMENT 'Qua ra vàng 10 (ghi có)',
  `wage_credit` double NOT NULL DEFAULT '0' COMMENT 'Tiền công (ghi có)',
  `exchange_g10_debit` double NOT NULL DEFAULT '0' COMMENT 'Qua ra vàng 10 (ghi nợ)',
  `wage_debit` double NOT NULL DEFAULT '0' COMMENT 'Qua ra vàng 10 (ghi nợ)',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_products`
--

DROP TABLE IF EXISTS `gold_products`;
CREATE TABLE IF NOT EXISTS `gold_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bar_code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'mã vạch, duy nhất',
  `product_code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mã sản phẩm, có thể trùng',
  `product_name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'tên sản phẩm, có thể trùng',
  `product_unit_id` int(11) NOT NULL COMMENT 'Đơn vị Tính',
  `total_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng trọng lượng của sản phẩm',
  `gem_weight` double NOT NULL DEFAULT '0' COMMENT 'Trong lượng của đá quý trong sản phẩm',
  `gold_weight` double NOT NULL DEFAULT '0' COMMENT 'trọng lượng của vàng trong sản phẩm',
  `qty` int(11) NOT NULL DEFAULT '1' COMMENT 'Số lượng',
  `retail_machining_fee` double NOT NULL DEFAULT '0' COMMENT 'công lẻ',
  `whole_machining_fee` double NOT NULL DEFAULT '0' COMMENT 'Công sỉ',
  `fund_machining_fee` double NOT NULL DEFAULT '0' COMMENT 'Công vốn',
  `input_date` timestamp NULL DEFAULT NULL COMMENT 'Ngày nhập',
  `make_stemp_date` timestamp NULL DEFAULT NULL COMMENT 'Ngày làm tem',
  `stock_id` int(11) NOT NULL COMMENT 'Khi hàng',
  `product_category_id` int(11) NOT NULL COMMENT 'Loại hàng',
  `product_group_id` int(11) NOT NULL COMMENT 'Nhóm hàng',
  `product_type_id` int(11) NOT NULL COMMENT 'Loại vàng',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT 'Tình trạng\n0 - hết hàng\n1- còn hàng',
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Ghi chú',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bar_code_UNIQUE` (`bar_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_categories`
--

DROP TABLE IF EXISTS `gold_product_categories`;
CREATE TABLE IF NOT EXISTS `gold_product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Loại hàng: Nhẫn, Vòng, …',
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_categories`
--

INSERT INTO `gold_product_categories` (`id`, `name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'Nhẫn', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(2, 'Vòng', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(3, 'Bông', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(4, 'Dây', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(5, 'Lắc', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(6, 'Mặt', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_groups`
--

DROP TABLE IF EXISTS `gold_product_groups`;
CREATE TABLE IF NOT EXISTS `gold_product_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Nhóm hàng: Nhẫn cưới, Bông',
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` int(11) DEFAULT NULL,
  `deleted_by` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_groups`
--

INSERT INTO `gold_product_groups` (`id`, `name`, `product_category_id`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'Bông đít đẩy', 3, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(2, 'Bông giò gà', 3, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(3, 'Dây cổ', 4, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(4, 'Lắc tay', 5, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(5, 'Nhẫn cưới', NULL, '2019-04-23 03:19:21', NULL, NULL, NULL, NULL, NULL),
(6, 'Vòng', NULL, '2019-05-03 16:59:55', 2, NULL, NULL, NULL, NULL),
(7, 'Nhẫn nữ', NULL, '2019-05-03 17:00:03', 2, NULL, NULL, NULL, NULL),
(8, 'Nhẫn nam', NULL, '2019-05-03 17:12:01', 2, NULL, NULL, NULL, NULL),
(9, 'Mặt dây', NULL, '2019-05-03 17:12:01', 2, NULL, NULL, NULL, NULL),
(10, 'Bông khoen', NULL, '2019-05-03 17:12:11', 2, NULL, NULL, NULL, NULL),
(11, 'Bông mì kiểu', NULL, '2019-05-03 17:16:24', 2, NULL, NULL, NULL, NULL),
(12, 'Bông tòn teng', NULL, '2019-05-03 17:18:16', 2, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_types`
--

DROP TABLE IF EXISTS `gold_product_types`;
CREATE TABLE IF NOT EXISTS `gold_product_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Loại vàng: 610, 680, …',
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_types`
--

INSERT INTO `gold_product_types` (`id`, `name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, '610', '2019-04-20 04:56:02', 1, NULL, NULL, NULL, NULL),
(2, '680', '2019-04-20 04:56:02', 1, NULL, NULL, NULL, NULL),
(3, '600', '2019-05-06 17:12:40', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_units`
--

DROP TABLE IF EXISTS `gold_product_units`;
CREATE TABLE IF NOT EXISTS `gold_product_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_units`
--

INSERT INTO `gold_product_units` (`id`, `name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'Đôi', '2019-04-20 08:08:57', 1, NULL, NULL, NULL, NULL),
(2, 'Chiếc', '2019-04-20 08:09:02', 1, NULL, NULL, NULL, NULL),
(3, 'Bộ', '2019-04-20 08:11:16', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_orders`
--

DROP TABLE IF EXISTS `gold_sale_orders`;
CREATE TABLE IF NOT EXISTS `gold_sale_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL COMMENT 'Khách hàng',
  `debt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày công nợ',
  `days_diff` int(11) NOT NULL COMMENT 'Số Ngày',
  `exchange_g10` double NOT NULL COMMENT 'Q10 từ bản công nợ',
  `wage` double NOT NULL COMMENT 'Tiền công từ bản công nợ',
  `saler_id` int(11) NOT NULL COMMENT 'Người ban',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày đơn hàng',
  `order_no` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'tự phát sinh \rFormat (DHYYMMDD-###\rVí dụ: DH190418-001',
  `pay_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày thu tiền, dự kiến',
  `actual_weight` double NOT NULL COMMENT 'Tổng cân thực tế',
  `reduce` double NOT NULL DEFAULT '0' COMMENT 'Giảm trừ (số tiền)',
  `total_wage` double NOT NULL DEFAULT '0' COMMENT 'Tổng tiền công',
  `total_exchange_g10` double NOT NULL DEFAULT '0',
  `reason_pay_not_enough` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Lý do chưa thu hết công nợ cũ/tiền công',
  `other_orders` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Khách đặt',
  `order_type` int(11) NOT NULL DEFAULT '2' COMMENT '2: đơn hàng thường\\n1: đơn hàng nhanh',
  `gold_age_1` double NOT NULL DEFAULT '0' COMMENT 'Tuổi vàng đồ đúc',
  `gold_age_2` double NOT NULL DEFAULT '0' COMMENT 'tuổi vàng đồ bọng',
  `gold_age_3` double NOT NULL DEFAULT '0' COMMENT 'Tuổi vàng hàng khác',
  `pay_total_wage` double NOT NULL DEFAULT '0' COMMENT 'Tổng tiền công thanh toán',
  `sampling_discount` double NOT NULL DEFAULT '0' COMMENT 'Chiếc khấu, dùng để làm mẫu cho ấc dong detail',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_order_details`
--

DROP TABLE IF EXISTS `gold_sale_order_details`;
CREATE TABLE IF NOT EXISTS `gold_sale_order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `sort_no` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL,
  `age` double NOT NULL DEFAULT '0' COMMENT 'Tuổi ban',
  `discount_wage` double NOT NULL DEFAULT '0' COMMENT '% chiếc khấu tiền công',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_order_pays`
--

DROP TABLE IF EXISTS `gold_sale_order_pays`;
CREATE TABLE IF NOT EXISTS `gold_sale_order_pays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `pay_method` int(11) NOT NULL DEFAULT '0' COMMENT '1 - Thảo\n2 - Dẻ\n3 - Tiền mặt\n4 - Đúc\n5 - Bộng',
  `description` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0' COMMENT 'Số lượng',
  `total_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng cân\\r(Chỉ)',
  `gem_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng đá\\r(Chỉ)',
  `gold_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng vàng 18\\r(Chỉ)',
  `money` double NOT NULL DEFAULT '0' COMMENT 'Tiền mặt',
  `gold_age` double NOT NULL DEFAULT '0' COMMENT 'Tuổi (%)',
  `converted_price` double NOT NULL DEFAULT '0',
  `exchange_g10` double NOT NULL DEFAULT '0' COMMENT 'Vàng quy 10\\r(Chỉ)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_order_returns`
--

DROP TABLE IF EXISTS `gold_sale_order_returns`;
CREATE TABLE IF NOT EXISTS `gold_sale_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `sort_no` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL COMMENT '1 - Đồ đúc\n2 - Đồ bộng\n3 - Hàng khác',
  `qty` int(11) NOT NULL DEFAULT '0' COMMENT 'Số lượng (mon)',
  `total_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng cân\r(Chỉ)',
  `gem_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng đá\r(Chỉ)',
  `gold_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng vàng 18\r(Chỉ)',
  `gold_age` double NOT NULL DEFAULT '0' COMMENT 'Tuổi (%)',
  `exchange_g10` double NOT NULL DEFAULT '0' COMMENT 'Vàng quy 10\r(Chỉ)',
  `wage` double NOT NULL DEFAULT '0' COMMENT 'Tiền công',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_stocks`
--

DROP TABLE IF EXISTS `gold_stocks`;
CREATE TABLE IF NOT EXISTS `gold_stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Kho hàng',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_06_23_125201_create_categories_table', 1),
(2, '2018_06_23_125201_create_cms_apicustom_table', 1),
(3, '2018_06_23_125201_create_cms_apikey_table', 1),
(4, '2018_06_23_125201_create_cms_dashboard_table', 1),
(5, '2018_06_23_125201_create_cms_email_queues_table', 1),
(6, '2018_06_23_125201_create_cms_email_templates_table', 1),
(7, '2018_06_23_125201_create_cms_logs_table', 1),
(8, '2018_06_23_125201_create_cms_menus_privileges_table', 1),
(9, '2018_06_23_125201_create_cms_menus_table', 1),
(10, '2018_06_23_125201_create_cms_moduls_table', 1),
(11, '2018_06_23_125201_create_cms_notifications_table', 1),
(12, '2018_06_23_125201_create_cms_privileges_roles_table', 1),
(13, '2018_06_23_125201_create_cms_privileges_table', 1),
(14, '2018_06_23_125201_create_cms_settings_table', 1),
(15, '2018_06_23_125201_create_cms_statistic_components_table', 1),
(16, '2018_06_23_125201_create_cms_statistics_table', 1),
(17, '2018_06_23_125201_create_cms_users_table', 1),
(18, '2018_06_23_125201_create_customers_table', 1),
(19, '2018_06_23_125201_create_employees_table', 1),
(20, '2018_06_23_125201_create_products_table', 1),
(21, '2018_06_23_125201_create_trans_detail_table', 1),
(22, '2018_06_23_125201_create_trans_table', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
