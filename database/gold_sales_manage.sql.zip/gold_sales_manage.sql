-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 25, 2019 at 11:41 AM
-- Server version: 5.7.23
-- PHP Version: 7.1.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gold_sales_manage`
--
CREATE DATABASE IF NOT EXISTS `gold_sales_manage` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `gold_sales_manage`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Tire'),
(2, 'Sparepart'),
(3, 'Oil');

-- --------------------------------------------------------

--
-- Table structure for table `cms_apicustom`
--

DROP TABLE IF EXISTS `cms_apicustom`;
CREATE TABLE IF NOT EXISTS `cms_apicustom` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `permalink` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tabel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aksi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kolom` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderby` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_query_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sql_where` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `method_type` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci,
  `responses` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_apikey`
--

DROP TABLE IF EXISTS `cms_apikey`;
CREATE TABLE IF NOT EXISTS `cms_apikey` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `screetkey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `status` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_dashboard`
--

DROP TABLE IF EXISTS `cms_dashboard`;
CREATE TABLE IF NOT EXISTS `cms_dashboard` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_email_queues`
--

DROP TABLE IF EXISTS `cms_email_queues`;
CREATE TABLE IF NOT EXISTS `cms_email_queues` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `send_at` datetime DEFAULT NULL,
  `email_recipient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_cc_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_content` text COLLATE utf8mb4_unicode_ci,
  `email_attachments` text COLLATE utf8mb4_unicode_ci,
  `is_sent` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_email_templates`
--

DROP TABLE IF EXISTS `cms_email_templates`;
CREATE TABLE IF NOT EXISTS `cms_email_templates` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_email_templates`
--

INSERT INTO `cms_email_templates` (`id`, `name`, `slug`, `subject`, `content`, `description`, `from_name`, `from_email`, `cc_email`, `created_at`, `updated_at`) VALUES
(1, 'Email Template Forgot Password Backend', 'forgot_password_backend', 'VNJ - Cấp lại mật khẩu', '<p>Chào bạn,</p>\r\n<p>Đây là mật khẩu mới được cấp lại cho bạn:<b>[password]</b></p><p><br></p>\r\n<p></p>\r\n<p>--</p>\r\n<p>Regards,</p>\r\n<p>Admin</p>', '[password]', 'System', 'system@crudbooster.com', NULL, '2018-03-28 16:38:52', '2019-04-20 16:59:03');

-- --------------------------------------------------------

--
-- Table structure for table `cms_logs`
--

DROP TABLE IF EXISTS `cms_logs`;
CREATE TABLE IF NOT EXISTS `cms_logs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `useragent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `id_cms_users` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_logs`
--

INSERT INTO `cms_logs` (`id`, `ipaddress`, `useragent`, `url`, `description`, `details`, `id_cms_users`, `created_at`, `updated_at`) VALUES
(1, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com login with IP Address ::1', '', 1, '2019-04-19 10:22:32', NULL),
(2, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/8', 'Sửa dữ liệu Loại hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>icon</td><td>fa fa-glass</td><td>fa fa-th-large</td></tr><tr><td>sorting</td><td>8</td><td></td></tr></tbody></table>', 1, '2019-04-19 18:15:29', NULL),
(3, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Nhẫn trong Loại hàng', '', 1, '2019-04-19 18:18:25', NULL),
(4, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Vòng trong Loại hàng', '', 1, '2019-04-19 18:18:36', NULL),
(5, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Bông trong Loại hàng', '', 1, '2019-04-19 18:19:10', NULL),
(6, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Dây trong Loại hàng', '', 1, '2019-04-19 18:19:14', NULL),
(7, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Lắc trong Loại hàng', '', 1, '2019-04-19 18:19:18', NULL),
(8, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_categories/add-save', 'Tạo mới dữ liệu Mặt trong Loại hàng', '', 1, '2019-04-19 18:19:23', NULL),
(9, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO 68 trong Kho hàng', '', 1, '2019-04-19 18:30:19', NULL),
(10, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO A trong Kho hàng', '', 1, '2019-04-19 18:30:33', NULL),
(11, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO B trong Kho hàng', '', 1, '2019-04-19 18:30:38', NULL),
(12, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO C trong Kho hàng', '', 1, '2019-04-19 18:30:43', NULL),
(13, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho hàng sửa trong Kho hàng', '', 1, '2019-04-19 18:31:02', NULL),
(14, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 1 trong Kho hàng', '', 1, '2019-04-19 18:31:24', NULL),
(15, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 2 trong Kho hàng', '', 1, '2019-04-19 18:31:32', NULL),
(16, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 3 trong Kho hàng', '', 1, '2019-04-19 18:31:37', NULL),
(17, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 4 trong Kho hàng', '', 1, '2019-04-19 18:31:43', NULL),
(18, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 5 trong Kho hàng', '', 1, '2019-04-19 18:31:50', NULL),
(19, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 6 trong Kho hàng', '', 1, '2019-04-19 18:31:55', NULL),
(20, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 7 trong Kho hàng', '', 1, '2019-04-19 18:32:03', NULL),
(21, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho phát 8 trong Kho hàng', '', 1, '2019-04-19 18:32:08', NULL),
(22, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu KHO VIET NGOC trong Kho hàng', '', 1, '2019-04-19 18:32:32', NULL),
(23, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Bông đít đẩy trong Nhóm hàng', '', 1, '2019-04-19 18:51:31', NULL),
(24, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Bông giò gà trong Nhóm hàng', '', 1, '2019-04-19 18:51:59', NULL),
(25, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Dây cổ trong Nhóm hàng', '', 1, '2019-04-19 18:52:38', NULL),
(26, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_groups/add-save', 'Tạo mới dữ liệu Lắc tay trong Nhóm hàng', '', 1, '2019-04-19 18:52:58', NULL),
(27, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_types/add-save', 'Tạo mới dữ liệu 610 trong Loại vàng', '', 1, '2019-04-19 18:53:15', NULL),
(28, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_types/add-save', 'Tạo mới dữ liệu 680 trong Loại vàng', '', 1, '2019-04-19 18:53:24', NULL),
(29, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-20 04:45:44', NULL),
(30, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu Kho test trong Kho hàng', '', 1, '2019-04-20 04:56:54', NULL),
(31, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/delete/15', 'Xóa dữ liệu Kho test trong Kho hàng', '', 1, '2019-04-20 04:57:45', NULL),
(32, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/edit-save/15', 'Sửa dữ liệu Kho test aaa trong Kho hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>Kho test</td><td>Kho test aaa</td></tr><tr><td>created_by</td><td></td><td></td></tr><tr><td>updated_by</td><td></td><td></td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>delete_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 05:00:08', NULL),
(33, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/edit-save/15', 'Sửa dữ liệu Kho test aaa trong Kho hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>notes</td><td>test aaaakkkk</td><td>test aaaakkkkkmomk</td></tr><tr><td>created_by</td><td></td><td></td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>delete_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 05:39:42', NULL),
(34, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/add-save', 'Tạo mới dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 05:40:31', NULL),
(35, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/delete/16', 'Xóa dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 05:41:09', NULL),
(36, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_stocks/delete/15', 'Xóa dữ liệu Kho test aaa trong Kho hàng', '', 1, '2019-04-20 05:41:14', NULL),
(37, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Quản lý users trong Menu Management', '', 1, '2019-04-20 06:02:52', NULL),
(38, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Danh sách user trong Menu Management', '', 1, '2019-04-20 06:03:57', NULL),
(39, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/13', 'Sửa dữ liệu Danh sách user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>icon</td><td>fa fa-user</td><td>fa fa-navicon</td></tr><tr><td>parent_id</td><td>12</td><td></td></tr></tbody></table>', 1, '2019-04-20 06:05:45', NULL),
(40, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/users/delete-image', 'Xóa ảnh của Super Admin trong Users Management', '', 1, '2019-04-20 06:58:27', NULL),
(41, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/users/edit-save/1', 'Sửa dữ liệu Super Admin trong Users Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>photo</td><td></td><td>uploads/1/2019-04/vnjlogo.png</td></tr><tr><td>password</td><td>$2y$10$Jevyu0o1N651oyZjHyd0Y.367dhBWYrtCTp8jxak40DaWpGjZhw6a</td><td></td></tr><tr><td>id_cms_privileges</td><td>1</td><td></td></tr><tr><td>status</td><td>Active</td><td></td></tr></tbody></table>', 1, '2019-04-20 06:59:05', NULL),
(42, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-20 06:59:17', NULL),
(43, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-20 06:59:20', NULL),
(44, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/12', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>#</td><td></td></tr><tr><td>sorting</td><td>5</td><td></td></tr></tbody></table>', 1, '2019-04-20 07:00:56', NULL),
(45, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tạo mới user trong Menu Management', '', 1, '2019-04-20 07:02:39', NULL),
(46, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/13', 'Sửa dữ liệu Danh sách user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>12</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-04-20 07:03:02', NULL),
(47, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Danh mục trong Menu Management', '', 1, '2019-04-20 07:14:04', NULL),
(48, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/9', 'Sửa dữ liệu Kho hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:06:44', NULL),
(49, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/8', 'Sửa dữ liệu Loại hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:06:56', NULL),
(50, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/10', 'Sửa dữ liệu Nhóm hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:07:08', NULL),
(51, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/11', 'Sửa dữ liệu Loại vàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:07:21', NULL),
(52, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_units/add-save', 'Tạo mới dữ liệu Đôi trong Đơn vị tính', '', 1, '2019-04-20 08:08:57', NULL),
(53, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_units/add-save', 'Tạo mới dữ liệu Chiếc trong Đơn vị tính', '', 1, '2019-04-20 08:09:02', NULL),
(54, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_product_units/add-save', 'Tạo mới dữ liệu Bộ trong Đơn vị tính', '', 1, '2019-04-20 08:11:16', NULL),
(55, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/9', 'Sửa dữ liệu Kho hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>path</td><td>AdminGoldProductStocksControllerGetIndex</td><td>AdminGoldStocksControllerGetIndex</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:16:01', NULL),
(56, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/edit-save/16', 'Sửa dữ liệu tesst 2 trong Kho hàng', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>notes</td><td></td><td>fhdgf</td></tr><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 08:17:03', NULL),
(57, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/delete/16', 'Xóa dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 08:18:01', NULL),
(58, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/delete/16', 'Xóa dữ liệu tesst 2 trong Kho hàng', '', 1, '2019-04-20 08:20:23', NULL),
(59, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_stocks/delete/15', 'Xóa dữ liệu Kho test aaa trong Kho hàng', '', 1, '2019-04-20 08:20:29', NULL),
(60, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/17', 'Sửa dữ liệu Sản phẩm trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>8</td><td></td></tr></tbody></table>', 1, '2019-04-20 08:55:07', NULL),
(61, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/add-save', 'Tạo mới dữ liệu do_duc trong Settings', '', 1, '2019-04-20 16:33:57', NULL),
(62, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/add-save', 'Tạo mới dữ liệu do_bong trong Settings', '', 1, '2019-04-20 16:34:25', NULL),
(63, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/edit-save/17', 'Sửa dữ liệu  trong Settings', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>do_duc</td><td></td></tr><tr><td>content</td><td>625</td><td></td></tr><tr><td>content_input_type</td><td>number</td><td>text</td></tr><tr><td>dataenum</td><td></td><td></td></tr><tr><td>helper</td><td></td><td>Bạn chỉ được nhập số</td></tr></tbody></table>', 1, '2019-04-20 16:37:09', NULL),
(64, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/edit-save/18', 'Sửa dữ liệu  trong Settings', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>name</td><td>do_bong</td><td></td></tr><tr><td>content</td><td>635</td><td></td></tr><tr><td>content_input_type</td><td>number</td><td>text</td></tr><tr><td>dataenum</td><td></td><td></td></tr><tr><td>helper</td><td></td><td>Bạn chỉ được nhập số</td></tr></tbody></table>', 1, '2019-04-20 16:37:32', NULL),
(65, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-20 16:41:42', NULL),
(66, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-20 16:54:53', NULL),
(67, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/email_templates/edit-save/1', 'Sửa dữ liệu Email Template Forgot Password Backend trong Email Templates', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>subject</td><td></td><td>VNJ - Cấp lại mật khẩu</td></tr><tr><td>content</td><td><p>Hi,</p><p>Someone requested forgot password, here is your new password : </p><p>[password]</p><p><br></p><p>--</p><p>Regards,</p><p>Admin</p></td><td><p>Chào bạn,</p>\r\n<p>Đây là mật khẩu mới được cấp lại cho bạn:<b>[password]</b></p><p><br></p>\r\n<p></p>\r\n<p>--</p>\r\n<p>Regards,</p>\r\n<p>Admin</p></td></tr><tr><td>cc_email</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 16:59:03', NULL),
(68, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products/add-save', 'Tạo mới dữ liệu buhk87654 trong Sản phẩm', '', 1, '2019-04-20 17:43:39', NULL),
(69, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products/edit-save/1', 'Sửa dữ liệu buhk87654 trong Sản phẩm', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>updated_by</td><td></td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 17:44:20', NULL),
(70, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products/edit-save/1', 'Sửa dữ liệu buhk87654 trong Sản phẩm', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>status</td><td>0</td><td>1</td></tr><tr><td>deleted_at</td><td></td><td></td></tr><tr><td>deleted_by</td><td></td><td></td></tr></tbody></table>', 1, '2019-04-20 17:45:13', NULL),
(71, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-21 01:00:41', NULL),
(72, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 07:37:30', NULL),
(73, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 16:44:25', NULL),
(74, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 16:45:58', NULL),
(75, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 17:08:25', NULL),
(76, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 17:08:29', NULL),
(77, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 17:24:20', NULL),
(78, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-22 17:28:09', NULL),
(79, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-22 17:28:13', NULL),
(80, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 01:17:41', NULL),
(81, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 03:09:22', NULL),
(82, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 03:09:32', NULL),
(83, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tuổi vàng trong Menu Management', '', 1, '2019-04-23 05:11:08', NULL),
(84, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/users/add-save', 'Tạo mới dữ liệu Võ Tuấn Nguyên trong Quản lý Users', '', 1, '2019-04-23 05:13:21', NULL),
(85, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 05:13:28', NULL),
(86, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-04-23 05:13:51', NULL),
(87, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:13:58', NULL),
(88, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_products', 'Try view the data :name at Sản phẩm', '', 2, '2019-04-23 05:14:06', NULL),
(89, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-04-23 05:14:18', NULL),
(90, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 05:14:22', NULL),
(91, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 05:23:44', NULL),
(92, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-04-23 05:23:59', NULL),
(93, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:24:03', NULL),
(94, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:24:15', NULL),
(95, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:25:40', NULL),
(96, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/settings/show', 'Try view the data Setting at Setting', '', 2, '2019-04-23 05:25:43', NULL),
(97, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-04-23 05:29:56', NULL),
(98, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 05:30:00', NULL),
(99, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/delete/18', 'Xóa dữ liệu Tuổi vàng trong Menu Management', '', 1, '2019-04-23 05:33:09', NULL),
(100, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tuổi vàng trong Menu Management', '', 1, '2019-04-23 05:46:52', NULL),
(101, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'admin@crudbooster.com đăng xuất', '', 1, '2019-04-23 05:47:47', NULL),
(102, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'tuannguyen8888@gmail.com đăng nhập với địa chỉ IP ::1', '', 2, '2019-04-23 05:48:04', NULL),
(103, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/logout', 'tuannguyen8888@gmail.com đăng xuất', '', 2, '2019-04-23 08:48:36', NULL),
(104, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-23 08:48:38', NULL),
(105, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/19', 'Sửa dữ liệu Khách hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>3</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:04:59', NULL),
(106, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/16', 'Sửa dữ liệu Đơn vị tính trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>parent_id</td><td>15</td><td></td></tr><tr><td>sorting</td><td>6</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:05:18', NULL),
(107, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/12', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:05:37', NULL),
(108, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/12', 'Sửa dữ liệu Quản lý users trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:06:10', NULL),
(109, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/14', 'Sửa dữ liệu Tạo mới user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>12</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:06:22', NULL),
(110, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/13', 'Sửa dữ liệu Danh sách user trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>parent_id</td><td>12</td><td></td></tr><tr><td>sorting</td><td>2</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:07:06', NULL),
(111, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_customers/add-save', 'Tạo mới dữ liệu  trong Khách hàng', '', 1, '2019-04-23 09:20:04', NULL),
(112, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/gold_customers/add-save', 'Tạo mới dữ liệu  trong Khách hàng', '', 1, '2019-04-23 09:40:09', NULL),
(113, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/20', 'Sửa dữ liệu Công nợ trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 09:59:44', NULL),
(114, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/21', 'Sửa dữ liệu Đơn hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>color</td><td></td><td>normal</td></tr><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 17:04:36', NULL),
(115, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/edit-save/21', 'Sửa dữ liệu Đơn hàng trong Menu Management', '<table class=\"table table-striped\"><thead><tr><th>Key</th><th>Old Value</th><th>New Value</th></thead><tbody><tr><td>sorting</td><td>4</td><td></td></tr></tbody></table>', 1, '2019-04-23 17:04:53', NULL),
(116, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/login', 'admin@crudbooster.com đăng nhập với địa chỉ IP ::1', '', 1, '2019-04-24 16:11:26', NULL),
(117, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Kiểm tra đơn hàng trong Menu Management', '', 1, '2019-04-24 16:15:32', NULL),
(118, '::1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 'http://localhost:8888/admin/menu_management/add-save', 'Tạo mới dữ liệu Tạo đơn hàng mới trong Menu Management', '', 1, '2019-04-24 16:20:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_menus`
--

DROP TABLE IF EXISTS `cms_menus`;
CREATE TABLE IF NOT EXISTS `cms_menus` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'url',
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_dashboard` tinyint(1) NOT NULL DEFAULT '0',
  `id_cms_privileges` int(11) DEFAULT NULL,
  `sorting` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_menus`
--

INSERT INTO `cms_menus` (`id`, `name`, `type`, `path`, `color`, `icon`, `parent_id`, `is_active`, `is_dashboard`, `id_cms_privileges`, `sorting`, `created_at`, `updated_at`) VALUES
(1, 'Categories', 'Route', 'AdminCategoriesControllerGetIndex', NULL, 'fa fa-tags', 0, 0, 0, 1, 4, '2018-03-28 17:10:57', NULL),
(2, 'Products', 'Route', 'AdminProductsControllerGetIndex', NULL, 'fa fa-cubes', 0, 0, 0, 1, 2, '2018-03-28 17:46:14', NULL),
(3, 'Employees', 'Route', 'AdminEmployeesControllerGetIndex', NULL, 'fa fa-users', 0, 0, 0, 1, 3, '2018-03-28 17:46:40', NULL),
(4, 'Report Product Sales', 'Route', 'AdminReportProductSalesControllerGetIndex', NULL, 'fa fa-glass', 0, 0, 0, 1, 5, '2018-03-28 17:48:57', NULL),
(5, 'Report Profit Sales', 'Route', 'AdminReportProfitSalesControllerGetIndex', NULL, 'fa fa-table', 0, 0, 0, 1, 6, '2018-03-28 17:49:35', NULL),
(6, 'Stock Report', 'Route', 'AdminStockReportControllerGetIndex', NULL, 'fa fa-table', 0, 0, 0, 1, 7, '2018-03-28 18:24:43', NULL),
(7, 'History Order', 'Route', 'AdminTransControllerGetIndex', NULL, 'fa fa-th', 0, 0, 0, 1, 1, '2018-06-23 05:49:11', NULL),
(8, 'Loại hàng', 'Route', 'AdminGoldProductCategoriesControllerGetIndex', 'normal', 'fa fa-th-large', 15, 1, 0, 1, 2, '2019-04-19 18:09:36', '2019-04-20 08:06:56'),
(9, 'Kho hàng', 'Route', 'AdminGoldStocksControllerGetIndex', 'normal', 'fa fa-hospital-o', 15, 1, 0, 1, 1, '2019-04-19 18:25:43', '2019-04-20 08:16:01'),
(10, 'Nhóm hàng', 'Route', 'AdminGoldProductGroupsControllerGetIndex', 'normal', 'fa fa-th', 15, 1, 0, 1, 3, '2019-04-19 18:33:57', '2019-04-20 08:07:08'),
(11, 'Loại vàng', 'Route', 'AdminGoldProductTypesControllerGetIndex', 'normal', 'fa fa-unlink', 15, 1, 0, 1, 4, '2019-04-19 18:48:53', '2019-04-20 08:07:21'),
(12, 'Quản lý users', 'URL', '#', 'normal', 'fa fa-group', 0, 1, 0, 1, 6, '2019-04-20 06:02:52', '2019-04-23 09:06:10'),
(13, 'Danh sách user', 'Module', 'users', 'normal', 'fa fa-navicon', 12, 1, 0, 1, 2, '2019-04-20 06:03:57', '2019-04-23 09:07:06'),
(14, 'Tạo mới user', 'URL', '/admin/users/add', 'normal', 'fa fa-plus', 12, 1, 0, 1, 1, '2019-04-20 07:02:39', '2019-04-23 09:06:22'),
(15, 'Danh mục', 'URL', '#', 'normal', 'fa fa-sitemap', 0, 1, 0, 1, 1, '2019-04-20 07:14:04', NULL),
(16, 'Đơn vị tính', 'Route', 'AdminGoldProductUnitsControllerGetIndex', 'normal', 'fa fa-stack-overflow', 15, 1, 0, 1, 6, '2019-04-20 08:00:45', '2019-04-23 09:05:18'),
(17, 'Sản phẩm', 'Route', 'AdminGoldProductsControllerGetIndex', 'normal', 'fa fa-cubes', 0, 1, 0, 1, 2, '2019-04-20 08:24:54', '2019-04-20 08:55:07'),
(18, 'Tuổi vàng', 'URL', '/admin/settings/show?group=Tuổi+vàng&m=0', 'normal', 'fa fa-magic', 15, 1, 0, 1, 5, '2019-04-23 05:46:52', NULL),
(19, 'Khách hàng', 'Route', 'AdminGoldCustomersControllerGetIndex', 'normal', 'fa fa-male', 0, 1, 0, 1, 3, '2019-04-23 08:54:43', '2019-04-23 09:04:59'),
(20, 'Công nợ', 'Route', 'AdminGoldLiabilitiesControllerGetIndex', 'normal', 'fa fa-money', 0, 1, 0, 1, 5, '2019-04-23 09:49:28', '2019-04-23 09:59:44'),
(21, 'Đơn hàng', 'Route', 'AdminGoldSaleOrdersControllerGetIndex', 'normal', 'fa fa-diamond', 0, 1, 0, 1, 4, '2019-04-23 16:50:00', '2019-04-23 17:04:53'),
(22, 'Kiểm tra đơn hàng', 'Module', 'gold_sale_orders', 'normal', 'fa fa-th-list', 21, 1, 0, 1, 2, '2019-04-24 16:15:32', NULL),
(23, 'Tạo đơn hàng mới', 'URL', '/admin/gold_sale_orders/add', 'normal', 'fa fa-cart-plus', 21, 1, 0, 1, 1, '2019-04-24 16:20:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_menus_privileges`
--

DROP TABLE IF EXISTS `cms_menus_privileges`;
CREATE TABLE IF NOT EXISTS `cms_menus_privileges` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_cms_menus` int(11) DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_menus_privileges`
--

INSERT INTO `cms_menus_privileges` (`id`, `id_cms_menus`, `id_cms_privileges`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(22, 15, 5),
(23, 15, 2),
(24, 15, 3),
(25, 15, 4),
(26, 15, 1),
(33, 8, 5),
(34, 8, 2),
(35, 8, 3),
(36, 8, 4),
(37, 8, 1),
(38, 10, 5),
(39, 10, 2),
(40, 10, 3),
(41, 10, 4),
(42, 10, 1),
(43, 11, 5),
(44, 11, 2),
(45, 11, 3),
(46, 11, 4),
(47, 11, 1),
(48, 9, 5),
(49, 9, 2),
(50, 9, 3),
(51, 9, 4),
(52, 9, 1),
(53, 17, 5),
(54, 17, 2),
(55, 17, 3),
(56, 17, 4),
(57, 17, 1),
(58, 18, 5),
(59, 18, 4),
(60, 18, 1),
(61, 19, 5),
(62, 19, 2),
(63, 19, 3),
(64, 19, 4),
(65, 19, 1),
(66, 16, 5),
(67, 16, 2),
(68, 16, 3),
(69, 16, 4),
(70, 16, 1),
(71, 12, 4),
(72, 14, 4),
(73, 13, 4),
(74, 20, 5),
(75, 20, 1),
(76, 21, 5),
(77, 21, 2),
(78, 21, 1),
(79, 22, 5),
(80, 22, 2),
(81, 22, 1),
(82, 23, 2),
(83, 23, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_moduls`
--

DROP TABLE IF EXISTS `cms_moduls`;
CREATE TABLE IF NOT EXISTS `cms_moduls` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_protected` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_moduls`
--

INSERT INTO `cms_moduls` (`id`, `name`, `icon`, `path`, `table_name`, `controller`, `is_protected`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Notifications', 'fa fa-cog', 'notifications', 'cms_notifications', 'NotificationsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(2, 'Privileges', 'fa fa-cog', 'privileges', 'cms_privileges', 'PrivilegesController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(3, 'Privileges Roles', 'fa fa-cog', 'privileges_roles', 'cms_privileges_roles', 'PrivilegesRolesController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(4, 'Quản lý Users', 'fa fa-users', 'users', 'cms_users', 'AdminCmsUsersController', 0, 1, '2018-03-28 16:38:50', NULL, NULL),
(5, 'Settings', 'fa fa-cog', 'settings', 'cms_settings', 'SettingsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(6, 'Module Generator', 'fa fa-database', 'module_generator', 'cms_moduls', 'ModulsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(7, 'Menu Management', 'fa fa-bars', 'menu_management', 'cms_menus', 'MenusController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(8, 'Email Templates', 'fa fa-envelope-o', 'email_templates', 'cms_email_templates', 'EmailTemplatesController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(9, 'Statistic Builder', 'fa fa-dashboard', 'statistic_builder', 'cms_statistics', 'StatisticBuilderController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(10, 'API Generator', 'fa fa-cloud-download', 'api_generator', '', 'ApiCustomController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(11, 'Log User Access', 'fa fa-flag-o', 'logs', 'cms_logs', 'LogsController', 1, 1, '2018-03-28 16:38:50', NULL, NULL),
(12, 'Categories', 'fa fa-tags', 'categories', 'categories', 'AdminCategoriesController', 0, 0, '2018-03-28 17:10:57', NULL, NULL),
(13, 'Products', 'fa fa-cubes', 'products', 'products', 'AdminProductsController', 0, 0, '2018-03-28 17:46:14', NULL, NULL),
(14, 'Employees', 'fa fa-users', 'employees', 'employees', 'AdminEmployeesController', 0, 0, '2018-03-28 17:46:40', NULL, NULL),
(15, 'Report Product Sales', 'fa fa-glass', 'report_product_sales', 'trans', 'AdminReportProductSalesController', 0, 0, '2018-03-28 17:48:57', NULL, NULL),
(16, 'Report Profit Sales', 'fa fa-table', 'report_profit_sales', 'trans', 'AdminReportProfitSalesController', 0, 0, '2018-03-28 17:49:35', NULL, NULL),
(17, 'Stock Report', 'fa fa-table', 'stock_report', 'products', 'AdminStockReportController', 0, 0, '2018-03-28 18:24:43', NULL, NULL),
(18, 'History Order', 'fa fa-th', 'trans', 'trans', 'AdminTransController', 0, 0, '2018-06-23 05:49:10', NULL, NULL),
(19, 'Loại hàng', 'fa fa-th-large', 'gold_product_categories', 'gold_product_categories', 'AdminGoldProductCategoriesController', 0, 0, '2019-04-19 18:09:36', NULL, NULL),
(20, 'Kho hàng', 'fa fa-hospital-o', 'gold_stocks', 'gold_stocks', 'AdminGoldStocksController', 0, 0, '2019-04-19 18:25:43', NULL, NULL),
(21, 'Nhóm hàng', 'fa fa-th', 'gold_product_groups', 'gold_product_groups', 'AdminGoldProductGroupsController', 0, 0, '2019-04-19 18:33:57', NULL, NULL),
(22, 'Loại vàng', 'fa fa-unlink', 'gold_product_types', 'gold_product_types', 'AdminGoldProductTypesController', 0, 0, '2019-04-19 18:48:53', NULL, NULL),
(23, 'Đơn vị tính', 'fa fa-stack-overflow', 'gold_product_units', 'gold_product_units', 'AdminGoldProductUnitsController', 0, 0, '2019-04-20 08:00:45', NULL, NULL),
(24, 'Sản phẩm', 'fa fa-cubes', 'gold_products', 'gold_products', 'AdminGoldProductsController', 0, 0, '2019-04-20 08:24:53', NULL, NULL),
(25, 'Khách hàng', 'fa fa-male', 'gold_customers', 'gold_customers', 'AdminGoldCustomersController', 0, 0, '2019-04-23 08:54:43', NULL, NULL),
(26, 'Công nợ', 'fa fa-money', 'gold_liabilities', 'gold_liabilities', 'AdminGoldLiabilitiesController', 0, 0, '2019-04-23 09:49:28', NULL, NULL),
(27, 'Đơn hàng', 'fa fa-diamond', 'gold_sale_orders', 'gold_sale_orders', 'AdminGoldSaleOrdersController', 0, 0, '2019-04-23 16:50:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_notifications`
--

DROP TABLE IF EXISTS `cms_notifications`;
CREATE TABLE IF NOT EXISTS `cms_notifications` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_cms_users` int(11) DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_privileges`
--

DROP TABLE IF EXISTS `cms_privileges`;
CREATE TABLE IF NOT EXISTS `cms_privileges` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_superadmin` tinyint(1) DEFAULT NULL,
  `theme_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_privileges`
--

INSERT INTO `cms_privileges` (`id`, `name`, `is_superadmin`, `theme_color`, `created_at`, `updated_at`) VALUES
(1, 'Super Administrator', 1, 'skin-blue', '2018-03-28 16:38:50', NULL),
(2, 'Nhân viên bán hàng', 0, 'skin-blue', NULL, NULL),
(3, 'Quản lý đơn hàng sản xuất', 0, 'skin-blue', NULL, NULL),
(4, 'Quản trị hệ thống', 0, 'skin-blue', NULL, NULL),
(5, 'Kế toán', 0, 'skin-blue', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_privileges_roles`
--

DROP TABLE IF EXISTS `cms_privileges_roles`;
CREATE TABLE IF NOT EXISTS `cms_privileges_roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `is_visible` tinyint(1) DEFAULT NULL,
  `is_create` tinyint(1) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `is_edit` tinyint(1) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `id_cms_moduls` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_privileges_roles`
--

INSERT INTO `cms_privileges_roles` (`id`, `is_visible`, `is_create`, `is_read`, `is_edit`, `is_delete`, `id_cms_privileges`, `id_cms_moduls`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 0, 0, 0, 1, 1, '2018-03-28 16:38:50', NULL),
(2, 1, 1, 1, 1, 1, 1, 2, '2018-03-28 16:38:51', NULL),
(3, 0, 1, 1, 1, 1, 1, 3, '2018-03-28 16:38:51', NULL),
(4, 1, 1, 1, 1, 1, 1, 4, '2018-03-28 16:38:51', NULL),
(5, 1, 1, 1, 1, 1, 1, 5, '2018-03-28 16:38:51', NULL),
(6, 1, 1, 1, 1, 1, 1, 6, '2018-03-28 16:38:51', NULL),
(7, 1, 1, 1, 1, 1, 1, 7, '2018-03-28 16:38:51', NULL),
(8, 1, 1, 1, 1, 1, 1, 8, '2018-03-28 16:38:51', NULL),
(9, 1, 1, 1, 1, 1, 1, 9, '2018-03-28 16:38:51', NULL),
(10, 1, 1, 1, 1, 1, 1, 10, '2018-03-28 16:38:51', NULL),
(11, 1, 0, 1, 0, 1, 1, 11, '2018-03-28 16:38:51', NULL),
(12, 1, 1, 1, 1, 1, 2, 4, NULL, NULL),
(13, 1, 1, 1, 1, 1, 1, 12, NULL, NULL),
(14, 1, 1, 1, 1, 1, 1, 13, NULL, NULL),
(15, 1, 1, 1, 1, 1, 1, 14, NULL, NULL),
(16, 1, 1, 1, 1, 1, 1, 15, NULL, NULL),
(17, 1, 1, 1, 1, 1, 1, 16, NULL, NULL),
(18, 1, 1, 1, 1, 1, 1, 17, NULL, NULL),
(19, 1, 1, 1, 1, 1, 2, 17, NULL, NULL),
(20, 1, 1, 1, 1, 1, 1, 18, NULL, NULL),
(21, 1, 0, 0, 0, 0, 3, 13, NULL, NULL),
(22, 1, 0, 0, 0, 0, 4, 12, NULL, NULL),
(23, 1, 0, 0, 0, 0, 4, 14, NULL, NULL),
(24, 1, 0, 0, 0, 0, 4, 18, NULL, NULL),
(25, 1, 0, 0, 0, 0, 4, 13, NULL, NULL),
(26, 1, 0, 0, 0, 0, 4, 15, NULL, NULL),
(27, 1, 0, 0, 0, 0, 4, 16, NULL, NULL),
(28, 1, 0, 0, 0, 0, 4, 17, NULL, NULL),
(29, 1, 1, 1, 1, 1, 4, 4, NULL, NULL),
(30, 1, 1, 1, 1, 1, 1, 19, NULL, NULL),
(31, 1, 1, 1, 1, 1, 1, 20, NULL, NULL),
(32, 1, 1, 1, 1, 1, 1, 21, NULL, NULL),
(33, 1, 1, 1, 1, 1, 1, 22, NULL, NULL),
(34, 1, 1, 1, 1, 1, 5, 20, NULL, NULL),
(35, 1, 1, 1, 1, 1, 5, 19, NULL, NULL),
(36, 1, 1, 1, 1, 1, 5, 22, NULL, NULL),
(37, 1, 1, 1, 1, 1, 5, 21, NULL, NULL),
(38, 1, 1, 1, 1, 1, 1, 23, NULL, NULL),
(39, 1, 1, 1, 1, 1, 1, 24, NULL, NULL),
(40, 1, 1, 1, 1, 1, 5, 23, NULL, NULL),
(41, 1, 1, 1, 1, 1, 5, 24, NULL, NULL),
(42, 1, 0, 1, 0, 0, 4, 23, NULL, NULL),
(43, 1, 0, 1, 0, 0, 4, 20, NULL, NULL),
(44, 1, 0, 1, 0, 0, 4, 19, NULL, NULL),
(45, 1, 0, 1, 0, 0, 4, 22, NULL, NULL),
(46, 1, 0, 1, 0, 0, 4, 21, NULL, NULL),
(47, 1, 0, 1, 0, 0, 4, 24, NULL, NULL),
(48, 1, 1, 1, 1, 1, 1, 25, NULL, NULL),
(49, 1, 1, 1, 1, 1, 1, 26, NULL, NULL),
(50, 1, 1, 1, 1, 1, 1, 27, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_settings`
--

DROP TABLE IF EXISTS `cms_settings`;
CREATE TABLE IF NOT EXISTS `cms_settings` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `content_input_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dataenum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `helper` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `group_setting` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_settings`
--

INSERT INTO `cms_settings` (`id`, `name`, `content`, `content_input_type`, `dataenum`, `helper`, `created_at`, `updated_at`, `group_setting`, `label`) VALUES
(1, 'login_background_color', NULL, 'text', NULL, 'Input hexacode', '2018-03-28 16:38:51', NULL, 'Login Register Style', 'Login Background Color'),
(2, 'login_font_color', NULL, 'text', NULL, 'Input hexacode', '2018-03-28 16:38:51', NULL, 'Login Register Style', 'Login Font Color'),
(3, 'login_background_image', 'uploads/2019-04/efbeed6e1e280fdce87982f6d25ed152.jpg', 'upload_image', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Login Register Style', 'Login Background Image'),
(4, 'email_sender', 'support@crudbooster.com', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'Email Sender'),
(5, 'smtp_driver', 'mail', 'select', 'smtp,mail,sendmail', NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'Mail Driver'),
(6, 'smtp_host', '', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Host'),
(7, 'smtp_port', '25', 'text', NULL, 'default 25', '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Port'),
(8, 'smtp_username', '', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Username'),
(9, 'smtp_password', '', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Email Setting', 'SMTP Password'),
(10, 'appname', 'Việt Ngọc Jewerly', 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Application Name'),
(11, 'default_paper_size', 'Legal', 'text', NULL, 'Paper size, ex : A4, Legal, etc', '2018-03-28 16:38:51', NULL, 'Application Setting', 'Default Paper Print Size'),
(12, 'logo', 'uploads/2019-04/c52cca1e0f0865b1a378c1d1395cd51f.png', 'upload_image', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Logo'),
(13, 'favicon', 'uploads/2019-04/5a1ae61c6e05dc9cdf5b4bd46943281b.jpg', 'upload_image', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Favicon'),
(14, 'api_debug_mode', 'true', 'select', 'true,false', NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'API Debug Mode'),
(15, 'google_api_key', NULL, 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Google API Key'),
(16, 'google_fcm_key', NULL, 'text', NULL, NULL, '2018-03-28 16:38:51', NULL, 'Application Setting', 'Google FCM Key'),
(17, 'do_duc', '62.5', 'text', NULL, 'Bạn chỉ được nhập số', '2019-04-20 16:33:57', '2019-04-20 16:37:09', 'Tuổi vàng', 'Đồ đúc'),
(18, 'do_bong', '63.5', 'text', NULL, 'Bạn chỉ được nhập số', '2019-04-20 16:34:25', '2019-04-20 16:37:32', 'Tuổi vàng', 'Đồ bộng');

-- --------------------------------------------------------

--
-- Table structure for table `cms_statistics`
--

DROP TABLE IF EXISTS `cms_statistics`;
CREATE TABLE IF NOT EXISTS `cms_statistics` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_statistic_components`
--

DROP TABLE IF EXISTS `cms_statistic_components`;
CREATE TABLE IF NOT EXISTS `cms_statistic_components` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_cms_statistics` int(11) DEFAULT NULL,
  `componentID` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `component_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_name` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sorting` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_users`
--

DROP TABLE IF EXISTS `cms_users`;
CREATE TABLE IF NOT EXISTS `cms_users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_cms_privileges` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms_users`
--

INSERT INTO `cms_users` (`id`, `name`, `photo`, `email`, `password`, `id_cms_privileges`, `created_at`, `updated_at`, `status`) VALUES
(1, 'Super Admin', 'uploads/1/2019-04/vnjlogo.png', 'admin@crudbooster.com', '$2y$10$Jevyu0o1N651oyZjHyd0Y.367dhBWYrtCTp8jxak40DaWpGjZhw6a', 1, '2018-03-28 16:38:50', '2019-04-20 06:59:05', 'Active'),
(2, 'Võ Tuấn Nguyên', 'uploads/1/2019-04/vnjlogo.png', 'tuannguyen8888@gmail.com', '$2y$10$F1dU6JO7koEJjbDHwEKGeO8ZSNlVPseD3.hn8RJa/E4yj2Co0INGC', 5, '2019-04-23 05:13:21', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `code`, `name`) VALUES
(1, '001', 'John Doe');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `username`, `password`) VALUES
(1, 'Operator', 'operator', '$2y$10$CRRXQq9TCA6hVTD.BLMqze8YPk.FO3XDjK43MuoNocuZWCBmYd0pa');

-- --------------------------------------------------------

--
-- Table structure for table `gold_customers`
--

DROP TABLE IF EXISTS `gold_customers`;
CREATE TABLE IF NOT EXISTS `gold_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tmp_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import` int(1) DEFAULT '0' COMMENT '1 = Được import từ bảng công nợ của kế toán, mã được lưu vào cột code\n0 = Được phát sinh tạm thời khi Saler bán cho khách hàng mới, mã được lưu vào cột tmp_code',
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `tmp_code_UNIQUE` (`tmp_code`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_customers`
--

INSERT INTO `gold_customers` (`id`, `code`, `tmp_code`, `name`, `address`, `phone`, `import`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, NULL, 'KHMOI99', 'heheheheh', 'dsckjsbdkcjnjkb', '0987654567', 0, 'kjbkjbbhjb', '2019-04-23 09:20:04', NULL, NULL, NULL, NULL, NULL),
(2, NULL, 'KHMOI98', 'jhniuhuini', '165 đường số 2, P.3, Q.Gò Vấp', '987175075', 0, 'hhhh', '2019-04-23 09:40:09', NULL, NULL, NULL, NULL, NULL),
(3, 'KH0001', NULL, 'MINH HOÀNG 2', NULL, NULL, 1, NULL, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(4, 'KH0002', NULL, 'KIM OANH (TIỆM VÀNG )', NULL, NULL, 1, NULL, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(5, 'KH0003', NULL, 'KỲ KIM PHÁT HIỆP THÀNH', NULL, NULL, 1, NULL, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(6, 'KH0004', NULL, 'ĐỨC BẢO (TIÊM VÀNG)', NULL, NULL, 1, NULL, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(7, 'KH0005', NULL, 'HUỲNH HOA 4', NULL, NULL, 1, NULL, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_import_liabilities`
--

DROP TABLE IF EXISTS `gold_import_liabilities`;
CREATE TABLE IF NOT EXISTS `gold_import_liabilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_import_liabilities`
--

INSERT INTO `gold_import_liabilities` (`id`, `import_date`) VALUES
(1, '2019-04-23 11:28:28'),
(2, '2019-04-23 12:14:15'),
(3, '2019-04-23 12:26:15'),
(4, '2019-04-23 14:14:05'),
(5, '2019-04-23 14:35:40'),
(6, '2019-04-23 14:36:22'),
(7, '2019-04-23 14:38:15'),
(8, '2019-04-23 14:43:30');

-- --------------------------------------------------------

--
-- Table structure for table `gold_liabilities`
--

DROP TABLE IF EXISTS `gold_liabilities`;
CREATE TABLE IF NOT EXISTS `gold_liabilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_liabilities_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL COMMENT 'id khách hàng',
  `saler_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tên người bán',
  `date` timestamp NULL DEFAULT NULL COMMENT 'ngày công nợ',
  `age_sell` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tuổi ban',
  `exchange_g10_credit` double NOT NULL DEFAULT '0' COMMENT 'Qua ra vàng 10 (ghi có)',
  `wage_credit` double NOT NULL DEFAULT '0' COMMENT 'Tiền công (ghi có)',
  `exchange_g10_debit` double NOT NULL DEFAULT '0' COMMENT 'Qua ra vàng 10 (ghi nợ)',
  `wage_debit` double NOT NULL DEFAULT '0' COMMENT 'Qua ra vàng 10 (ghi nợ)',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_liabilities`
--

INSERT INTO `gold_liabilities` (`id`, `import_liabilities_id`, `customer_id`, `saler_name`, `date`, `age_sell`, `exchange_g10_credit`, `wage_credit`, `exchange_g10_debit`, `wage_debit`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 7, 3, 'Phạm Thị Ngọc Khuyên', NULL, '0', 0, 0, 0, 0, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(2, 7, 4, 'Đặng Thị Thanh Huệ', NULL, '0', 0, 0, 0, 0, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(3, 7, 5, 'Phạm Thị Ngọc Khuyên', '2019-03-24 17:00:00', '62.2', 5.5089859155, 0, 0, 0, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(4, 7, 6, 'Đặng Thị Thanh Huệ', '2019-03-16 17:00:00', '62.5', 0.2709100099, 0, 0, 0, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(5, 7, 7, 'TRẦN QUỐC HOANH', NULL, '0', 0, 0, 0.0001515152, 0, '2019-04-23 14:38:15', 1, NULL, NULL, NULL, NULL),
(6, 8, 3, 'Phạm Thị Ngọc Khuyên', NULL, '0', 0, 0, 0, 0, '2019-04-23 14:43:30', 1, NULL, NULL, NULL, NULL),
(7, 8, 4, 'Đặng Thị Thanh Huệ', NULL, '0', 0, 0, 0, 0, '2019-04-23 14:43:30', 1, NULL, NULL, NULL, NULL),
(8, 8, 5, 'Phạm Thị Ngọc Khuyên', '2019-03-24 17:00:00', '62.2', 5.5089859155, 0, 0, 0, '2019-04-23 14:43:30', 1, NULL, NULL, NULL, NULL),
(9, 8, 6, 'Đặng Thị Thanh Huệ', '2019-03-16 17:00:00', '62.5', 0.2709100099, 0, 0, 0, '2019-04-23 14:43:30', 1, NULL, NULL, NULL, NULL),
(10, 8, 7, 'TRẦN QUỐC HOANH', NULL, '0', 0, 0, 0.0001515152, 0, '2019-04-23 14:43:30', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_products`
--

DROP TABLE IF EXISTS `gold_products`;
CREATE TABLE IF NOT EXISTS `gold_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bar_code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'mã vạch, duy nhất',
  `product_code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Mã sản phẩm, có thể trùng',
  `product_name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'tên sản phẩm, có thể trùng',
  `product_unit_id` int(11) NOT NULL COMMENT 'Đơn vị Tính',
  `total_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng trọng lượng của sản phẩm',
  `gem_weight` double NOT NULL DEFAULT '0' COMMENT 'Trong lượng của đá quý trong sản phẩm',
  `gold_weight` double NOT NULL DEFAULT '0' COMMENT 'trọng lượng của vàng trong sản phẩm',
  `qty` int(11) NOT NULL DEFAULT '1' COMMENT 'Số lượng',
  `retail_machining_fee` double NOT NULL DEFAULT '0' COMMENT 'công lẻ',
  `whole_machining_fee` double NOT NULL DEFAULT '0' COMMENT 'Công sỉ',
  `fund_machining_fee` double NOT NULL DEFAULT '0' COMMENT 'Công vốn',
  `input_date` timestamp NULL DEFAULT NULL COMMENT 'Ngày nhập',
  `make_stemp_date` timestamp NULL DEFAULT NULL COMMENT 'Ngày làm tem',
  `stock_id` int(11) NOT NULL COMMENT 'Khi hàng',
  `product_category_id` int(11) NOT NULL COMMENT 'Loại hàng',
  `product_group_id` int(11) NOT NULL COMMENT 'Nhóm hàng',
  `product_type_id` int(11) NOT NULL COMMENT 'Loại vàng',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT 'Tình trạng\n0 - hết hàng\n1- còn hàng',
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Ghi chú',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bar_code_UNIQUE` (`bar_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_products`
--

INSERT INTO `gold_products` (`id`, `bar_code`, `product_code`, `product_name`, `product_unit_id`, `total_weight`, `gem_weight`, `gold_weight`, `qty`, `retail_machining_fee`, `whole_machining_fee`, `fund_machining_fee`, `input_date`, `make_stemp_date`, `stock_id`, `product_category_id`, `product_group_id`, `product_type_id`, `status`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, '0987654', 'V_87654567', 'buhk87654', 3, 1200, 250, 950, 1, 1000, 500, 3000, '2019-03-31 17:00:00', '2019-04-01 17:00:00', 1, 3, 2, 2, 1, 'he he', '2019-04-20 17:43:39', 1, '2019-04-20 17:45:13', 1, NULL, NULL),
(2, '1950400059421', 'NCB151', 'NC', 1, 0.861, 0, 0.861, 1, 130000, 0, 60000, '2019-04-09 17:00:00', NULL, 17, 1, 5, 2, 1, NULL, '2019-04-23 03:30:01', 1, '2019-04-23 03:33:07', 1, NULL, NULL),
(3, '1950400059506', 'NCB151', 'NC', 1, 0.87, 0, 0.87, 1, 130000, 0, 60000, '2019-04-09 17:00:00', NULL, 17, 1, 5, 2, 1, NULL, '2019-04-23 03:30:01', 1, '2019-04-23 03:33:07', 1, NULL, NULL),
(4, '1950400059513', 'NCB151', 'NC', 1, 0.863, 0, 0.863, 1, 130000, 0, 60000, '2019-04-09 17:00:00', NULL, 17, 1, 5, 1, 1, NULL, '2019-04-23 03:30:01', 1, '2019-04-23 03:33:07', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_categories`
--

DROP TABLE IF EXISTS `gold_product_categories`;
CREATE TABLE IF NOT EXISTS `gold_product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Loại hàng: Nhẫn, Vòng, …',
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_categories`
--

INSERT INTO `gold_product_categories` (`id`, `name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'Nhẫn', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(2, 'Vòng', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(3, 'Bông', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(4, 'Dây', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(5, 'Lắc', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL),
(6, 'Mặt', '2019-04-20 04:54:56', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_groups`
--

DROP TABLE IF EXISTS `gold_product_groups`;
CREATE TABLE IF NOT EXISTS `gold_product_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Nhóm hàng: Nhẫn cưới, Bông',
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` int(11) DEFAULT NULL,
  `deleted_by` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_groups`
--

INSERT INTO `gold_product_groups` (`id`, `name`, `product_category_id`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'Bông đít đẩy', 3, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(2, 'Bông giò gà', 3, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(3, 'Dây cổ', 4, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(4, 'Lắc tay', 5, '2019-04-20 04:55:27', 1, NULL, NULL, NULL, NULL),
(5, 'Nhẫn cưới', NULL, '2019-04-23 03:19:21', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_types`
--

DROP TABLE IF EXISTS `gold_product_types`;
CREATE TABLE IF NOT EXISTS `gold_product_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Loại vàng: 610, 680, …',
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_types`
--

INSERT INTO `gold_product_types` (`id`, `name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, '610', '2019-04-20 04:56:02', 1, NULL, NULL, NULL, NULL),
(2, '680', '2019-04-20 04:56:02', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_product_units`
--

DROP TABLE IF EXISTS `gold_product_units`;
CREATE TABLE IF NOT EXISTS `gold_product_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_product_units`
--

INSERT INTO `gold_product_units` (`id`, `name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'Đôi', '2019-04-20 08:08:57', 1, NULL, NULL, NULL, NULL),
(2, 'Chiếc', '2019-04-20 08:09:02', 1, NULL, NULL, NULL, NULL),
(3, 'Bộ', '2019-04-20 08:11:16', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_orders`
--

DROP TABLE IF EXISTS `gold_sale_orders`;
CREATE TABLE IF NOT EXISTS `gold_sale_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL COMMENT 'Khách hàng',
  `debt_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày công nợ',
  `days_diff` int(11) NOT NULL COMMENT 'Số Ngày',
  `exchange_g10` double NOT NULL COMMENT 'Q10',
  `wage` double NOT NULL COMMENT 'Tiền công',
  `saler_id` int(11) NOT NULL COMMENT 'Người ban',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày đơn hàng',
  `order_no` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'tự phát sinh \rFormat (DHYYMMDD-###\rVí dụ: DH190418-001',
  `pay_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày thu tiền, dự kiến',
  `actual_weight` double NOT NULL COMMENT 'Tổng cân thực tế',
  `reduce` double NOT NULL DEFAULT '0' COMMENT 'Giảm trừ (số tiền)',
  `reason_pay_not_enough` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Lý do chưa thu hết công nợ cũ/tiền công',
  `other_orders` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Khách đặt',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_order_details`
--

DROP TABLE IF EXISTS `gold_sale_order_details`;
CREATE TABLE IF NOT EXISTS `gold_sale_order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `sort_no` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_order_pays`
--

DROP TABLE IF EXISTS `gold_sale_order_pays`;
CREATE TABLE IF NOT EXISTS `gold_sale_order_pays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_method` int(11) NOT NULL DEFAULT '0' COMMENT '1 - Thảo\n2 - Dẻ\n3 - Tiền mặt\n4 - Đúc\n5 - Bộng',
  `description` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0' COMMENT 'Số lượng',
  `total_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng cân\\r(Chỉ)',
  `gem_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng đá\\r(Chỉ)',
  `gold_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng vàng 18\\r(Chỉ)',
  `money` double NOT NULL DEFAULT '0' COMMENT 'Tiền mặt',
  `gold_age` double NOT NULL DEFAULT '0' COMMENT 'Tuổi (%)',
  `converted_price` double NOT NULL DEFAULT '0',
  `exchange_g10` double NOT NULL DEFAULT '0' COMMENT 'Vàng quy 10\\r(Chỉ)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_sale_order_returns`
--

DROP TABLE IF EXISTS `gold_sale_order_returns`;
CREATE TABLE IF NOT EXISTS `gold_sale_order_returns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `sort_no` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL COMMENT '1 - Đồ đúc\n2 - Đồ bộng',
  `qty` int(11) NOT NULL DEFAULT '0' COMMENT 'Số lượng (mon)',
  `total_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng cân\r(Chỉ)',
  `gem_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng đá\r(Chỉ)',
  `gold_weight` double NOT NULL DEFAULT '0' COMMENT 'Tổng vàng 18\r(Chỉ)',
  `gold_age` double NOT NULL DEFAULT '0' COMMENT 'Tuổi (%)',
  `exchange_g10` double NOT NULL DEFAULT '0' COMMENT 'Vàng quy 10\r(Chỉ)',
  `wage` double NOT NULL DEFAULT '0' COMMENT 'Tiền công',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gold_stocks`
--

DROP TABLE IF EXISTS `gold_stocks`;
CREATE TABLE IF NOT EXISTS `gold_stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Kho hàng',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gold_stocks`
--

INSERT INTO `gold_stocks` (`id`, `name`, `notes`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'KHO 68', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(2, 'KHO A', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(3, 'KHO B', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(4, 'KHO C', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(5, 'Kho hàng sửa', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(6, 'Kho phát 1', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(7, 'Kho phát 2', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(8, 'Kho phát 3', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(9, 'Kho phát 4', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(10, 'Kho phát 5', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(11, 'Kho phát 6', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(12, 'Kho phát 7', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(13, 'Kho phát 8', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(14, 'KHO VIET NGOC', NULL, '2019-04-20 04:55:47', 1, NULL, NULL, NULL, NULL),
(15, 'Kho test aaa', 'test aaaakkkkkmomk', '2019-04-20 04:56:54', 1, '2019-04-20 05:39:42', 1, '2019-04-20 08:20:29', 1),
(16, 'tesst 2', 'fhdgf', '2019-04-20 05:40:31', 1, '2019-04-20 08:17:03', 1, '2019-04-20 08:20:23', 1),
(17, 'KHO  A', NULL, '2019-04-23 03:13:18', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_06_23_125201_create_categories_table', 1),
(2, '2018_06_23_125201_create_cms_apicustom_table', 1),
(3, '2018_06_23_125201_create_cms_apikey_table', 1),
(4, '2018_06_23_125201_create_cms_dashboard_table', 1),
(5, '2018_06_23_125201_create_cms_email_queues_table', 1),
(6, '2018_06_23_125201_create_cms_email_templates_table', 1),
(7, '2018_06_23_125201_create_cms_logs_table', 1),
(8, '2018_06_23_125201_create_cms_menus_privileges_table', 1),
(9, '2018_06_23_125201_create_cms_menus_table', 1),
(10, '2018_06_23_125201_create_cms_moduls_table', 1),
(11, '2018_06_23_125201_create_cms_notifications_table', 1),
(12, '2018_06_23_125201_create_cms_privileges_roles_table', 1),
(13, '2018_06_23_125201_create_cms_privileges_table', 1),
(14, '2018_06_23_125201_create_cms_settings_table', 1),
(15, '2018_06_23_125201_create_cms_statistic_components_table', 1),
(16, '2018_06_23_125201_create_cms_statistics_table', 1),
(17, '2018_06_23_125201_create_cms_users_table', 1),
(18, '2018_06_23_125201_create_customers_table', 1),
(19, '2018_06_23_125201_create_employees_table', 1),
(20, '2018_06_23_125201_create_products_table', 1),
(21, '2018_06_23_125201_create_trans_detail_table', 1),
(22, '2018_06_23_125201_create_trans_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_id` int(11) DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `main_price` double DEFAULT NULL,
  `sell_price` double DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `categories_id`, `code`, `name`, `main_price`, `sell_price`, `stock`) VALUES
(1, 3, 'PZ1', 'Penzoil 1 ltr', 90000, 120000, 100),
(2, 3, 'CS1', 'Castrol 1 ltr', 95000, 130000, 100),
(3, 3, 'MO1', 'Mobil One 1 ltr', 70000, 100000, 100),
(4, 3, 'SR1', 'Shell Rotellia 1 ltr', 120000, 160000, 110),
(5, 2, 'FBT', 'Front Bumper Toyota', 250000, 350000, 100),
(6, 2, 'SCOWLS', 'Cowl Screen Toyota', 200000, 300000, 100),
(7, 2, 'SFTOY', 'Fender Toyota', 300000, 400000, 100),
(8, 2, 'SBPAD1', 'Brake Pad Toyota Genuine', 450000, 550000, 100),
(9, 2, 'SACF', 'Filter AC Toyota', 200000, 325000, 100),
(10, 1, 'TGY1517070', 'Goodyear R15 170/70', 550000, 650000, 50),
(11, 1, 'TM1517070', 'Michelin R15 170/70', 450000, 500000, 100),
(12, 1, 'TB1517070', 'Bridgestone R15 170/70', 600000, 700000, 100),
(13, 1, 'TH1517070', 'Hankook R15 170/70', 570000, 700000, 100);

-- --------------------------------------------------------

--
-- Table structure for table `trans`
--

DROP TABLE IF EXISTS `trans`;
CREATE TABLE IF NOT EXISTS `trans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `employees_id` int(11) DEFAULT NULL,
  `trans_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customers_code` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customers_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_total` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `grand_total` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employees_id` (`employees_id`),
  KEY `customers_code` (`customers_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trans`
--

INSERT INTO `trans` (`id`, `created_at`, `employees_id`, `trans_no`, `customers_code`, `customers_name`, `sub_total`, `discount`, `tax`, `grand_total`) VALUES
(1, '2018-03-29 00:17:09', 1, '00001', '000', 'Walk In', 3275000, 0, 327500, 3602500),
(2, '2018-03-29 00:17:27', 1, '00002', '000', 'Walk In', 160000, 0, 16000, 176000),
(3, '2018-03-29 00:17:50', 1, '00003', '000', 'Walk In', 2975000, 0, 297500, 3272500),
(4, '2018-03-29 00:19:26', 1, '00004', '000', 'Walk In', 2535000, 0, 253500, 2788500),
(5, '2018-03-29 09:46:02', 1, '00005', '000', 'Walk In', 230000, 0, 23000, 253000),
(6, '2018-03-29 09:46:19', 1, '00006', '000', 'Walk In', 130000, 0, 13000, 143000);

-- --------------------------------------------------------

--
-- Table structure for table `trans_detail`
--

DROP TABLE IF EXISTS `trans_detail`;
CREATE TABLE IF NOT EXISTS `trans_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_id` int(11) DEFAULT NULL,
  `products_id` int(11) DEFAULT NULL,
  `products_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `products_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `products_main_price` double DEFAULT NULL,
  `products_sell_price` double DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trans_id` (`trans_id`),
  KEY `products_id` (`products_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trans_detail`
--

INSERT INTO `trans_detail` (`id`, `trans_id`, `products_id`, `products_code`, `products_name`, `products_main_price`, `products_sell_price`, `quantity`, `total`) VALUES
(1, 1, 7, 'SFTOY', 'Fender Toyota', 300000, 400000, 1, 400000),
(2, 1, 13, 'TH1517070', 'Hankook R15 170/70', 570000, 700000, 1, 700000),
(3, 1, 11, 'TM1517070', 'Michelin R15 170/70', 450000, 500000, 1, 500000),
(4, 1, 9, 'SACF', 'Filter AC Toyota', 200000, 325000, 1, 325000),
(5, 1, 5, 'FBT', 'Front Bumper Toyota', 250000, 350000, 1, 350000),
(6, 1, 3, 'MO1', 'Mobil One 1 ltr', 70000, 100000, 1, 100000),
(7, 1, 1, 'PZ1', 'Penzoil 1 ltr', 90000, 120000, 1, 120000),
(8, 1, 10, 'TGY1517070', 'Goodyear R15 170/70', 550000, 650000, 1, 650000),
(9, 1, 2, 'CS1', 'Castrol 1 ltr', 95000, 130000, 1, 130000),
(10, 2, 4, 'SR1', 'Shell Rotellia 1 ltr', 120000, 160000, 1, 160000),
(11, 3, 5, 'FBT', 'Front Bumper Toyota', 250000, 350000, 5, 1750000),
(12, 3, 9, 'SACF', 'Filter AC Toyota', 200000, 325000, 1, 325000),
(13, 3, 12, 'TB1517070', 'Bridgestone R15 170/70', 600000, 700000, 1, 700000),
(14, 3, 2, 'CS1', 'Castrol 1 ltr', 95000, 130000, 1, 130000),
(15, 3, 6, 'SCOWLS', 'Cowl Screen Toyota', 200000, 300000, 1, 300000),
(16, 3, 1, 'PZ1', 'Penzoil 1 ltr', 90000, 120000, 1, 120000),
(17, 4, 4, 'SR1', 'Shell Rotellia 1 ltr', 120000, 160000, 1, 160000),
(18, 4, 3, 'MO1', 'Mobil One 1 ltr', 70000, 100000, 1, 100000),
(19, 4, 9, 'SACF', 'Filter AC Toyota', 200000, 325000, 8, 2600000),
(20, 5, 3, 'MO1', 'Mobil One 1 ltr', 70000, 100000, 1, 100000),
(21, 5, 2, 'CS1', 'Castrol 1 ltr', 95000, 130000, 1, 130000),
(22, 6, 2, 'CS1', 'Castrol 1 ltr', 95000, 130000, 1, 130000);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
